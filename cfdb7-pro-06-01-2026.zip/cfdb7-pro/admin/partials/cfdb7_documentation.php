<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Main logic block for displaying the plugin documentation page in the admin area.
 *
 * - Enqueues the documentation-specific stylesheet for proper UI styling.
 * - Renders a heading for the documentation section using WordPress translation functions.
 *
 * @since 1.0.0
*/

wp_enqueue_style( 'cfdb7_document_style' );
?>
<div class="wrap cfdb7-contact-us">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Documentation', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
    <div class="cfdb7-pro-addon-guide">
        <section>
            <div>
                <h1>CFDB7 Pro Addon – Easy User Guide</h1>
                <p>Our addon works together with the Contact Form 7 Database Addon – CFDB7 plugin. We do not change the original plugin. Instead, we add extra features to make managing your form entries easier, faster, and more powerful with Multisite and Multi language support in CFDB7 pro addon.</p>
                <p>Below are all the features explained in simple words.</p>
            </div>

            <div>
                <h2>1. CFDB7 Entries</h2>
                <p>This menu shows all the entries submitted through Contact Form 7, import and indexing previous entries.</p>
                <h3>✔ Features:</h3>
                <ul>
                    <li>Date Filter: See entries between specific submission dates.</li>
                    <li>Keyword Search: Find entries using any word, name, email, or text.</li>
                    <li>Search by Field Name: Search by specific field values (like “email”, “phone”, “name” etc.).</li>
                    <li>Field Name Display: All field names are shown clearly in the generated report.</li>
                    <li>Delete multiple entries at once</li>
                    <li>Export multiple entries at once</li>
                    <li>You can also view each entry in a popup.</li>
                </ul>
                <p>Deleted entries are not removed permanently. They go to the Delete & Restore menu.</p>
                <h3>✔ Display Settings</h3>
                <ul>
                    <li>Rename field labels</li>
                    <li>Hide specific fields from the report and exports</li>
                </ul>
                <h3>✔ Optimized Performance</h3>
                <ul>
                    <li>Bulk delete and export actions run in small parts to avoid server load.</li>
                </ul>
            </div>

            <div>
                <h2>2. Delete & Restore</h2>
                <p>This menu shows all entries you deleted from “CFDB7 Entries”.</p>
                <h3>✔ Features:</h3>
                <ul>
                    <li>Date Filter: See entries between specific submission dates.</li>
                    <li>Keyword Search: Find entries using any word, name, email, or text.</li>
                    <li>Search by Field Name: Search by specific field values (like “email”, “phone”, “name” etc.).</li>
                    <li>Field Name Display: All field names are shown clearly in the generated report.</li>
                    <li>Bulk Delete (permanent delete)</li>
                    <li>Bulk Restore (move back to main entries)</li>
                </ul>
                <p>Restored entries go back to “CFDB7 Entries” menu and removed from “Delete & Restore” menu.</p>
                <h3>✔ Display Settings</h3>
                <ul>
                    <li>Rename field labels</li>
                    <li>Hide specific fields from the report</li>
                </ul>
                <h3>✔ Optimized Performance</h3>
                <ul>
                    <li>Bulk delete and restore actions run in small parts to avoid server load.</li>
                </ul>
            </div>

            <div>
                <h2>3. Export Logs</h2>
                <p>This menu shows a list of all exported files.</p>
                <h3>✔ Includes:</h3>
                <ul>
                    <li>Date and time of export</li>
                    <li>User who exported</li>
                    <li>Download exported files</li>
                </ul>
            </div>

            <div>
                <h2>4. Entry Logger</h2>
                <p>This menu helps you compare the original submitted entry with the final saved entry, based on the form settings applied to the entry.</p>
                <h3>✔ Features:</h3>
                <ul>
                    <li>Date Filter: See entries between specific submission dates.</li>
                    <li>Keyword Search: Find entries using any word, name, email, or text.</li>
                    <li>Search by Field Name: Search by specific field values (like “email”, “phone”, “name” etc.).</li>
                    <li>Field Name Display: All field names are shown clearly in the generated report.</li>
                    <li>You can also view each entry in a popup.</li>
                </ul>
                <h3>✔ Display Settings</h3>
                <ul>
                    <li>Rename field labels</li>
                    <li>Hide specific fields from the report</li>
                </ul>
            </div>

            <div>
                <h2>5. Indexing Entries</h2>
                <p>This feature scans and fixes old or missing entries.</p>
                <h3>✔ Useful when:</h3>
                <ul>
                    <li>Some entries didn’t save correctly due to server issues</li>
                    <li>You want to bring old CFDB7 entries into the Pro addon</li>
                </ul>
            </div>

            <div>
                <h2>6. Indexing Field Names</h2>
                <p>This screen helps fix problems related to field names in reports.</p>
                <h3>✔ Useful when:</h3>
                <ul>
                    <li>If field names weren’t saved correctly due to server issues, indexing will repair them.</li>
                </ul>
            </div>

            <div>
                <h2>7. Import Entries</h2>
                <p>You can import entries from a CSV file.</p>
                <h3>✔ How it works:</h3>
                <ul>
                    <li>Select the Contact Form 7 form</li>
                    <li>Prepare a CSV file with matching field names</li>
                    <li>Upload and import your entries</li>
                </ul>
            </div>

            <div>
                <h2>8. Settings</h2>
                <p>Settings for controlling the submission of entries through Contact Form 7, and for importing and indexing previous entries. These settings are also used for displaying entries.</p>
                <h3>✔ Features:</h3>
                <ul>
                    <li>Duplicate Entry Protection: Stop the same entry from being submitted more than once.</li>
                    <li>Exclude Fields from Saving: Choose which fields should not be saved (for example, Google reCAPTCHA keys).</li>
                    <li>Enquiries Per Page: Set how many entries to show on one page.</li>
                    <li>Character Limit for Logs: Limit how much text is shown in entry logs.</li>
                </ul>
                <h3>✔ Useful when:</h3>
                <ul>
                    <li>New Contact Form 7 submissions</li>
                    <li>Imported entries</li>
                    <li>Indexed entries</li>
                </ul>
            </div>

            <div>
                <h2>9. Tools</h2>
                <p>This menu allows you to generate necessary database tables for the CFDB7 Pro addon.</p>
            </div>
        </section>        
    </div>
</div>
