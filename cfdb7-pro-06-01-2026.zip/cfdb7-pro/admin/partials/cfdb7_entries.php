<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Render the entries UI for displaying Contact Form 7 submissions or activation notice.
 *
 * This logic checks plugin activation status and includes the appropriate partial for displaying entries
 * or showing an activation notice. Enqueues required styles and scripts for UI functionality.
 *
 * Coding Guide:
 * - Use plugin activation constant to control UI logic.
 * - Enqueue required styles and scripts for entries UI.
 *
 * @since 1.0.0
*/

wp_enqueue_style( 'cfdb7_entries_style' );
wp_enqueue_script( 'cfdb7_entries_script' );
?>
<div class="wrap cfdb7-entries">
    <?php 
	if(CFDB7_ACTIVATED == true){
		include_once plugin_dir_path( __DIR__ ).'partials/cfdb7_entries_submissions.php';
	}else{
		include_once plugin_dir_path( __DIR__ ).'partials/cfdb7_activation_notice.php';
	} 
	?>
</div>