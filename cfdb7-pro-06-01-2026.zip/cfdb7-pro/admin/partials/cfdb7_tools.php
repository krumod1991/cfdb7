<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Display the admin tools view for the plugin, including the table generator utility.
 *
 * This section provides a UI for generating necessary database tables based on form data.
 * It enqueues required scripts and styles, and renders the table generator card with nonce protection.
 *
 * Coding Guide:
 * - Use wp_enqueue_script and wp_enqueue_style to load assets for the tools page.
 * - Use wp_nonce_field for security when triggering table generation.
 * - Display clear instructions and feedback to the user.
 * - Use semantic HTML and WordPress translation functions for accessibility.
 *
 * @since 1.0.0
 */
wp_enqueue_script( 'cfdb7_tools_script' );
wp_enqueue_style( 'cfdb7_tools_style' );
?>
<div class="wrap cfdb7-tools">
    <div class="loader" style="display:none;">
        <div class="loader-icon"></div>
    </div>
    <div class="notice" style="display:none;"><p id="notice"></p></div>
    <h1 class="wp-heading-inline"><?php echo esc_html__('Tools', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
    <div class="card fancy-shadow">
        <h2 class="title">
            <span class="dashicons dashicons-database"></span> <?php echo esc_html__('Generate Tables', CFDB7_PRO_TEXT_DOMAIN); ?>
        </h2>
        <p class="context-info">
            <?php echo esc_html__('This utility will analyze your form data and ensure the necessary database structure is in place.', CFDB7_PRO_TEXT_DOMAIN); ?>
        </p>
        <p>
            <button id="generate-tables" class="button button-primary button-large"><?php echo esc_html__('Run Table Generator', CFDB7_PRO_TEXT_DOMAIN); ?></button>
            <?php wp_nonce_field('generate_tables', 'generate_tables_nonce'); ?>
        </p>
    </div>
</div>