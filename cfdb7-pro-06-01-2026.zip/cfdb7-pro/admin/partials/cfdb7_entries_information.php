<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Render detailed entry information for a specific Contact Form 7 submission.
 *
 * This logic verifies nonce for security, retrieves entry details, and displays field values in a structured table format.
 * Handles field renaming, ordering, and file fields with download links. All input and output is sanitized for security.
 * Provides admin notices for error states.
 *
 * Coding Guide:
 * - Sanitize all input and output data.
 * - Use wp_verify_nonce for security against CSRF.
 * - Use esc_html, esc_attr, and esc_url for safe output.
 * - Support field renaming and ordering from display settings.
 * - Handle file fields with download links.
 * - Provide clear admin notices for error states.
 *
 * @since 1.0.0
 * @param int $_POST['cf7_id'] Selected form ID for entry.
 * @param string $_POST['nonce'] Nonce for security verification.
 * @param int $_POST['index'] Entry index to display.
 * @param string $_POST['context'] Display context for field settings.
*/

$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
$index = isset($_POST['index']) && !empty($_POST['index']) ? intval($_POST['index']) : "";
$context = isset($_POST['context']) && !empty($_POST['context']) ? sanitize_text_field($_POST['context']) : "";
if(!empty($cf7_id) && !empty($nonce) && !empty($index) && !empty($context)){
	if(wp_verify_nonce($nonce, 'entries_page')){
		global $wpdb;
		$obj = new Cfdb7_Queries();
		$obj->init_cfdb7_tables();
		
		$entry_id = $index;
		$entry_details =  $obj->get_cfdb7_form_entry_details($wpdb, $cf7_id, $entry_id);
		if(!empty($entry_details)){
			$user_info = cfdb7_get_logged_in_user_info();
			$user_id = $user_info['user_id'];

			$display_settings = $obj->get_cfdb7_form_display_settings($wpdb, $cf7_id, $user_id, $context);

			$rename_fields = array();
			$field_order = array();
			$saved_settings = isset($display_settings['settings']) && !empty($display_settings['settings']) ? maybe_unserialize($display_settings['settings']) : array();
			if(!empty($saved_settings)){
				$rename_fields = isset($saved_settings['rename_field']) && !empty($saved_settings['rename_field']) ? array_map('sanitize_text_field', $saved_settings['rename_field']) : array();

				$field_order = isset($saved_settings['field_order']) && !empty($saved_settings['field_order']) ? array_map('sanitize_text_field', $saved_settings['field_order']) : array();
			}

			$lead_source = isset($entry_details['lead_source']) && !empty($entry_details['lead_source']) ? esc_html($entry_details['lead_source']) : "";

			$form_submissions = isset($entry_details['form_submissions']) && !empty($entry_details['form_submissions']) ? maybe_unserialize($entry_details['form_submissions']) : array();
			$form_submissions = !empty($form_submissions) ? array_map('sanitize_text_field', $form_submissions) : array();

			$form_submission_fields = isset($entry_details['form_submission_fields']) && !empty($entry_details['form_submission_fields']) ? maybe_unserialize($entry_details['form_submission_fields']) : array();
			$form_submission_fields = !empty($form_submission_fields) ? array_map('sanitize_text_field', $form_submission_fields) : array();

			$submit_display_name = isset($entry_details['submit_display_name']) && !empty($entry_details['submit_display_name']) ? esc_html($entry_details['submit_display_name']) : "";

			$submit_date_time = isset($entry_details['submit_date_time']) && !empty($entry_details['submit_date_time']) ? esc_html(date("d-m-Y H:i:s", strtotime($entry_details['submit_date_time']))) : "";

			$submit_ip_address = isset($entry_details['submit_ip_address']) && !empty($entry_details['submit_ip_address']) ? esc_html($entry_details['submit_ip_address']) : "";

			if(!empty($form_submissions)){
				// sanitize keys + values
				$clean = array();
				foreach ($form_submissions as $key => $value) {
					$clean[sanitize_text_field($key)] = sanitize_text_field($value);
				}
				$form_submissions = $clean;

				//Apply field ordering if provided
				if (!empty($field_order) && is_array($field_order)) {
					$ordered = array();
					foreach ($field_order as $key) {
						if (isset($form_submissions[$key])) {
							$ordered[$key] = $form_submissions[$key];
						}
					}
					// Add remaining fields not listed in order
					foreach ($form_submissions as $key => $value) {
						if (!isset($ordered[$key])) {
							$ordered[$key] = $value;
						}
					}
					$form_submissions = $ordered;
				}
				?>
				<table border="1" class="logger-original-information">
					<thead>
						<tr>
							<th><?php echo esc_html__('Field Name', CFDB7_PRO_TEXT_DOMAIN); ?></th>
							<th><?php echo esc_html__('Field Value', CFDB7_PRO_TEXT_DOMAIN); ?></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php echo esc_html__('lead source', CFDB7_PRO_TEXT_DOMAIN); ?></td>
							<td><?php echo $lead_source; ?></td>
						</tr>
						<?php 
						foreach($form_submissions as $entry_name => $entry_value){
							$field_type = isset($form_submission_fields[$entry_name]) && !empty($form_submission_fields[$entry_name]) ? esc_html($form_submission_fields[$entry_name]) : '';
							//Apply rename_fields: If a rename is defined, apply it
							$display_name = isset($rename_fields[$entry_name]) && !empty($rename_fields[$entry_name]) ? esc_html($rename_fields[$entry_name]) :esc_html($entry_name);

							if($field_type == 'file'){
								$entry_value = '<a href="'.esc_url($entry_value).'" target="_blank">'.esc_html(basename($entry_value)).'</a>';
							}else{
								$entry_value = esc_html(html_entity_decode($entry_value));
							}
							?>
							<tr>
								<td><?php echo $display_name; ?></td>
								<td><?php echo $entry_value; ?></td>
							</tr>
							<?php
						}
						?>
						<tr>
							<td><?php echo esc_html__('submit by', CFDB7_PRO_TEXT_DOMAIN); ?></td>
							<td><?php echo $submit_display_name; ?></td>
						</tr>
						<tr>
							<td><?php echo esc_html__('submit date time', CFDB7_PRO_TEXT_DOMAIN); ?></td>
							<td><?php echo $submit_date_time; ?></td>
						</tr>
						<tr>
							<td><?php echo esc_html__('submit ip address', CFDB7_PRO_TEXT_DOMAIN); ?></td>
							<td><?php echo $submit_ip_address; ?></td>
						</tr>
					</tbody>
				</table>
				<?php
			}
		}	
	}else{
		?>
		<div class="notice notice-error"><p><?php echo esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
		<?php
	}
}