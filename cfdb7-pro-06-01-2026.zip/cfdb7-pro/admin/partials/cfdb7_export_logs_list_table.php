<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Render and manage the export logs list table UI for Contact Form 7 entries.
 *
 * This logic sets up the WP_List_Table for export logs, handles pagination, filtering by date,
 * column rendering, and download actions. It verifies nonce for security, sanitizes all input/output,
 * and enqueues required styles/scripts for UI functionality. Also provides admin notices for error states.
 *
 * Coding Guide:
 * - Extend WP_List_Table for custom table functionality.
 * - Sanitize all input and output data.
 * - Use wp_nonce_field and wp_verify_nonce for security against CSRF.
 * - Use esc_html, esc_attr, and esc_url for safe output.
 * - Provide clear admin notices for error states.
 * - Enqueue required styles and scripts for UI and popup functionality.
 *
 * @since 1.0.0
 * @param object $wpdb WordPress database object.
 * @param object $obj Cfdb7_Queries object for database operations.
 * @param int $cf7_id Selected form ID for export logs.
 * @param string $context Current admin page context.
 * @param string $admin_page_url Admin page URL for actions.
 * @param string $nonce Nonce for security verification.
*/

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

wp_enqueue_style('cfdb7_magnific_popup_style');
wp_enqueue_style('jquery-ui-css');
wp_enqueue_style('cfdb7_chosen_style');
wp_enqueue_style('cfdb7_dataTable_style_1');
wp_enqueue_style('cfdb7_dataTable_style_2');
wp_enqueue_script('cfdb7_magnific_popup_script');
wp_enqueue_script('jquery-ui-datepicker');
wp_enqueue_script('cfdb7_chosen_script');
wp_enqueue_script('cfdb7_dataTable_script_1');
wp_enqueue_script('cfdb7_dataTable_script_2');
wp_enqueue_script('cfdb7_dataTable_script_3');

/**
 * Class Custom_WP_List_Table
 *
 * Handles the display and management of deleted entries in the admin area for the Cfdb7 Pro plugin.
 * Extends the WP_List_Table class to provide custom table functionality for Contact Form 7 entries.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
*/
class Custom_WP_List_Table extends WP_List_Table {
    private $wpdb;
    private $obj;
    private $cf7_id;
    private $context;
    private $admin_page_url;
    private $nonce;
    private $form_settings = array();
    private $list_table_id = "cfdb7-export-entries";

    /**
     * Constructor for Custom_WP_List_Table.
     * Initializes the table, sets up dependencies, and loads form settings.
     */
    public function __construct($obj_data) {
        parent::__construct([
            'singular' => 'item',
            'plural'   => 'items',
            'ajax'     => false
        ]);

        $this->wpdb = $obj_data['wpdb'];
        $this->obj = $obj_data['obj'];
        $this->cf7_id = $obj_data['cf7_id'];
        $this->context = $obj_data['context'];
        $this->admin_page_url = $obj_data['admin_page_url'];
        $this->nonce = $obj_data['nonce'];
        $this->form_settings = $this->obj->get_cfdb7_form_setting($this->wpdb, $this->cf7_id);
    }

    /**
     * Get the columns for the export logs table.
     *
     * @return array Columns to display in the table.
     */
    public function get_columns() {
        return [
            'export_display_name' => esc_html__('Export By', CFDB7_PRO_TEXT_DOMAIN),
            'export_date_time' => esc_html__('Date Time', CFDB7_PRO_TEXT_DOMAIN),
            'export_ip_address' => esc_html__('Ip Address', CFDB7_PRO_TEXT_DOMAIN),
            'export_file_url' => esc_html__('File URL', CFDB7_PRO_TEXT_DOMAIN),
        ];
    }

    /**
     * Default column rendering for the table.
     *
     * @param array $item The current item.
     * @param string $column_name The name of the column.
     * @return string Column output.
     */
    public function column_default($item, $column_name) {
        switch ($column_name) {
            case 'export_display_name':
                return esc_html($item[$column_name]);
            case 'export_date_time':
                return date('d-m-Y H:i:s', strtotime(esc_html($item[$column_name])));
            case 'export_ip_address':
                return esc_html($item[$column_name]);
            case 'export_file_url':
                return $this->get_download_cta(esc_html($item[$column_name]));
            default:
                return "";
        }
    }

    /**
     * Output the View button for a given entry.
     *
     * @param int $id Entry ID.
     */
    private function get_download_cta($export_file_url){
        echo '<a href="' . esc_url($export_file_url) . '" download>' . esc_html__( 'Download', CFDB7_PRO_TEXT_DOMAIN ) . '</a>';
    }

    /**
     * Output message when no items are found.
     *
     * @return void
     */
    public function no_items() {
        echo esc_html__( 'No enquiries found.', CFDB7_PRO_TEXT_DOMAIN );
    }

    /**
     * Prepares the items for display in the export logs list table, including pagination and date filtering.
     *
     * - Loads form settings for pagination.
     * - Sanitizes and validates all GET parameters for date filtering.
     * - Handles date range validation and displays error messages for invalid input.
     * - Retrieves filtered export log data and paginates results for the current page.
     * - Sets up table columns, pagination, and headers for WP_List_Table.
     *
     * @since 1.0.0
     *
     * Coding Guide:
     * - Always sanitize and validate all incoming GET data.
     * - Use esc_html, esc_attr, esc_url for output escaping.
     * - Use WordPress translation functions for all user-facing text.
     *
     * Security Practices:
     * - All output is properly escaped to prevent XSS.
    */
    public function prepare_items() {
        $enquiries_per_page = 10;
        if(!empty( $this->form_settings)){
            $form_settings = isset($this->form_settings['settings']) && !empty($this->form_settings['settings']) ? maybe_unserialize($this->form_settings['settings']) : array();
            $form_settings = !empty($form_settings) ? array_map('sanitize_text_field', $form_settings) : array();

            $enquiries_per_page = isset($form_settings['enquiries_per_page']) && !empty($form_settings['enquiries_per_page']) ? intval($form_settings['enquiries_per_page']) : 10;
        }

        $per_page = $enquiries_per_page;
        $current_page = $this->get_pagenum();

        $from_date = !empty($_GET['from_date']) ? sanitize_text_field($_GET['from_date']) : '';
        $to_date   = !empty($_GET['to_date'])   ? sanitize_text_field($_GET['to_date'])   : '';
        if (!empty($from_date) && !empty($to_date) && strtotime($from_date) > strtotime($to_date)) {
            add_settings_error('date_filter_error', 'invalid_date_range', esc_html__('Invalid date range: From Date is later than To Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        } else if (!empty($from_date) && empty($to_date)) {
            add_settings_error('date_filter_error', 'missing_to_date', esc_html__('Kindly select To Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        } else if (empty($from_date) && !empty($to_date)) {
            add_settings_error('date_filter_error', 'missing_from_date', esc_html__('Kindly select From Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        }
        $all_data = $this->get_data($from_date, $to_date);

        $total_items = count($all_data);

        // Pagination
        $paged_data = array_slice($all_data, ($current_page - 1) * $per_page, $per_page);

        $this->items = $paged_data;

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ]);

        $this->_column_headers = [$this->get_columns(), [], []];
    }

    /**
     * Retrieve export log data for the table.
     *
     * @param string $from_date Optional. Filter from date (Y-m-d).
     * @param string $to_date Optional. Filter to date (Y-m-d).
     * @return array Export log data.
     */
    public function get_data($from_date = "", $to_date = "") {
        $data = $this->obj->get_cfdb7_export_log($this->wpdb, $this->cf7_id, $from_date, $to_date);
        return $data;
    }

    /**
     * Display the date filter UI for the export logs table.
     */
    public function get_date_filters() {
        $filter_type = "export_filter";
        include CFDB7_PRO_PLUGIN_DIR . 'admin/partials/cfdb7_list_table_forms.php';
    }

    public function display() {
        include CFDB7_PRO_PLUGIN_DIR . 'admin/partials/cfdb7_display_table.php';
    }
}

$obj_data = array(
    'wpdb' => $wpdb,
    'obj' => $obj,
    'cf7_id' => $cf7_id,
    'context' => $context,
    'admin_page_url' => $admin_page_url,
    'nonce' => $nonce,
);
$table = new Custom_WP_List_Table($obj_data);
$table->prepare_items();
?>
<div class="wrap cfdb7-export-log">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Export Logs', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
    <div id="cfdb7-entries-ctas-container">
        <button class="reset-settings button"><?php echo esc_html__('Reset All', CFDB7_PRO_TEXT_DOMAIN); ?></button>
    </div>
    <div id="date-filter-container">
        <?php $table->get_date_filters(); ?>
    </div>
    <div id="wp-list-table-container">
        <form id="wp-list-table" method="get" action="<?php echo esc_url($admin_page_url); ?>" novalidate="novalidate">
            <input type="hidden" name="page" value="<?php echo esc_attr($context); ?>" />
            <input type="hidden" name="cf7-id" value="<?php echo esc_attr($cf7_id); ?>" />
            <?php $table->display(); ?>
        </form>
    </div>
</div>
<div id="popup-content" class="mfp-hide">
    <div class="logger-information-container">
    </div>
</div>