<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Main logic block for displaying the Contact Us page in the admin area.
 *
 * - Enqueues the contact us-specific stylesheet for proper UI styling.
 * - Renders a heading and embeds a Google Form via iframe for user contact submissions.
 * - Uses WordPress translation functions for all user-facing text.
 *
 * Coding Guide:
 * - Use wp_enqueue_style to load custom styles for admin pages.
 * - Always use esc_html__ for translatable strings and esc_html for output.
 * - Use semantic HTML and appropriate class names for styling.
 * - When embedding iframes, ensure the source is trusted and uses HTTPS.
 *
 * @since 1.0.0
*/

wp_enqueue_style( 'cfdb7_contact_us_style' );
?>
<div class="wrap cfdb7-contact-us">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Contact Us', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
    <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSelANdhHz5Uj8KMjBt3z9iGqrzZABX9X9oRCu3XW5xFJ1uNIQ/viewform"
        width="640" height="800" frameborder="0" marginheight="0" marginwidth="0">
    Loading…
</iframe>
</div>
