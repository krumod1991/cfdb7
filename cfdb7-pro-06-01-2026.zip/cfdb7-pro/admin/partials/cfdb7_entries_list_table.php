<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Render and manage the entries list table UI for Contact Form 7 submissions.
 *
 * This logic sets up the WP_List_Table for entries, handles pagination, filtering by date, field names, and search term,
 * column rendering, view actions, and bulk actions (delete, export). It verifies nonce for security, sanitizes all input/output,
 * and enqueues required styles/scripts for UI functionality. Also provides admin notices for error states and supports display settings customization.
 *
 * Coding Guide:
 * - Extend WP_List_Table for custom table functionality.
 * - Sanitize all input and output data.
 * - Use wp_nonce_field and wp_verify_nonce for security against CSRF.
 * - Use esc_html, esc_attr, and esc_url for safe output.
 * - Provide clear admin notices for error states.
 * - Enqueue required styles and scripts for UI and popup functionality.
 * - Support display settings, date, and search filters.
 * - Support bulk actions (delete, export).
 *
 * @since 1.0.0
 * @param object $wpdb WordPress database object.
 * @param object $obj Cfdb7_Queries object for database operations.
 * @param int $cf7_id Selected form ID for entries.
 * @param string $context Current admin page context.
 * @param array $user_info Current user info array.
 * @param string $delete_capability User delete capability status.
 * @param string $admin_page_url Admin page URL for actions.
 * @param string $nonce Nonce for security verification.
*/

if (!class_exists('WP_List_Table')) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

wp_enqueue_style('cfdb7_magnific_popup_style');
wp_enqueue_style('jquery-ui-css');
wp_enqueue_style('cfdb7_chosen_style');
wp_enqueue_style('cfdb7_dataTable_style_1');
wp_enqueue_style('cfdb7_dataTable_style_2');
wp_enqueue_script('cfdb7_magnific_popup_script');
wp_enqueue_script('jquery-ui-datepicker');
wp_enqueue_script('jquery-ui-sortable');
wp_enqueue_script('cfdb7_chosen_script');
wp_enqueue_script('cfdb7_dataTable_script_1');
wp_enqueue_script('cfdb7_dataTable_script_2');
wp_enqueue_script('cfdb7_dataTable_script_3');

/**
 * Class Custom_WP_List_Table
 *
 * Handles the display and management of deleted entries in the admin area for the Cfdb7 Pro plugin.
 * Extends the WP_List_Table class to provide custom table functionality for Contact Form 7 entries.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
*/
class Custom_WP_List_Table extends WP_List_Table {
    private $wpdb;
    private $obj;
    private $cf7_id;
    private $context;
    private $user_info;
    private $user_id;
    private $delete_capability;
    private $admin_page_url;
    private $nonce;
    private $form_settings = array();
    private $field_names = array();
    private $field_count_info = array();
    private $rename_fields = array();
    private $enable_fields = array();
    private $field_order = array();
    private $entries_count = 0;
    private $list_table_id = "cfdb7-entries";

    /**
     * Constructor for Custom_WP_List_Table.
     *
     * Initializes the table, sets up properties, and loads form settings and field names.
     *
     * @param array $obj_data Array containing wpdb, obj, user_info, and delete_capability.
     */
    public function __construct($obj_data) {
        parent::__construct([
            'singular' => 'item',
            'plural'   => 'items',
            'ajax'     => false
        ]);

        $user_info = $obj_data['user_info'];
        $this->wpdb = $obj_data['wpdb'];
        $this->obj = $obj_data['obj'];
        $this->cf7_id = $obj_data['cf7_id'];
        $this->context = $obj_data['context'];
        $this->user_info = $user_info;
		$this->user_id = $user_info['user_id'];
        $this->delete_capability = $obj_data['delete_capability'];
        $this->admin_page_url = $obj_data['admin_page_url'];
        $this->nonce = $obj_data['nonce'];

        $this->form_settings = $this->obj->get_cfdb7_form_setting($this->wpdb, $this->cf7_id);
        $this->field_names = $this->obj->get_cfdb7_report_field_name_options($this->wpdb, $this->cf7_id);

        $this->field_count_info = array();
        if(!empty($this->field_names)){
            foreach($this->field_names as $field){
                $field_name = isset($field['field_name']) && !empty($field['field_name']) ? sanitize_text_field($field['field_name']) : '';
                $entry_count = isset($field['entry_count']) && !empty($field['entry_count']) ? intval($field['entry_count']) : 0;
                
                $this->field_count_info[$field_name] = $entry_count;
            }
        }

        $display_settings = $this->obj->get_cfdb7_form_display_settings($this->wpdb, $this->cf7_id, $this->user_id, $this->context);
        
        $this->rename_fields = array();
        $this->enable_fields = array();
        $this->field_order = array();
        if(!empty($display_settings)){
            $saved_settings = isset($display_settings['settings']) && !empty($display_settings['settings']) ? maybe_unserialize($display_settings['settings']) : array();
            
            if(!empty($saved_settings)){
                $this->rename_fields = isset($saved_settings['rename_field']) && !empty($saved_settings['rename_field']) ? array_map('sanitize_text_field', $saved_settings['rename_field']) : array();

                $this->enable_fields = isset($saved_settings['enable_field']) && !empty($saved_settings['enable_field']) ? $saved_settings['enable_field'] : array();

                $this->field_order = isset($saved_settings['field_order']) && !empty($saved_settings['field_order']) ? array_map('sanitize_text_field', $saved_settings['field_order']) : array();
            }
        }
    }

    /**
     * Get the columns for the list table.
     *
     * @return array Columns to display in the table.
     */
    public function get_columns() {
        $columns = array();
        if($this->delete_capability == "exist"){
            $columns['cb'] = '<input type="checkbox" />';
        }
        $columns['lead_source'] = esc_html__('Lead Source', CFDB7_PRO_TEXT_DOMAIN);
        $columns['view_cta'] = esc_html__('View Entry', CFDB7_PRO_TEXT_DOMAIN);

        if(!empty($this->field_names)){
            $rename_fields = !empty($this->rename_fields) ? $this->rename_fields : array();
            $enable_fields = !empty($this->enable_fields) ? $this->enable_fields : array();
            $field_order = !empty($this->field_order) ? $this->field_order : array();

            $exclude_fields = array();
            if(!empty($field_order)){
                foreach ($field_order as $field_name) {
                    if($this->field_count_info[$field_name] > 0){
                        if(!empty($enable_fields)){
                            if(isset($enable_fields[$field_name])){
                                $columns[$field_name] = isset($rename_fields[$field_name]) && !empty($rename_fields[$field_name]) ? esc_html($rename_fields[$field_name]) : esc_html($field_name);
                            }
                        }else{
                            $columns[$field_name] = isset($rename_fields[$field_name]) && !empty($rename_fields[$field_name]) ? esc_html($rename_fields[$field_name]) : esc_html($field_name);
                        }   
                    }
                    $exclude_fields[] = esc_html($field_name);
                }
            }

            $current_fields = wp_list_pluck($this->field_names, 'field_name');
            if(!empty($current_fields)){
                $current_fields = array_map('sanitize_text_field', $current_fields);
                foreach($current_fields as $proceed_field_name){
                    if($this->field_count_info[$proceed_field_name] > 0){
                        if(!in_array($proceed_field_name, $exclude_fields)){
                            if(!empty($enable_fields)){
                                if(isset($enable_fields[$proceed_field_name])){
                                    $columns[$proceed_field_name] = isset($rename_fields[$proceed_field_name]) && !empty($rename_fields[$proceed_field_name]) ? esc_html($rename_fields[$proceed_field_name]) : esc_html($proceed_field_name);
                                }
                            }else{
                                $columns[$proceed_field_name] = isset($rename_fields[$proceed_field_name]) && !empty($rename_fields[$proceed_field_name]) ? esc_html($rename_fields[$proceed_field_name]) : esc_html($proceed_field_name);
                            }   
                        }   
                    }
                }
            }
        }
        $columns['submit_display_name'] = esc_html__('Submit By', CFDB7_PRO_TEXT_DOMAIN);
        $columns['submit_date_time'] = esc_html__('Submit Date Time', CFDB7_PRO_TEXT_DOMAIN);
        $columns['submit_ip_address'] = esc_html__('Submit Ip Address', CFDB7_PRO_TEXT_DOMAIN);
        return $columns;
    }

    /**
     * Render the checkbox column for bulk actions.
     *
     * @param array $item The current item.
     * @return string Checkbox HTML or empty string.
     */
    public function column_cb( $item ) {
        if($this->delete_capability == "exist"){
            return sprintf(
                '<input type="checkbox" name="ids[]" value="%s" />',
                esc_attr($item['ID'])
            );
        }else{
            return '';
        }
    }

    /**
     * Render the default column output.
     *
     * @param array $item The current item.
     * @param string $column_name The name of the column.
     * @return string The column output.
     */
    public function column_default($item, $column_name) {
        if(isset($item[$column_name])){
            switch ($column_name) {
                case 'lead_source':
                case 'submit_display_name':
                    return esc_html($item[$column_name]);
                case 'submit_date_time':
                    return date("d-m-Y H:i:s", strtotime(esc_html($item[$column_name])));
                case 'submit_ip_address':
                    return esc_html($item[$column_name]);
                default:
                    if (strpos($column_name, 'cfdb7_file') !== false) {
                        $uploaded_file_url = esc_url($item[$column_name]);
                        return $this->get_download_cta($uploaded_file_url);
                    }else{
                        return esc_html($item[$column_name]);
                    }
            }
        }else{
            switch ($column_name){
                case 'view_cta':
                    return $this->cfdb7_entry_ctas($item['ID'], $item);
                default:
                    return "";
            }
        }
    }

    /**
     * Render the View Entry button for a row.
     *
     * @param int $entry_id The entry ID.
     * @param array $item The current item.
     * @return void
     */
    public function cfdb7_entry_ctas($entry_id, $item) {
        echo '<input type="button" class="button cfdb7_entries_information" data-index="' . esc_attr($entry_id) . '" data-cf7_id="' . esc_attr($this->cf7_id) . '" value="' . esc_attr__('View', CFDB7_PRO_TEXT_DOMAIN) . '">';
    }

    /**
     * Render the download call-to-action link.
     *
     * @param string $uploaded_file_url The URL of the uploaded file.
     * @return void
     */
    private function get_download_cta($uploaded_file_url){
        echo '<a href="' . esc_url($uploaded_file_url) . '" download>' . esc_html__( 'Download', CFDB7_PRO_TEXT_DOMAIN) . '</a>';
    }

    /**
     * Get the available bulk actions for the table.
     *
     * @return array Bulk actions.
     */
    public function get_bulk_actions() {
        $bulk_actions = array(
            'delete' => esc_html__('Delete', CFDB7_PRO_TEXT_DOMAIN),
            'export' => esc_html__('Export', CFDB7_PRO_TEXT_DOMAIN)
        );
        $bulk_actions = array_map('sanitize_text_field', $bulk_actions);
        $bulk_actions = apply_filters('cfdb7_entries_bulk_actions', $bulk_actions);
        return $bulk_actions;
    }

    /**
     * Output message when no items are found.
     *
     * @return void
     */
    public function no_items() {
        echo esc_html__( 'No enquiries found.', CFDB7_PRO_TEXT_DOMAIN );
    }

    /**
     * Prepares the items for display in the entries list table, including pagination, filtering, and search.
     *
     * - Loads form settings for pagination and character limits.
     * - Sanitizes and validates all GET parameters for filtering and search.
     * - Handles date range validation and displays error messages for invalid input.
     * - Retrieves filtered data and paginates results for the current page.
     * - Truncates long field values and handles file fields with download links.
     * - Sets up table columns, pagination, and headers for WP_List_Table.
     * - Updates entries_count for export and UI display.
     *
     * @since 1.0.0
     *
     * Coding Guide:
     * - Always sanitize and validate all incoming GET data.
     * - Use esc_html, esc_attr, esc_url for output escaping.
     * - Use WordPress translation functions for all user-facing text.
     * - Handle file fields securely and provide download links with proper escaping.
     *
     * Security Practices:
     * - All output is properly escaped to prevent XSS.
    */
    public function prepare_items() {
        $enquiries_per_page = 10;
        $character_limit = 30;
        if(!empty( $this->form_settings)){
            $form_settings = isset($this->form_settings['settings']) && !empty($this->form_settings['settings']) ? maybe_unserialize($this->form_settings['settings']) : array();
            $form_settings = !empty($form_settings) ? array_map('sanitize_text_field', $form_settings) : array();

            $enquiries_per_page = isset($form_settings['enquiries_per_page']) && !empty($form_settings['enquiries_per_page']) ? intval($form_settings['enquiries_per_page']) : 10;

            $character_limit = isset($form_settings['character_limit']) && !empty($form_settings['character_limit']) ? intval($form_settings['character_limit']) : 30;
        }

        $per_page = $enquiries_per_page;
        $current_page = $this->get_pagenum();

        $from_date = !empty($_GET['from_date']) && !empty($_GET['from_date']) ? sanitize_text_field($_GET['from_date']) : '';
        $to_date   = !empty($_GET['to_date']) && !empty($_GET['to_date']) ? sanitize_text_field($_GET['to_date'])   : '';
        $field_names = isset($_GET['field_names']) && !empty($_GET['field_names']) ? $_GET['field_names'] : array();
		$field_names = array_map( 'sanitize_text_field', (array) $field_names );
        
		$search_value = isset($_GET['s']) ? sanitize_text_field(wp_unslash(trim($_GET['s']))) : '';

        if (!empty($from_date) && !empty($to_date) && strtotime($from_date) > strtotime($to_date)) {
            add_settings_error('date_filter_error', 'invalid_date_range', esc_html__('Invalid date range: From Date is later than To Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        } else if (!empty($from_date) && empty($to_date)) {
            add_settings_error('date_filter_error', 'missing_to_date', esc_html__('Kindly select To Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        } else if (empty($from_date) && !empty($to_date)) {
            add_settings_error('date_filter_error', 'missing_from_date', esc_html__('Kindly select From Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        }

        $search_input = array();
        if(!empty($from_date) || !empty($to_date) || !empty($field_names) || !empty($search_value)){
            $search_input = array(
                'from_date' => $from_date,
                'to_date'   => $to_date,
                'field_names' => $field_names,
                's' => $search_value,
            );
        }
        $all_data = $this->get_data($search_input);
        
        $total_items = count($all_data);
        $this->entries_count = $total_items;

        // Pagination
        $paged_data_before = array_slice($all_data, ($current_page - 1) * $per_page, $per_page);

        $paged_data_after = array();
        if(!empty($paged_data_before)){
            foreach($paged_data_before as $data){
                $entry_data = isset($data['form_submissions']) && !empty($data['form_submissions']) ? maybe_unserialize($data['form_submissions']) : array();
                $entry_data = array_map('sanitize_text_field', $entry_data);

                $form_submission_fields = isset($data['form_submission_fields']) && !empty($data['form_submission_fields']) ? maybe_unserialize($data['form_submission_fields']) : array();
                $form_submission_fields = array_map('sanitize_text_field', $form_submission_fields);

                $row = array(
                    'ID' => esc_html($data['entry_id']),
                    'lead_source' => esc_html($data['lead_source']),
                );
                if(!empty($this->field_names)){
                    $current_fields = wp_list_pluck($this->field_names, 'field_name');
                    if(!empty($current_fields)){
                        $current_fields = array_map('sanitize_text_field', $current_fields);
                    
                        foreach($current_fields as $field_key){
                            //Get field type of form fields
                            $field_type = isset($form_submission_fields[$field_key]) && !empty($form_submission_fields[$field_key]) ? $form_submission_fields[$field_key] : '';
                            if(!empty($field_type)){
                                if($field_type == "file"){
                                    $field_value = isset($entry_data[$field_key]) && !empty($entry_data[$field_key]) ? esc_url($entry_data[$field_key]) : '';
                                    if(filter_var($field_value, FILTER_VALIDATE_URL) !== false){
                                        $row[$field_key] = esc_url($field_value);
                                    }
                                }else{
                                    $field_value = isset($entry_data[$field_key]) && !empty($entry_data[$field_key]) ? esc_html(html_entity_decode($entry_data[$field_key])) : '';
                                    if(strlen($field_value) > $character_limit){
                                        $row[$field_key] = esc_html(substr($field_value, 0, $character_limit)).'...';
                                    }else{
                                        $row[$field_key] = esc_html($field_value);
                                    }
                                }
                            }
                        }
                    }
                }
                $row['submit_display_name'] = esc_html($data['submit_display_name']);
                $row['submit_date_time'] = date("d-m-Y H:i:s", strtotime(esc_html($data['submit_date_time'])));
                $row['submit_ip_address'] = esc_html($data['submit_ip_address']);
                $paged_data_after[] = $row;
            }
        }

        $this->items = $paged_data_after;

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ]);

        $this->_column_headers = [$this->get_columns(), [], []];
    }

    /**
     * Process bulk actions for the table (delete, export, etc.).
     *
     * @return void
     */
    public function process_bulk_action() {  
        //Proceed bulk on form submited      
        if(isset($_POST['bulk_action']) && !empty($_POST['bulk_action'])){
            $proceed_ids = array_map( 'intval', $_POST['ids'] );
            $action_data = array(
                'admin_page_url' => $this->admin_page_url,
                'proceed_ids' => $proceed_ids,
                'cf7_id' => $this->cf7_id,
                'user_info' => $this->user_info,
                'current_action' => $this->current_action(),
                'nonce' => isset($_POST['cfdb7_entries_nonce']) && !empty($_POST['cfdb7_entries_nonce']) ? sanitize_text_field($_POST['cfdb7_entries_nonce']) : '',
            );
            do_action('cfdb7_entries_proceed_bulk_action', $this->wpdb, $this->obj, $action_data);
        }
    }

    /**
     * Retrieve the data for the table, optionally filtered by search input.
     *
     * @param array $search_input Optional search/filter parameters.
     * @return array Data for the table.
     */
    public function get_data($search_input = array()) { 
        $data = $this->obj->get_cfdb7_form_entries($this->wpdb, $this->cf7_id, $search_input);
        return $data;
    }

    /**
     * Include the display settings filter partial.
     *
     * @return void
     */
    public function get_display_setting(){
        $filter_type = 'display_settings';
        include CFDB7_PRO_PLUGIN_DIR . 'admin/partials/cfdb7_list_table_forms.php';
    }

    /**
     * Include the search filter partial.
     *
     * @return void
     */
    public function get_search_filter(){
        $filter_type = "common_filter";
        include CFDB7_PRO_PLUGIN_DIR . 'admin/partials/cfdb7_list_table_forms.php';
    }

    public function get_entries_count(){
        return $this->entries_count;
    }

    public function display() {
        include CFDB7_PRO_PLUGIN_DIR . 'admin/partials/cfdb7_display_table.php';
    }
}


$obj_data = array(
    'wpdb' => $wpdb,
    'obj' => $obj,
    'cf7_id' => $cf7_id,
    'context' => $context,
    'user_info' => $user_info,
    'delete_capability' => $delete_capability,
    'admin_page_url' => $admin_page_url,
    'nonce' => $nonce,
);

$table = new Custom_WP_List_Table($obj_data);
$table->prepare_items();
//Proceed bulk action
$table->process_bulk_action();
?>
<div class="wrap cfdb7-entries-list-table">
	<h3><?php echo esc_html__('View Submissions', CFDB7_PRO_TEXT_DOMAIN); ?></h3>
	<div class="loader" style="display:none;">
        <div class="loader-icon"></div>
    </div>
	<div id="cfdb7-entries-ctas-container">
		<button class="display-settings button"><?php echo esc_html__('Display Settings', CFDB7_PRO_TEXT_DOMAIN); ?></button>
		<button class="export-all button"><?php echo esc_html__('Export All', CFDB7_PRO_TEXT_DOMAIN); ?></button>
        <button class="reset-settings button"><?php echo esc_html__('Reset All', CFDB7_PRO_TEXT_DOMAIN); ?></button>
	</div>
    <div id="cfdb7-entries-export-all-container" style="display:none;">
        <form id="cfdb7-entries-export-form" name="cfdb7-entries-export-all" method="POST" action="<?php echo esc_url($admin_page_url); ?>" novalidate="novalidate">
            <input type="hidden" name="action" value="export-all" />
            <input type="hidden" name="page" value="<?php echo esc_attr($context); ?>" />
			<input type="hidden" name="cf7-id" value="<?php echo esc_attr($cf7_id); ?>" />
            <input type="hidden" name="cfdb7_entries_count" value="<?php echo esc_attr($table->get_entries_count()); ?>" />
            <?php wp_nonce_field('cfdb7_entries_'.$cf7_id, 'cfdb7_entries_nonce'); ?>
            <input type="submit" name="cfdb7-entries-export-all" value="<?php echo esc_attr__('Export All', CFDB7_PRO_TEXT_DOMAIN); ?>"/>
        </form>
	</div>
	<div id="display-settings-container" style="display: none;">
		<?php $table->get_display_setting(); ?>
	</div>
	<div id="search-filter-container">
		<?php $table->get_search_filter(); ?>
	</div>
	<div id="wp-list-table-container">
		<form id="wp-list-table" method="POST" action="<?php echo esc_url($admin_page_url); ?>" novalidate="novalidate">
			<input type="hidden" name="page" value="<?php echo esc_attr($context); ?>" />
			<input type="hidden" name="cf7-id" value="<?php echo esc_attr($cf7_id); ?>" />
            <?php wp_nonce_field('cfdb7_entries_'.$cf7_id, 'cfdb7_entries_nonce'); ?>
			<?php $table->display(); ?>
		</form>
	</div>
</div>
<div id="popup-content" class="mfp-hide">
	<div class="entries-popup-container">
	</div>
</div>