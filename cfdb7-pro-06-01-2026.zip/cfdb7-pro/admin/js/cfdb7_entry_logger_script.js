jQuery(document).ready(function () {
    setTimeout(function(){
        new DataTable('#cfdb7-entries-logger', {
            responsive: true,
            pageLength: -1,      // show all records
            lengthChange: false, // remove entries-per-page dropdown
            paging: false,       // remove pagination controls
            searching: false,     // remove search box
            info: false          // remove "Showing X to Y of Z entries"
        });
    }, 300);

    jQuery("#cf7-id").change(function () {
        var cf7_id = jQuery(this).val();
        var nonce = jQuery("#entries_logger_page_nonce").val();
        var current_url = new URL(window.location.href);
        current_url.searchParams.delete('cf7-id');
        if (cf7_id != "" && nonce != "") {
            window.location = current_url + '&cf7-id=' + cf7_id + '&nonce=' + nonce;
        } else {
            window.location = current_url;
        }
    });

    if (jQuery('#from_date').length > 0 && jQuery('#to_date').length > 0) {
        jQuery('#from_date, #to_date').datepicker({
            dateFormat: 'dd-mm-yy'
        });
    }

    if (jQuery('#field_name').length > 0) {
        jQuery('#field_name').chosen({
            width: "100%",              // expand to full width of container (or set px)
            no_results_text: cfdb7_params.chosen_no_results, // text when filtering has no results
            placeholder_text_multiple: cfdb7_params.chosen_placeholder,
            search_contains: true,
        });
    }

    // Toggle display settings container with animation
    jQuery(document).on('click', '.display-settings', function () {
        jQuery('#display-settings-container').slideToggle(300);
        jQuery(this).toggleClass('active');
    });

    // Reset settings - reload page with only page and cf7-id params
    jQuery(document).on('click', '.reset-settings', function () {
        var currentUrl = new URL(window.location.href);
        var page = currentUrl.searchParams.get('page');
        var cf7Id = currentUrl.searchParams.get('cf7-id');
        var nonce = currentUrl.searchParams.get('nonce');

        var resetUrl = currentUrl.origin + currentUrl.pathname + '?page=' + page;
        if (cf7Id != "" && nonce != "") {
            resetUrl += '&cf7-id=' + cf7Id + '&nonce=' + nonce;
        }

        window.location.href = resetUrl;
    });

    jQuery(document).on('click', '.view-logger-cta', function () {
        jQuery(".logger-information-container").html('');
        var cf7_id = jQuery(this).data('cf7_id');
        var nonce = jQuery("#entries_logger_page_nonce").val();
        var index = jQuery(this).data('index');

        jQuery.ajax({
            url: cfdb7_params.ajax_url,
            method: 'post',
            data: {
                'action': 'cfdb7_get_entry_logger_information',
                'cf7_id': cf7_id,
                'nonce': nonce,
                'index': index,
            },
            beforeSend: function (xhr) {
                jQuery(".cfdb7-entries-logger .loader").css("display", 'flex');
            },
            success: function (content) {
                if (content != "") {
                    jQuery(".logger-information-container").html(content);
                    setTimeout(function () {
                        jQuery.magnificPopup.open({
                            items: {
                                src: '#popup-content'
                            },
                            type: 'inline',
                        });
                    }, 100);
                }
            },
            complete: function () {
                jQuery(".cfdb7-entries-logger .loader").css("display", 'none');
            },
            error: function () {
                jQuery(".cfdb7-entries-logger .loader").css("display", 'none');
            }
        });
    });
});