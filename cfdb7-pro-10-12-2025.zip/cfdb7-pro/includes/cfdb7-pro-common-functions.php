<?php

/**
 * Retrieve a list of Contact Form 7 forms.
 *
 * This function fetches all Contact Form 7 forms, or a specific form if an ID is provided.
 * It returns an array of WP_Post objects representing the forms.
 *
 * @param int|string $cf7_id  (Optional) The ID of a specific Contact Form 7 form to retrieve. Default is empty (all forms).
 * @return array              An array of WP_Post objects for the contact forms.
 *
 * Coding Guide:
 * - Always cast the form ID to an integer and validate before use.
 * - Use get_posts() with appropriate arguments to fetch forms.
 * - Return an empty array if no forms are found.
 *
 * @since    1.0.0
*/
function cfdb7_get_contact_forms_list($cf7_id = ""){
    $args = array(
        'post_type'      => 'wpcf7_contact_form',
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC', // or 'DESC' for descending
    );


    if(!empty($cf7_id)){
        $cf7_id = intval($cf7_id);
        if(!empty($cf7_id)){
            $args['include'] = $cf7_id;
        }
    }

    $forms_list = get_posts($args);

    return $forms_list;
}

/**
 * Retrieve all form tags for a given Contact Form 7 form.
 *
 * This function fetches and returns the parsed tags for a specific Contact Form 7 form.
 * Returns an empty array if the form does not exist.
 *
 * @param int $cf7_id  The ID of the Contact Form 7 form.
 * @return array       An array of tag objects for the form, or an empty array if not found.
 *
 * Coding Guide:
 * - Always cast the form ID to an integer and validate before use.
 * - Use WPCF7_ContactForm::get_instance() to retrieve the form object.
 * - Return an empty array if the form does not exist.
 *
 * @since    1.0.0
*/
function cfdb7_get_form_tags($cf7_id){
    $cf7_id = intval($cf7_id);
    // Get form by ID
    $form = WPCF7_ContactForm::get_instance($cf7_id);
    if (!$form) {
        return array(); // return empty array if form doesn't exist
    }
    // Parse tags
    return $form->scan_form_tags();
}

/**
 * Add the 'lead_source' column to the db7_forms table if it does not exist.
 *
 * This function checks for the existence of the 'lead_source' column in the db7_forms table
 * and adds it if missing. Used to track the source of form leads.
 *
 * Coding Guide:
 * - Always use $wpdb->prepare() for SQL queries to prevent SQL injection.
 * - Check for column existence before attempting to add it.
 * - Use VARCHAR(100) as the column type with a default empty value.
 *
 * @since    1.0.0
*/
function add_lead_source_column(){
    global $wpdb;
    $table_name = $wpdb->prefix . 'db7_forms';
    $column_name = 'lead_source';

    // Check if the column already exists
    $column_exists = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM `$table_name` LIKE %s",$column_name));

    if (empty($column_exists)){
        $wpdb->query("ALTER TABLE `$table_name` ADD `$column_name` VARCHAR(100) DEFAULT ''");
    }
}

/**
 * Create the basic settings and settings log tables for the plugin.
 *
 * This function checks for the existence of the cfdb7_settings and cfdb7_settings_log tables,
 * and creates them if they do not exist. These tables store form settings and their change logs.
 *
 * Coding Guide:
 * - Always use $wpdb->prefix for table names to ensure compatibility with different installations.
 * - Use dbDelta() for safe table creation and updates.
 * - Define appropriate data types and primary keys for all columns.
 * - Require the WordPress upgrade library before calling dbDelta().
 *
 * @since    1.0.0
*/
function cfdb7_generate_basic_tables(){
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    // Get all table names
    $tables = array_map('strtolower', $wpdb->get_col("SHOW TABLES"));

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $table_name1 = $wpdb->prefix.'cfdb7_settings';
    if(!in_array($table_name1, $tables)){
        $sql = "CREATE TABLE {$table_name1} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT(20),
            settings LONGTEXT,
            entry_by BIGINT(20) UNSIGNED,
            entry_display_name VARCHAR(50),
            entry_date_time DATETIME,
            entry_ip_address VARCHAR(100),
            PRIMARY KEY  (id)
        ) $charset_collate;";

        dbDelta($sql);
    }

    $table_name2 = $wpdb->prefix.'cfdb7_settings_log';
    if(!in_array($table_name2, $tables)){
        $sql = "CREATE TABLE {$table_name2} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT(20),
            settings LONGTEXT,
            entry_by BIGINT(20) UNSIGNED,
            entry_display_name VARCHAR(50),
            entry_date_time DATETIME,
            entry_ip_address VARCHAR(100),
            PRIMARY KEY  (id)
        ) $charset_collate;";

        dbDelta($sql);
    }
}

/**
 * Generate all necessary database tables for each Contact Form 7 form.
 *
 * This function creates a set of custom tables for each Contact Form 7 form found,
 * including tables for entries, submissions, field options, export logs, delete logs,
 * display settings, and entry logs. It checks for the existence of each table before
 * attempting to create it, ensuring no duplicates are made.
 *
 * @param int|string $cf7_id  (Optional) The ID of a specific Contact Form 7 form to process. Default is empty (all forms).
 *
 * Coding Guide:
 * - Always use $wpdb->prefix for table names to ensure multisite compatibility.
 * - Use dbDelta() for safe table creation and updates.
 * - Require the WordPress upgrade library before calling dbDelta().
 * - Check for table existence before attempting to create.
 * - Define appropriate data types and primary keys for all columns.
 * - Use cfdb7_get_contact_forms_list() to retrieve the list of forms.
 *
 * @since    1.0.0
*/
function cfdb7_generate_entries_table($cf7_id = ""){
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    // Get all table names
    $tables = $wpdb->get_col("SHOW TABLES");

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $forms_list = cfdb7_get_contact_forms_list($cf7_id);
    if(!empty($forms_list)){
        foreach($forms_list as $form){
            $form_id = $form->ID;

            $table_name1 = $wpdb->prefix.'cfdb7_entries_details_form_'.$form_id;
            if(!in_array($table_name1, $tables)){
                $sql = "CREATE TABLE {$table_name1} (
                    entry_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    db7_forms_id BIGINT(20) UNSIGNED,
                    lead_source VARCHAR(100),
                    form_submissions LONGTEXT,
                    form_submission_fields LONGTEXT,
                    submit_by BIGINT(20) UNSIGNED,
                    submit_display_name VARCHAR(50),
                    submit_date_time DATETIME,
                    submit_ip_address VARCHAR(100),
                    PRIMARY KEY  (entry_id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name2 = $wpdb->prefix.'cfdb7_entries_submission_form_'.$form_id;
            if(!in_array($table_name2, $tables)){
                $sql = "CREATE TABLE {$table_name2} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    entry_id BIGINT(20) UNSIGNED,
                    db7_forms_id BIGINT(20) UNSIGNED,
                    lead_source VARCHAR(100),
                    field_name VARCHAR(100),
                    field_type VARCHAR(50),
                    field_value LONGTEXT,
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name3 = $wpdb->prefix.'cfdb7_entries_field_name_options_form_'.$form_id;
            if(!in_array($table_name3, $tables)){
                $sql = "CREATE TABLE {$table_name3} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    field_name VARCHAR(100),
                    entry_count VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name4 = $wpdb->prefix.'cfdb7_export_logs_form_'.$form_id;
            if(!in_array($table_name4, $tables)){
                $sql = "CREATE TABLE {$table_name4} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    form_id BIGINT(20),
                    export_type VARCHAR(100),
                    export_file_path TEXT,
                    export_file_url TEXT,
                    export_by BIGINT(20) UNSIGNED,
                    export_display_name VARCHAR(50),
                    export_date_time DATETIME,
                    export_ip_address VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name5 = $wpdb->prefix.'cfdb7_delete_entries_logs_form_'.$form_id;
            if(!in_array($table_name5, $tables)){
                $sql = "CREATE TABLE {$table_name5} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    form_id BIGINT(20),
                    entry_id BIGINT(20),
                    db7_forms_id BIGINT(20) UNSIGNED,
                    lead_source VARCHAR(100),
                    form_submissions LONGTEXT,
                    form_submission_fields LONGTEXT,
                    submit_by BIGINT(20) UNSIGNED,
                    submit_display_name VARCHAR(50),
                    submit_date_time DATETIME,
                    submit_ip_address VARCHAR(100),
                    delete_by BIGINT(20) UNSIGNED,
                    delete_display_name VARCHAR(50),
                    delete_date_time DATETIME,
                    delete_ip_address VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name6 = $wpdb->prefix.'cfdb7_delete_entries_submission_form_'.$form_id;
            if(!in_array($table_name6, $tables)){
                $sql = "CREATE TABLE {$table_name6} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    entry_id BIGINT(20) UNSIGNED,
                    db7_forms_id BIGINT(20) UNSIGNED,
                    lead_source VARCHAR(100),
                    field_name VARCHAR(100),
                    field_type VARCHAR(50),
                    field_value LONGTEXT,
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name7 = $wpdb->prefix.'cfdb7_delete_entries_field_name_options_form_'.$form_id;
            if(!in_array($table_name7, $tables)){
                $sql = "CREATE TABLE {$table_name7} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    field_name VARCHAR(100),
                    entry_count VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name8 = $wpdb->prefix.'cfdb7_display_settings_form_'.$form_id;
            if(!in_array($table_name8, $tables)){
                $sql = "CREATE TABLE {$table_name8} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id VARCHAR(100),
                    context VARCHAR(100),
                    settings LONGTEXT,
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name9 = $wpdb->prefix.'cfdb7_entries_logs_form_'.$form_id;
            if(!in_array($table_name9, $tables)){
                $sql = "CREATE TABLE {$table_name9} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    lead_source VARCHAR(100),
                    form_setting LONGTEXT,
                    db7_forms_id BIGINT(20) UNSIGNED,
                    original_entry LONGTEXT,
                    original_entry_fields LONGTEXT,
                    form_entry LONGTEXT,
                    proceed_entry LONGTEXT,
                    proceed_entry_fields LONGTEXT,
                    entry_id BIGINT(20) UNSIGNED,
                    entry_details LONGTEXT,
                    display_name VARCHAR(50),
                    date_time DATETIME,
                    ip_address VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name10 = $wpdb->prefix.'cfdb7_entries_logs_submission_form_'.$form_id;
            if(!in_array($table_name10, $tables)){
                $sql = "CREATE TABLE {$table_name10} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    entry_id BIGINT(20) UNSIGNED,
                    db7_forms_id BIGINT(20) UNSIGNED,
                    lead_source VARCHAR(100),
                    field_name VARCHAR(100),
                    field_type VARCHAR(50),
                    field_value LONGTEXT,
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name11 = $wpdb->prefix.'cfdb7_entries_logs_field_name_options_form_'.$form_id;
            if(!in_array($table_name11, $tables)){
                $sql = "CREATE TABLE {$table_name11} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    field_name VARCHAR(100),
                    entry_count VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }
        }
    }
}

/**
 * Retrieve information about the currently logged-in user.
 *
 * This function returns an array containing the user's capabilities, display name,
 * and user ID. If no user is logged in, it returns empty values for each field.
 * Adds "manage_options" to capabilities if the user is an administrator.
 *
 * @return array {
 *     @type array  $capabilities  List of user capabilities.
 *     @type string $display_name  The display name of the user.
 *     @type int|string $user_id   The user ID, or empty string if not logged in.
 * }
 *
 * Coding Guide:
 * - Use get_current_user_id() to retrieve the current user.
 * - Always sanitize output using esc_attr() for display names.
 * - Check for administrator role and append "manage_options" if applicable.
 * - Return an array with empty values if no user is logged in.
 *
 * @since    1.0.0
*/
function cfdb7_get_logged_in_user_info(){
    $user_id = get_current_user_id();
    if(!empty($user_id)){
        $subject = new WP_User($user_id);   

        $all_capabilities = $subject->allcaps;
        $all_capabilities = !empty($all_capabilities) ? $all_capabilities : array();

        $is_administrator = false; 
        if ( current_user_can('administrator') ){
            $all_capabilities[] = "manage_options";
        }
	    return array('capabilities' => $all_capabilities, 'display_name' => esc_attr($subject->data->display_name), 'user_id' => $user_id) ;
    }else{  
	    return array('capabilities' => "", 'display_name' => "", 'user_id' => "") ;
    }
}

/**
 * Retrieve the IP address of the current user.
 *
 * This function attempts to get the user's IP address, first checking the
 * HTTP_X_FORWARDED_FOR header (for proxies), then falling back to REMOTE_ADDR.
 * It validates and sanitizes the IP address before returning it.
 *
 * @return string The sanitized IP address of the user, or an empty string if not found.
 *
 * Coding Guide:
 * - Always validate the IP address using rest_is_ip_address().
 * - Sanitize the IP address with sanitize_text_field() before returning.
 * - Prefer HTTP_X_FORWARDED_FOR for proxy support, fallback to REMOTE_ADDR.
 * - Return an empty string if no valid IP address is found.
 *
 * @since    1.0.0
*/
function cfdb7_get_ip_address(){
    $ip_address = isset($_SERVER['HTTP_X_FORWARDED_FOR']) && !empty(rest_is_ip_address($_SERVER['HTTP_X_FORWARDED_FOR'])) ?  sanitize_text_field($_SERVER['HTTP_X_FORWARDED_FOR']) : "";

    if(empty($ip_address)){
        $ip_address = isset($_SERVER['REMOTE_ADDR']) && !empty(rest_is_ip_address($_SERVER['REMOTE_ADDR'])) ?  sanitize_text_field($_SERVER['REMOTE_ADDR']) : "";
    }

    return $ip_address;
}

/**
 * Retrieve and sanitize form settings for a specific Contact Form 7 form.
 *
 * This function fetches the serialized settings for a given form, unserializes them,
 * and extracts key options such as duplicate submission prevention, the field to check,
 * and fields to exclude. All values are sanitized before being returned.
 *
 * @param wpdb   $wpdb         The WordPress database object.
 * @param object $obj          The object providing the get_cfdb7_form_setting() method.
 * @param int    $form_post_id The ID of the Contact Form 7 form.
 * @return array {
 *     @type string $avoid_duplicate_submission  Whether to avoid duplicate submissions ("on" or "").
 *     @type string $avoid_field                 The field name to check for duplicates.
 *     @type array  $excludes_fields             Array of field names to exclude from processing.
 * }
 *
 * Coding Guide:
 * - Always sanitize all settings before returning.
 * - Use maybe_unserialize() to handle serialized settings.
 * - Return default empty values if settings are missing.
 * - Ensure compatibility with the expected structure of the settings array.
 *
 * @since    1.0.0
*/
function cfdb7_get_form_setting($wpdb, $obj, $form_post_id){
    $form_setting = $obj->get_cfdb7_form_setting($wpdb, $form_post_id);
    $form_setting = isset($form_setting['settings']) && !empty($form_setting['settings']) ? maybe_unserialize($form_setting['settings']) : array();

    $avoid_duplicate_submission = "";
    $avoid_field = "";
    $excludes_fields = "";
    if(!empty($form_setting)){
        $avoid_duplicate_submission = isset($form_setting['avoid_duplicate_submission']) && !empty($form_setting['avoid_duplicate_submission']) ? sanitize_text_field($form_setting['avoid_duplicate_submission']) : "";

        $avoid_field = isset($form_setting['avoid_field']) && !empty($form_setting['avoid_field']) ? sanitize_text_field($form_setting['avoid_field']) : "";

        $excludes_fields = isset($form_setting['excludes_fields']) && !empty($form_setting['excludes_fields']) ? array_map('sanitize_text_field', $form_setting['excludes_fields']) : array();
    }

    return array('avoid_duplicate_submission' => $avoid_duplicate_submission, 'avoid_field' => $avoid_field, 'excludes_fields' => $excludes_fields);
}

/**
 * Apply form settings to submitted field data for a Contact Form 7 form.
 *
 * This function processes the submitted field data according to the form's settings:
 * - Removes fields specified in the excludes list.
 * - Prevents duplicate submissions based on a specific field if enabled.
 * - Removes the 'cfdb7_status' field if present.
 * All relevant values are sanitized before processing.
 *
 * @param array  $field_data   The submitted form field data.
 * @param array  $form_setting The settings array for the form (avoid duplicate, excludes, etc).
 * @param int    $cf7_id       The Contact Form 7 form ID.
 * @param object $obj          The object providing the check_Cfdb7_submission() method.
 * @param wpdb   $wpdb         The WordPress database object.
 * @return array The processed and sanitized field data after applying settings.
 *
 * Coding Guide:
 * - Always sanitize all input and settings before use.
 * - Remove excluded fields and prevent duplicate submissions as configured.
 * - Remove the 'cfdb7_status' field if present.
 * - Return the modified field data array.
 *
 * @since    1.0.0
*/
function cfdb7_form_data_after_applied_settings($field_data, $form_setting, $cf7_id, $obj, $wpdb){
    $cfdb7_avoid_duplicate_submission = isset($form_setting['avoid_duplicate_submission']) && !empty($form_setting['avoid_duplicate_submission']) ? sanitize_text_field($form_setting['avoid_duplicate_submission']) : "";

    $cfdb7_avoid_field = isset($form_setting['avoid_field']) && !empty($form_setting['avoid_field']) ? sanitize_text_field($form_setting['avoid_field']) : "";

    $cfdb7_excludes_fields = isset($form_setting['excludes_fields']) && !empty($form_setting['excludes_fields']) ? array_map('sanitize_text_field', $form_setting['excludes_fields']) : array();

    if($cfdb7_avoid_duplicate_submission == "on" && !empty($cfdb7_avoid_field)){
        $field_value = isset($field_data[$cfdb7_avoid_field]) && !empty($field_data[$cfdb7_avoid_field]) ? sanitize_text_field($field_data[$cfdb7_avoid_field]) : "";
        if(!empty($field_value)){
            $submitted_data = $obj->check_Cfdb7_submission($wpdb, $cf7_id, $cfdb7_avoid_field, $field_value);
            if(!empty($submitted_data)){
                $field_data = array();
            }
        }
    }

    if(!empty($cfdb7_excludes_fields) && !empty($field_data)){
        $submission_names = array_map('sanitize_text_field', array_keys($field_data));
        foreach($cfdb7_excludes_fields as $excludes_field){
            $excludes_field = sanitize_text_field($excludes_field);
            if(in_array($excludes_field, $submission_names)){
                unset($field_data[$excludes_field]);
            }
        }   
    }

    if(isset($field_data['cfdb7_status'])){
        unset($field_data['cfdb7_status']);
    }
    
    return $field_data;
}

/**
 * Save or update report field name options and their counts for a form.
 *
 * This function iterates over the provided field names, retrieves their current count
 * from the database, and either updates or inserts the count for both the main and log
 * report field name options tables. All field names and counts are sanitized before use.
 *
 * @param array  $field_names  Array of field names to process.
 * @param int    $cf7_id       The Contact Form 7 form ID.
 * @param object $obj          The object providing the report field name methods.
 * @param wpdb   $wpdb         The WordPress database object.
 *
 * Coding Guide:
 * - Always sanitize all field names and IDs before use.
 * - Use the object's methods to get, update, or insert field name options and counts.
 * - Process both main and log report field name options for each field.
 * - Skip processing if $field_names is empty.
 *
 * @since    1.0.0
*/
function cfdb7_save_report_field_for_field_name_options($field_names, $cf7_id, $obj, $wpdb){
    if(!empty($field_names)){
        $cf7_id = intval($cf7_id); // sanitize ID

        foreach($field_names as $field_name){
            $field_name = sanitize_text_field($field_name); // sanitize each field name

            $field_info = $obj->get_cfdb7_report_field_name_options_count($wpdb, $cf7_id, $field_name);
            if(!empty($field_info)){
                $field_option_info = $obj->get_cfdb7_report_field_name_options($wpdb, $cf7_id, $field_name);

                $safe_field_name = sanitize_text_field($field_info[0]['field_name']);
                $count = intval($field_info[0]['count']);

                if(!empty($field_option_info)){
                    $obj->update_cfdb7_report_field_name_options($wpdb, $cf7_id, $safe_field_name, $count);
                }else{
                    $obj->save_cfdb7_report_field_name_options($wpdb, $cf7_id, $safe_field_name, $count);
                }
            }

            $log_field_info = $obj->get_cfdb7_log_report_field_name_options_count($wpdb, $cf7_id, $field_name);
            if(!empty($log_field_info)){
                $field_option_info = $obj->get_cfdb7_log_report_field_name_options($wpdb, $cf7_id, $field_name);
                
                $safe_field_name = sanitize_text_field($log_field_info[0]['field_name']);
                $count = intval($log_field_info[0]['count']);

                if(!empty($field_option_info)){
                    $obj->update_cfdb7_log_report_field_name_options($wpdb, $cf7_id, $safe_field_name, $count);
                }else{
                    $obj->save_cfdb7_log_report_field_name_options($wpdb, $cf7_id, $safe_field_name, $count);
                }
            }
        }
    }
}

/**
 * Sanitize all keys and values in the submitted field data array.
 *
 * This function sanitizes each key using sanitize_text_field() and each value using
 * sanitize_textarea_field(). If a value is an array, it sanitizes each element and
 * concatenates them into a comma-separated string. This helps prevent JS injection
 * and ensures all data is safe for storage or display.
 *
 * @param array $field_data  The associative array of submitted field data.
 * @return array             The sanitized field data array.
 *
 * Coding Guide:
 * - Always sanitize both keys and values before further processing or storage.
 * - Use sanitize_text_field() for keys and sanitize_textarea_field() for values.
 * - If a value is an array, sanitize each element and join with a comma.
 * - Return an empty array if $field_data is empty.
 *
 * @since    1.0.0
*/
function cfdb7_sanitize_field_data($field_data){
    $sanitized_data = array();
    if(!empty($field_data)){
        foreach($field_data as $key => $value){
            $sanitized_key = sanitize_text_field($key);
            //It is prevent JS injection
            if(is_array($value)){
                $value = array_map('sanitize_textarea_field', $value);
                $value = implode(", ", $value);
                $sanitized_data[$sanitized_key] = $value;
            }else{
                $sanitized_data[$sanitized_key] = sanitize_textarea_field($value);
            }
        }
    }
    return $sanitized_data;
}

/**
 * Map each field name to its type based on Contact Form 7 tags.
 *
 * This function iterates over the submitted field data and assigns a field type
 * for each field using the provided CF7 tags array. If a field type is not found,
 * it defaults to 'text'. All field names and types are sanitized.
 *
 * @param array $field_data  The associative array of submitted field data.
 * @param array $cf7_tags    The associative array mapping field names to field types.
 * @return array             An array mapping field names to their types.
 *
 * Coding Guide:
 * - Always sanitize field names and types before use.
 * - Default the field type to 'text' if not specified in $cf7_tags.
 * - Return an empty array if $field_data is empty or not an array.
 *
 * @since    1.0.0
*/
function cfdb7_form_data_after_applied_field_type($field_data, $cf7_tags){
    $entry_fields = array();
    if(!empty($field_data) && is_array($field_data)){
        foreach($field_data as $field_name => $field_value){
            $field_name = sanitize_text_field($field_name);
            if(strstr($field_name, 'cfdb7_file')){
                $entry_fields[$field_name] = "file";
            }else{
                // Get field type from CF7 tags, default to 'text' if not found
                $entry_fields[$field_name] = isset($cf7_tags[$field_name]) && !empty($cf7_tags[$field_name]) ? sanitize_text_field($cf7_tags[$field_name]) : "text";
            }
        }
    }
    return $entry_fields;
}

/**
 * Save a form entry and its submissions to the database for a Contact Form 7 form.
 *
 * This function processes and saves the main entry details and each field submission
 * for a given form. It also handles logging of original field data, applies field type
 * mapping, and triggers the 'cfdb7_after_save_entry' action after saving.
 * All data is sanitized before being stored.
 *
 * @param wpdb   $wpdb        The WordPress database object.
 * @param object $obj         The object providing save and log methods for entries.
 * @param array  $cfdb7_data  The associative array containing all entry and form data.
 * @return array              An array with the entry ID, entry details, and processed field types.
 *
 * Coding Guide:
 * - Always sanitize all input data before saving to the database.
 * - Use cfdb7_form_data_after_applied_field_type() to map field types.
 * - Save both the main entry and each field submission, including logs for original data.
 * - Use array_fill() to set the format for database insertion.
 * - Trigger the 'cfdb7_after_save_entry' action after saving.
 * - Return an array with the entry ID, entry details, and field type mapping.
 *
 * @since    1.0.0
*/
function cfdb7_proceed_save_entry($wpdb, $obj, $cfdb7_data){
    $result = array();

    $field_data = isset($cfdb7_data['field_data']) && !empty($cfdb7_data['field_data']) ? $cfdb7_data['field_data'] : array();

    $cf7_tags = isset($cfdb7_data['cf7_tags']) && !empty($cfdb7_data['cf7_tags']) ? $cfdb7_data['cf7_tags'] : array();

    $cf7_id = isset($cfdb7_data['cf7_id']) && !empty($cfdb7_data['cf7_id']) ? intval($cfdb7_data['cf7_id']) : "";

    $db7_forms_id = isset($cfdb7_data['db7_forms_id']) && !empty($cfdb7_data['db7_forms_id']) ? intval($cfdb7_data['db7_forms_id']) : "";

    $form_date = isset($cfdb7_data['form_date']) && !empty($cfdb7_data['form_date']) ? $cfdb7_data['form_date'] : "";

    $lead_source = isset($cfdb7_data['lead_source']) && !empty($cfdb7_data['lead_source']) ? sanitize_text_field($cfdb7_data['lead_source']) : "";

    $user_id = isset($cfdb7_data['user_id']) && !empty($cfdb7_data['user_id']) ? intval($cfdb7_data['user_id']) : "";

    $display_name = isset($cfdb7_data['display_name']) && !empty($cfdb7_data['display_name']) ? sanitize_text_field($cfdb7_data['display_name']) : "";
    
    $ip_address = isset($cfdb7_data['ip_address']) && !empty($cfdb7_data['ip_address']) ? sanitize_text_field($cfdb7_data['ip_address']) : "";
    
    $original_field_data = isset($cfdb7_data['original_field_data']) && !empty($cfdb7_data['original_field_data']) ? $cfdb7_data['original_field_data'] : array();

    //Apply field type processing
	$proceed_entry_fields =  cfdb7_form_data_after_applied_field_type($field_data, $cf7_tags);
   
	$result['proceed_entry_fields'] = $proceed_entry_fields;

    if(!empty($field_data)){
        $upload_dir    = wp_upload_dir();
        $cfdb7_dir_url = $upload_dir['baseurl'].'/cfdb7_uploads';
        //Save entry to cfdb7 pro
        $entry_details = array(
            'db7_forms_id' => $db7_forms_id,
            'lead_source' => $lead_source,
            'form_submissions' => maybe_serialize($field_data),
            'form_submission_fields' => maybe_serialize($proceed_entry_fields),
            'submit_by' => $user_id,
            'submit_display_name' => $display_name,
            'submit_date_time' => $form_date,
            'submit_ip_address' => $ip_address,
        );

        $entry_details_format = array_fill(0, count($entry_details), '%s');

		$entry_id = $obj->save_cfdb7_entry($wpdb, $cf7_id, $entry_details, $entry_details_format);

		$result['entry_id'] = $entry_id;
		$result['entry_details'] = $entry_details;

        if (!empty($entry_id)){
            foreach($field_data as $field_name => $field_value){
                $field_name = sanitize_text_field($field_name);
                //It is prevent JS injection
                $field_value = sanitize_textarea_field(trim($field_value));

                $field_type = isset($cf7_tags[$field_name]) && !empty($cf7_tags[$field_name]) ? sanitize_text_field($cf7_tags[$field_name]) : "text";
                if($field_type == "file"){
                    $field_value = $cfdb7_dir_url."/".$field_value;
                }

                $entry_submission = array(
                    'entry_id' => $entry_id,
                    'db7_forms_id' => $db7_forms_id,
                    'lead_source' => $lead_source,
                    'field_name' => $field_name,
                    'field_type' => $field_type,
                    'field_value' => $field_value,
                );
                $entry_submission_format = array_fill(0, count($entry_submission), '%s');
                $obj->save_cfdb7_entry_submissions($wpdb, $cf7_id, $entry_submission, $entry_submission_format);
            }

            foreach($original_field_data as $original_field_name => $original_field_value){
                $original_field_name = sanitize_text_field($original_field_name);
                //It is prevent JS injection
                $original_field_value = sanitize_textarea_field(trim($original_field_value));

                $original_field_type = isset($cf7_tags[$original_field_name]) && !empty($cf7_tags[$original_field_name]) ? sanitize_text_field($cf7_tags[$original_field_name]) : "text";
                if($original_field_type == "file"){
                    $original_field_value = $cfdb7_dir_url."/".$original_field_value;
                }

                $entry_submission = array(
                    'entry_id' => $entry_id,
                    'db7_forms_id' => $db7_forms_id,
                    'lead_source' => $lead_source,
                    'field_name' => $original_field_name,
                    'field_type' => $original_field_type,
                    'field_value' => $original_field_value,
                );
                $entry_submission_format = array_fill(0, count($entry_submission), '%s');
                $obj->save_cfdb7_log_submissions($wpdb, $cf7_id, $entry_submission, $entry_submission_format);
            }

            $after_entry = array(
                'entry_details' => $entry_details,
                'entry_id' => $entry_id,
                'db7_forms_id' => $db7_forms_id,
                'cf7_id' => $cf7_id,
                'cf7_tags' => $cf7_tags,
                'original_field_data' => $original_field_data,
                'obj' => $obj,
                'wpdb' => $wpdb,
            );
            do_action( 'cfdb7_after_save_entry', $after_entry);
        }
    }
    return $result;
}

?>