<?php

/**
 * Fired during plugin activation
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/includes
*/
class Cfdb7_Queries {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	*/
	private $cfdb7_settings;
	private $cfdb7_settings_log;
	private $cfdb7_db;

	private $cfdb7_entries_details;
	private $cfdb7_entries_submissions;
	private $cfdb7_entries_field_name_options;

	private $cfdb7_delete_entries_log;
	private $cfdb7_delete_entries_submissions;
	private $cfdb7_delete_entries_field_name_options;

	private $cfdb7_entries_log;
	private $cfdb7_entries_submissions_log;
	private $cfdb7_entries_field_name_options_log;

	private $cfdb7_display_settings;
	private $cfdb7_export_log;
	
	/**
	 * Initialize all table name properties for the plugin.
	 *
	 * Sets up the class properties for all database table names used by the plugin,
	 * including settings, logs, entries, submissions, field options, display settings, and export logs.
	 *
	 * Coding Guide:
	 * - Use this method in the constructor or during setup to ensure all table names are available.
	 * - Table names use {form_id} as a placeholder for dynamic form-specific tables.
	 *
	 * @since    1.0.0
	*/
	public function init_cfdb7_tables(){
		$this->cfdb7_settings = 'cfdb7_settings';
		$this->cfdb7_settings_log = 'cfdb7_settings_log';
		$this->cfdb7_db = 'db7_forms';

		$this->cfdb7_entries_details = 'cfdb7_entries_details_form_{form_id}';
		$this->cfdb7_entries_submissions = 'cfdb7_entries_submission_form_{form_id}';
		$this->cfdb7_entries_field_name_options = 'cfdb7_entries_field_name_options_form_{form_id}';

		$this->cfdb7_delete_entries_log = 'cfdb7_delete_entries_logs_form_{form_id}';
		$this->cfdb7_delete_entries_submissions = 'cfdb7_delete_entries_submission_form_{form_id}';
		$this->cfdb7_delete_entries_field_name_options = 'cfdb7_delete_entries_field_name_options_form_{form_id}';

		$this->cfdb7_entries_log = 'cfdb7_entries_logs_form_{form_id}';
		$this->cfdb7_entries_submissions_log = 'cfdb7_entries_logs_submission_form_{form_id}';
		$this->cfdb7_entries_field_name_options_log = 'cfdb7_entries_logs_field_name_options_form_{form_id}';
		
		$this->cfdb7_display_settings = 'cfdb7_display_settings_form_{form_id}';
		$this->cfdb7_export_log = 'cfdb7_export_logs_form_{form_id}';
	}

	/**
	 * Retrieve the settings row for a specific Contact Form 7 form.
	 *
	 * @param wpdb $wpdb      The WordPress database object.
	 * @param int  $form_id   The ID of the Contact Form 7 form.
	 * @return array|null     The settings row as an associative array, or null if not found.
	 *
	 * Coding Guide:
	 * - Use $wpdb->prepare() for safe SQL queries.
	 * - Returns ARRAY_A for associative array output.
	 *
	 * @since    1.0.0
	*/
	public function get_cfdb7_form_setting($wpdb, $form_id) {
		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}{$this->cfdb7_settings} where form_id=%d", $form_id), ARRAY_A );
	}

	/**
	 * Insert a new settings row for a Contact Form 7 form.
	 *
	 * @param wpdb  $wpdb    The WordPress database object.
	 * @param array $data    The associative array of settings data to insert.
	 * @param array $format  The array of format strings for each column.
	 * @return int           The ID of the newly inserted row.
	 *
	 * Coding Guide:
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Return $wpdb->insert_id for the new row's ID.
	 *
	 * @since    1.0.0
	*/
	public function save_cfdb7_form_setting($wpdb, $data, $format) {
		$table_name = "{$wpdb->prefix}{$this->cfdb7_settings}";
		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Update an existing settings row for a Contact Form 7 form.
	 *
	 * @param wpdb  $wpdb          The WordPress database object.
	 * @param array $data          The associative array of settings data to update.
	 * @param array $format        The array of format strings for each column in $data.
	 * @param array $where         The associative array of WHERE conditions for the update.
	 * @param array $where_format  The array of format strings for each WHERE condition.
	 * @return int|false           The number of rows updated, or false on error.
	 *
	 * Coding Guide:
	 * - Use $wpdb->update() for safe data updates.
	 * - Ensure $data and $where arrays are properly sanitized and validated before calling.
	 * - Returns the number of rows affected, or false if the update fails.
	 *
	 * @since    1.0.0
	*/
	public function update_cfdb7_form_setting($wpdb, $data, $format, $where, $where_format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_settings}";
		return $wpdb->update($table_name, $data, $where, $format, $where_format);
	}

	/**
	 * Insert a new settings log row for a Contact Form 7 form.
	 *
	 * @param wpdb  $wpdb    The WordPress database object.
	 * @param array $data    The associative array of log data to insert.
	 * @param array $format  The array of format strings for each column.
	 * @return int           The ID of the newly inserted log row.
	 *
	 * Coding Guide:
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Return $wpdb->insert_id for the new log row's ID.
	 * - Ensure $data is properly sanitized before insertion.
	 *
	 * @since    1.0.0
	*/
	public function save_cfdb7_setting_log($wpdb, $data, $format) {
		$table_name = "{$wpdb->prefix}{$this->cfdb7_settings_log}";
		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Insert a new entry row into the main db7_forms table.
	 *
	 * @param wpdb  $wpdb    The WordPress database object.
	 * @param array $data    The associative array of entry data to insert.
	 * @param array $format  The array of format strings for each column.
	 * @return int           The ID of the newly inserted entry row.
	 *
	 * Coding Guide:
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Return $wpdb->insert_id for the new entry's ID.
	 * - Ensure $data is properly sanitized before insertion.
	 *
	 * @since    1.0.0
	*/
	public function save_db7_forms_entry($wpdb, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_db}";
		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Insert a new entry row into the form-specific entries details table.
	 *
	 * @param wpdb  $wpdb     The WordPress database object.
	 * @param int   $form_id  The ID of the Contact Form 7 form.
	 * @param array $data     The associative array of entry data to insert.
	 * @param array $format   The array of format strings for each column.
	 * @return int            The ID of the newly inserted entry row.
	 *
	 * Coding Guide:
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Return $wpdb->insert_id for the new entry's ID.
	 * - Ensure $data is properly sanitized before insertion.
	 *
	 * @since    1.0.0
	*/
	public function save_cfdb7_entry($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}
	
	/**
	 * Insert a new entry row into the form-specific entries submissions table.
	 *
	 * @param wpdb  $wpdb     The WordPress database object.
	 * @param int   $form_id  The ID of the Contact Form 7 form.
	 * @param array $data     The associative array of submission data to insert.
	 * @param array $format   The array of format strings for each column.
	 * @return int            The ID of the newly inserted submission row.
	 *
	 * Coding Guide:
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Return $wpdb->insert_id for the new submission's ID.
	 * - Ensure $data is properly sanitized before insertion.
	 *
	 * @since    1.0.0
	*/
	public function save_cfdb7_entry_submissions($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Retrieve all available Contact Form 7 post IDs from the main db7_forms table.
	 *
	 * @param wpdb $wpdb  The WordPress database object.
	 * @return array      Array of available form post IDs as associative arrays.
	 *
	 * Coding Guide:
	 * - Use SELECT DISTINCT to get unique form_post_id values.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for listing all forms with entries in the database.
	 *
	 * @since    1.0.0
	*/
	public function get_db7_available_form_post_ids($wpdb){
		$main_table    = "{$wpdb->prefix}{$this->cfdb7_db}";

		return $wpdb->get_results("SELECT DISTINCT(`form_post_id`) as form_ids FROM {$main_table}", ARRAY_A);
	}

	
	/**
	 * Get the count of entries for a specific Contact Form 7 form, optionally excluding deleted entries.
	 *
	 * @param wpdb $wpdb                The WordPress database object.
	 * @param int  $form_id             The ID of the Contact Form 7 form.
	 * @param int  $delete_entries_count The number of deleted entries to consider (if > 0, exclude deleted entries).
	 * @return array                    Associative array with the count of entries.
	 *
	 * Coding Guide:
	 * - Uses LEFT JOIN to count entries not present in the details table.
	 * - If $delete_entries_count > 0, excludes entries found in the delete log table.
	 * - Returns ARRAY_A for associative array output.
	 * - Use $wpdb->prepare() for safe SQL queries.
	 *
	 * @since    1.0.0
	*/
	public function get_db7_forms_entries_count($wpdb, $form_id, $delete_entries_count){
		$main_table    = "{$wpdb->prefix}{$this->cfdb7_db}";
		$details_table = str_replace("{form_id}", $form_id, "{$wpdb->prefix}{$this->cfdb7_entries_details}");

		if($delete_entries_count > 0){
			$deleted_table = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";

			$sql = "SELECT count(m.form_id) as count FROM {$main_table} AS m LEFT JOIN {$details_table} AS d ON m.form_id = d.db7_forms_id WHERE m.form_post_id = %d AND d.db7_forms_id IS NULL AND m.form_id NOT IN (SELECT entry_id FROM {$deleted_table})";

			return $wpdb->get_row($wpdb->prepare($sql, $form_id),ARRAY_A);
		}else{
			$sql = "SELECT count(m.form_id) as count FROM {$main_table} AS m LEFT JOIN {$details_table} AS d ON m.form_id = d.db7_forms_id WHERE m.form_post_id = %d AND d.db7_forms_id IS NULL";

			return $wpdb->get_row($wpdb->prepare($sql, $form_id),ARRAY_A);
		}
	}

	
	/**
	 * Retrieve a list of entries for a specific Contact Form 7 form, excluding those already indexed or deleted.
	 *
	 * This function fetches entries from the main db7_forms table that have not yet been indexed in the details table.
	 * If $delete_entries_count > 0, it also excludes entries found in the delete log table.
	 *
	 * @param wpdb $wpdb                  The WordPress database object.
	 * @param int  $form_id               The ID of the Contact Form 7 form.
	 * @param int  $limit                 The maximum number of entries to retrieve.
	 * @param int  $delete_entries_count  The number of deleted entries to consider (if > 0, exclude deleted entries).
	 * @return array                      Array of entries as associative arrays.
	 *
	 * Coding Guide:
	 * - Uses LEFT JOIN to find entries not present in the details table.
	 * - If $delete_entries_count > 0, excludes entries found in the delete log table.
	 * - Returns ARRAY_A for associative array output.
	 * - Use $wpdb->prepare() for safe SQL queries.
	 * - Useful for batch indexing or migration operations.
	 *
	 * @since 1.0.0
	*/
	public function get_db7_forms_indexing_entries($wpdb, $form_id, $limit, $delete_entries_count){
		$main_table    = "{$wpdb->prefix}{$this->cfdb7_db}";
		$details_table = str_replace("{form_id}", $form_id, "{$wpdb->prefix}{$this->cfdb7_entries_details}");

		if($delete_entries_count > 0){
			$deleted_table = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";

			$sql = "SELECT m.form_id,m.form_post_id,m.form_value,m.form_date,m.lead_source FROM {$main_table} AS m LEFT JOIN {$details_table} AS d ON m.form_id = d.db7_forms_id WHERE m.form_post_id = %d AND d.db7_forms_id IS NULL AND m.form_id NOT IN (SELECT entry_id FROM {$deleted_table}) LIMIT $limit";

			return $wpdb->get_results($wpdb->prepare($sql, $form_id),ARRAY_A);
		}else{
			$sql = "SELECT m.form_id,m.form_post_id,m.form_value,m.form_date,m.lead_source FROM {$main_table} AS m LEFT JOIN {$details_table} AS d ON m.form_id = d.db7_forms_id WHERE m.form_post_id = %d AND d.db7_forms_id IS NULL LIMIT $limit";

			return $wpdb->get_results($wpdb->prepare($sql, $form_id),ARRAY_A);
		}
	}

	/**
	 * Retrieve a single entry from the main db7_forms table by entry ID.
	 *
	 * @param wpdb $wpdb      The WordPress database object.
	 * @param int  $entry_id  The ID of the entry to retrieve.
	 * @return array|null     The entry row as an associative array, or null if not found.
	 *
	 * Coding Guide:
	 * - Use $wpdb->prepare() for safe SQL queries.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for fetching entry details for display or processing.
	 *
	 * @since 1.0.0
	*/
	public function get_db7_forms_entry($wpdb, $entry_id){
		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}{$this->cfdb7_db} where form_id=%d", $entry_id), ARRAY_A );
	}

	/**
	 * Check if a submission exists for a specific field and value in the entries submissions table.
	 *
	 * This function is useful for avoiding duplicate submissions or validating unique field values.
	 *
	 * @param wpdb  $wpdb         The WordPress database object.
	 * @param int   $form_id      The ID of the Contact Form 7 form.
	 * @param string $avoid_field The field name to check for (e.g., email, phone).
	 * @param string $field_value The value to check for in the specified field.
	 * @return array|null         The submission row as an associative array, or null if not found.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for duplicate checks or custom validation logic.
	 *
	 * @since 1.0.0
	*/
	public function check_Cfdb7_submission($wpdb, $form_id, $avoid_field, $field_value){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} where field_name=%s and field_value=%s", $avoid_field, $field_value), ARRAY_A );
	}

	/**
	 * Insert a new entry log row into the form-specific entries log table.
	 *
	 * This function records detailed log information for a form entry, including lead source, settings, original and processed entry data, and timestamps.
	 *
	 * @param wpdb  $wpdb     The WordPress database object.
	 * @param int   $form_id  The ID of the Contact Form 7 form.
	 * @param array $logger   The associative array of log data to insert. Keys include:
	 *                        - lead_source
	 *                        - form_setting
	 *                        - db7_forms_id
	 *                        - original_entry
	 *                        - original_entry_fields
	 *                        - form_entry
	 *                        - proceed_entry
	 *                        - proceed_entry_fields
	 *                        - entry_id
	 *                        - entry_details
	 *                        - date_time
	 * @return int            The ID of the newly inserted log row.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use maybe_serialize for array/object values to ensure proper storage.
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Return $wpdb->insert_id for the new log row's ID.
	 * - Ensure $logger data is properly sanitized before insertion.
	 * - Useful for tracking entry changes, debugging, or audit trails.
	 *
	 * @since 1.0.0
	*/
	public function save_entry_log($wpdb, $form_id, $logger){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$logger_data = array(
			'lead_source' => isset($logger['lead_source']) && !empty($logger['lead_source']) ? $logger['lead_source'] : "",

			'form_setting' => isset($logger['form_setting']) && !empty($logger['form_setting']) ? maybe_serialize($logger['form_setting']) : "",

			'db7_forms_id' => isset($logger['db7_forms_id']) && !empty($logger['db7_forms_id']) ? $logger['db7_forms_id'] : "",

			'original_entry' => isset($logger['original_entry']) && !empty($logger['original_entry']) ? maybe_serialize($logger['original_entry']) : "",

			'original_entry_fields' => isset($logger['original_entry_fields']) && !empty($logger['original_entry_fields']) ? maybe_serialize($logger['original_entry_fields']) : "",

			'form_entry' => isset($logger['form_entry']) && !empty($logger['form_entry']) ? maybe_serialize($logger['form_entry']) : "",

			'proceed_entry' => isset($logger['proceed_entry']) && !empty($logger['proceed_entry']) ? maybe_serialize($logger['proceed_entry']) : "",

			'proceed_entry_fields' => isset($logger['proceed_entry_fields']) && !empty($logger['proceed_entry_fields']) ? maybe_serialize($logger['proceed_entry_fields']) : "",

			'entry_id' => isset($logger['entry_id' ]) && !empty($logger['entry_id' ]) ? $logger['entry_id' ] : "",

			'entry_details' => isset($logger['entry_details']) && !empty($logger['entry_details']) ? maybe_serialize($logger['entry_details']) : "",
            
			'date_time' => isset($logger['date_time']) && !empty($logger['date_time']) ? $logger['date_time'] : "",

			'display_name' => isset($logger['display_name']) && !empty($logger['display_name']) ? $logger['display_name'] : "",

			'ip_address' => isset($logger['ip_address']) && !empty($logger['ip_address']) ? $logger['ip_address'] : "",
		);

		$logger_format = array_fill(0, count($logger_data), '%s');

		$wpdb->insert($table_name, $logger_data, $logger_format);
		return $wpdb->insert_id;
	}

		
	/**
	 * Insert a new submission log row into the form-specific entries submissions log table.
	 *
	 * This function records submission data for a form entry in the log table, useful for audit trails and debugging.
	 *
	 * @param wpdb  $wpdb     The WordPress database object.
	 * @param int   $form_id  The ID of the Contact Form 7 form.
	 * @param array $data     The associative array of submission data to insert.
	 * @param array $format   The array of format strings for each column.
	 * @return int            The ID of the newly inserted submission log row.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Return $wpdb->insert_id for the new log row's ID.
	 * - Ensure $data is properly sanitized before insertion.
	 * - Useful for tracking submission changes, debugging, or audit trails.
	 *
	 * @since 1.0.0
	*/
	public function save_cfdb7_log_submissions($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Get the count of each field name in the entries submissions table for a specific form.
	 *
	 * This function returns the count of submissions for each field name, optionally filtered by a specific field name.
	 * Useful for reporting and analytics on field usage.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $field_name (Optional) The field name to filter by. If empty, returns counts for all field names.
	 * @return array             Array of field name counts as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by field name.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating field usage reports and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_report_field_name_options_count($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);
        
		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} where field_name=%s GROUP BY field_name", $field_name), ARRAY_A );
		}else{
			return $wpdb->get_results("SELECT field_name,count(`field_name`) as count FROM {$table_name} GROUP BY field_name", ARRAY_A );
		}
	}

	/**
	 * Retrieve field name options for a specific Contact Form 7 form.
	 *
	 * This function fetches all field name options from the entries_field_name_options table for the given form.
	 * If a field name is provided, it returns only the options for that field name.
	 * Useful for reporting, analytics, and dynamic field management.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $field_name (Optional) The field name to filter by. If empty, returns all field name options.
	 * @return array             Array of field name options as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by field name.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating field option lists and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_report_field_name_options($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where field_name=%s", $field_name), ARRAY_A );
		}else{
			return $wpdb->get_results("SELECT * FROM {$table_name}", ARRAY_A );
		}
	}

	/**
	 * Truncate all field name options for a specific Contact Form 7 form.
	 *
	 * This function removes all rows from the entries_field_name_options table for the given form.
	 * Useful for resetting or clearing field name options before re-indexing or importing new data.
	 *
	 * @param wpdb $wpdb     The WordPress database object.
	 * @param int  $form_id  The ID of the Contact Form 7 form.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Uses TRUNCATE TABLE for fast removal of all rows.
	 * - Use with caution, as this operation cannot be undone.
	 *
	 * @since 1.0.0
	*/
	public function truncate_cfdb7_report_field_name_options($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->query("TRUNCATE TABLE {$table_name}");
	}

	/**
	 * Insert a new field name option for a specific Contact Form 7 form.
	 *
	 * This function adds a new row to the entries_field_name_options table for the given form,
	 * storing the field name and its entry count. Useful for reporting, analytics, and field management.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $field_name The field name to store.
	 * @param int    $field_count The count of entries for the field name.
	 * @return int               The ID of the newly inserted row.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Ensure $field_name and $field_count are properly sanitized before insertion.
	 * - Returns $wpdb->insert_id for the new row's ID.
	 *
	 * @since 1.0.0
	*/
	public function save_cfdb7_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'field_name' => $field_name,
			'entry_count' => $field_count,
		);
		$field_format = array("%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	/**
	 * Update the entry count for a specific field name in the entries_field_name_options table.
	 *
	 * This function modifies the entry count for a given field name in the specified form's
	 * entries_field_name_options table. Useful for maintaining accurate counts after data changes.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $field_name The field name to update.
	 * @param int    $field_count The new count of entries for the field name.
	 * @return int|false         The number of rows updated, or false on error.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->update() for safe data updates.
	 * - Ensure $field_name and $field_count are properly sanitized before updating.
	 * - Returns the number of rows affected, or false if the update fails.
	 *
	 * @since 1.0.0
	*/
	public function update_cfdb7_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'entry_count' => $field_count,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'field_name' => $field_name,
		);
		$where_field_format = array("%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	/**
	 * Get the count of each field name in the delete entries submissions table for a specific form.
	 *
	 * This function returns the count of deleted submissions for each field name, optionally filtered by a specific field name.
	 * Useful for reporting and analytics on deleted field usage.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $field_name (Optional) The field name to filter by. If empty, returns counts for all field names.
	 * @return array             Array of field name counts as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by field name.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating deleted field usage reports and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_delete_report_field_name_options_count($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);
		
		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} where field_name=%s GROUP BY field_name", $field_name), ARRAY_A );
		}else{
			return $wpdb->get_results("SELECT field_name,count(`field_name`) as count FROM {$table_name} GROUP BY field_name", ARRAY_A );
		}
	}

	/**
	 * Retrieve deleted field name options for a specific Contact Form 7 form.
	 *
	 * This function fetches all deleted field name options from the delete_entries_field_name_options table for the given form.
	 * If a field name is provided, it returns only the options for that field name.
	 * Useful for reporting, analytics, and dynamic field management of deleted entries.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $field_name (Optional) The field name to filter by. If empty, returns all deleted field name options.
	 * @return array             Array of deleted field name options as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by field name.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating deleted field option lists and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_delete_report_field_name_options($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where field_name=%s", $field_name), ARRAY_A );
		}else{
			return $wpdb->get_results("SELECT * FROM {$table_name}", ARRAY_A );
		}
	}

	/**
	 * Truncate all deleted field name options for a specific Contact Form 7 form.
	 *
	 * This function removes all rows from the delete_entries_field_name_options table for the given form.
	 * Useful for resetting or clearing deleted field name options before re-indexing or importing new data.
	 *
	 * @param wpdb $wpdb     The WordPress database object.
	 * @param int  $form_id  The ID of the Contact Form 7 form.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Uses TRUNCATE TABLE for fast removal of all rows.
	 * - Use with caution, as this operation cannot be undone.
	 *
	 * @since 1.0.0
	*/
	public function truncate_cfdb7_delete_report_field_name_options($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->query("TRUNCATE TABLE {$table_name}");
	}

	/**
	 * Insert a new deleted field name option for a specific Contact Form 7 form.
	 *
	 * This function adds a new row to the delete_entries_field_name_options table for the given form,
	 * storing the field name and its entry count. Useful for reporting, analytics, and field management of deleted entries.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $field_name The field name to store.
	 * @param int    $field_count The count of deleted entries for the field name.
	 * @return int               The ID of the newly inserted row.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Ensure $field_name and $field_count are properly sanitized before insertion.
	 * - Returns $wpdb->insert_id for the new row's ID.
	 *
	 * @since 1.0.0
	*/
	public function save_cfdb7_delete_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'field_name' => $field_name,
			'entry_count' => $field_count,
		);
		$field_format = array("%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	/**
	 * Update the entry count for a specific deleted field name in the delete_entries_field_name_options table.
	 *
	 * This function modifies the entry count for a given deleted field name in the specified form's
	 * delete_entries_field_name_options table. Useful for maintaining accurate counts after data changes.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $field_name The field name to update.
	 * @param int    $field_count The new count of deleted entries for the field name.
	 * @return int|false         The number of rows updated, or false on error.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->update() for safe data updates.
	 * - Ensure $field_name and $field_count are properly sanitized before updating.
	 * - Returns the number of rows affected, or false if the update fails.
	 *
	 * @since 1.0.0
	*/
	public function update_cfdb7_delete_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'entry_count' => $field_count,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'field_name' => $field_name,
		);
		$where_field_format = array("%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	/**
	 * Get the count of each field name in the entries submissions log table for a specific form.
	 *
	 * This function returns the count of logged submissions for each field name, optionally filtered by a specific field name.
	 * Useful for reporting and analytics on logged field usage.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $field_name (Optional) The field name to filter by. If empty, returns counts for all field names.
	 * @return array             Array of field name counts as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by field name.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating logged field usage reports and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_log_report_field_name_options_count($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);
		
		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} where field_name=%s GROUP BY field_name", $field_name), ARRAY_A );
		}else{
			return $wpdb->get_results("SELECT field_name,count(`field_name`) as count FROM {$table_name} GROUP BY field_name", ARRAY_A );
		}
	}

	/**
	 * Retrieve logged field name options for a specific Contact Form 7 form.
	 *
	 * This function fetches all logged field name options from the entries_field_name_options_log table for the given form.
	 * If a field name is provided, it returns only the options for that field name.
	 * Useful for reporting, analytics, and dynamic field management of logged entries.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $field_name (Optional) The field name to filter by. If empty, returns all logged field name options.
	 * @return array             Array of logged field name options as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by field name.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating logged field option lists and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_log_report_field_name_options($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where field_name=%s", $field_name), ARRAY_A );	
		}else{
			return $wpdb->get_results("SELECT * FROM {$table_name}", ARRAY_A );	
		}
	}

	/**
	 * Truncate all logged field name options for a specific Contact Form 7 form.
	 *
	 * This function removes all rows from the entries_field_name_options_log table for the given form.
	 * Useful for resetting or clearing logged field name options before re-indexing or importing new data.
	 *
	 * @param wpdb $wpdb     The WordPress database object.
	 * @param int  $form_id  The ID of the Contact Form 7 form.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Uses TRUNCATE TABLE for fast removal of all rows.
	 * - Use with caution, as this operation cannot be undone.
	 *
	 * @since 1.0.0
	*/
	public function truncate_cfdb7_log_report_field_name_options($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->query("TRUNCATE TABLE {$table_name}");
	}

	/**
	 * Insert a new logged field name option for a specific Contact Form 7 form.
	 *
	 * This function adds a new row to the entries_field_name_options_log table for the given form,
	 * storing the field name and its entry count. Useful for reporting, analytics, and field management of logged entries.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $field_name The field name to store.
	 * @param int    $field_count The count of logged entries for the field name.
	 * @return int               The ID of the newly inserted row.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Ensure $field_name and $field_count are properly sanitized before insertion.
	 * - Returns $wpdb->insert_id for the new row's ID.
	 *
	 * @since 1.0.0
	*/
	public function save_cfdb7_log_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'field_name' => $field_name,
			'entry_count' => $field_count,
		);
		$field_format = array("%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	/**
	 * Update the entry count for a specific logged field name in the entries_field_name_options_log table.
	 *
	 * This function modifies the entry count for a given logged field name in the specified form's
	 * entries_field_name_options_log table. Useful for maintaining accurate counts after data changes.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $field_name The field name to update.
	 * @param int    $field_count The new count of logged entries for the field name.
	 * @return int|false         The number of rows updated, or false on error.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->update() for safe data updates.
	 * - Ensure $field_name and $field_count are properly sanitized before updating.
	 * - Returns the number of rows affected, or false if the update fails.
	 *
	 * @since 1.0.0
	*/
	public function update_cfdb7_log_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'entry_count' => $field_count,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'field_name' => $field_name,
		);
		$where_field_format = array("%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}
	
	/**
	 * Get the count of export logs for a specific Contact Form 7 form.
	 *
	 * This function returns the total number of export log entries in the export_log table for the given form.
	 * Useful for reporting and analytics on export activity.
	 *
	 * @param wpdb $wpdb     The WordPress database object.
	 * @param int  $form_id  The ID of the Contact Form 7 form.
	 * @return array         Associative array containing the count of export logs.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating export activity reports and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_export_log_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_export_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row("SELECT count('id') as count FROM {$table_name}", ARRAY_A );	
	}

	/**
	 * Retrieve export logs for a specific Contact Form 7 form, optionally filtered by date range.
	 *
	 * This function fetches export log entries from the export_log table for the given form.
	 * If a date range is provided, it filters the logs accordingly.
	 * Useful for reporting, analytics, and tracking export activity.
	 *
	 * @param wpdb   $wpdb       The WordPress database object.
	 * @param int    $form_id    The ID of the Contact Form 7 form.
	 * @param string $from_date  (Optional) The start date for filtering logs (YYYY-MM-DD format).
	 * @param string $to_date    (Optional) The end date for filtering logs (YYYY-MM-DD format).
	 * @return array             Array of export log entries as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by date range.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating export activity reports and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_export_log($wpdb, $form_id, $from_date = "", $to_date = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_export_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$search_array = array();
		if(!empty($from_date) && !empty($to_date)){
			$from_date = date("Y-m-d", strtotime($from_date));
			$to_date = date("Y-m-d", strtotime($to_date));
			$search_array[] = $wpdb->prepare('export_date_time >= %s',$from_date . ' 00:00:00');
			$search_array[] = $wpdb->prepare('export_date_time <= %s',$to_date . ' 23:59:59');
		}

		if(!empty($search_array)){
			$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";
			return $wpdb->get_results("SELECT * FROM {$table_name} where $search_str order by `id` desc", ARRAY_A );	
		}else{
			return $wpdb->get_results("SELECT * FROM {$table_name} order by `id` desc", ARRAY_A );	
		}
	}

	/**
	 * Retrieve display settings for a specific Contact Form 7 form and user.
	 *
	 * This function fetches the display settings from the form_display_settings table for the given form and user.
	 * Useful for customizing the display of form entries based on user preferences.
	 *
	 * @param wpdb   $wpdb     The WordPress database object.
	 * @param int    $form_id  The ID of the Contact Form 7 form.
	 * @param int    $user_id  The ID of the user.
	 * @param string $context  The context for which to retrieve settings (e.g., 'admin', 'frontend').
	 * @return array           Associative array containing the display settings.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by user and context.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for customizing entry display based on user preferences.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_form_display_settings($wpdb, $form_id, $user_id, $context){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_display_settings}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} where user_id=%d AND context=%s", $user_id, $context), ARRAY_A );
	}

	/**
	 * Insert new display settings for a specific Contact Form 7 form and user.
	 *
	 * This function adds a new row to the form_display_settings table for the given form and user,
	 * storing the context and settings. Useful for saving user-specific display preferences.
	 *
	 * @param wpdb   $wpdb     The WordPress database object.
	 * @param int    $form_id  The ID of the Contact Form 7 form.
	 * @param int    $user_id  The ID of the user.
	 * @param string $context  The context for which to save settings (e.g., 'admin', 'frontend').
	 * @param string $settings The display settings to store (e.g., JSON string).
	 * @return int             The ID of the newly inserted row.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Ensure $context and $settings are properly sanitized before insertion.
	 * - Returns $wpdb->insert_id for the new row's ID.
	 *
	 * @since 1.0.0
	*/
	public function save_cfdb7_form_display_settings($wpdb, $form_id, $user_id, $context, $settings){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_display_settings}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'user_id' => $user_id,
			'context' => $context,
			'settings' => $settings,
		);
		$field_format = array("%s","%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	/**
	 * Update display settings for a specific Contact Form 7 form and user.
	 *
	 * This function modifies the display settings in the form_display_settings table for the given form and user.
	 * Useful for updating user-specific display preferences.
	 *
	 * @param wpdb   $wpdb     The WordPress database object.
	 * @param int    $form_id  The ID of the Contact Form 7 form.
	 * @param int    $user_id  The ID of the user.
	 * @param string $context  The context for which to update settings (e.g., 'admin', 'frontend').
	 * @param string $settings The new display settings to store (e.g., JSON string).
	 * @return int|false       The number of rows updated, or false on error.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->update() for safe data updates.
	 * - Ensure $context and $settings are properly sanitized before updating.
	 * - Returns the number of rows affected, or false if the update fails.
	 *
	 * @since 1.0.0
	*/
	public function update_cfdb7_form_display_settings($wpdb, $form_id, $user_id, $context, $settings){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_display_settings}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'settings' => $settings,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'user_id' => $user_id,
			'context' => $context,
		);
		$where_field_format = array("%s","%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	/**
	 * Get the count of form entries for a specific Contact Form 7 form.
	 *
	 * This function returns the total number of entries in the entries_details table for the given form.
	 * Useful for reporting and analytics on form submissions.
	 *
	 * @param wpdb $wpdb     The WordPress database object.
	 * @param int  $form_id  The ID of the Contact Form 7 form.
	 * @return array         Associative array containing the count of form entries.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating form submission reports and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_form_entries_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row("SELECT count(`entry_id`) as count FROM {$table_name}", ARRAY_A );
	}

	/**
	 * Retrieve form entries for a specific Contact Form 7 form, with optional search filters.
	 *
	 * This function fetches entries from the entries_details table for the given form.
	 * It supports filtering by field names, search value, date range, and pagination.
	 * Useful for reporting, analytics, and managing form submissions.
	 *
	 * @param wpdb   $wpdb         The WordPress database object.
	 * @param int    $form_id      The ID of the Contact Form 7 form.
	 * @param array  $search_input (Optional) An associative array containing search parameters:
	 *                             - 'field_names': array of field names to filter by.
	 *                             - 's': search value to look for in field values.
	 *                             - 'from_date': start date for filtering entries (YYYY-MM-DD format).
	 *                             - 'to_date': end date for filtering entries (YYYY-MM-DD format).
	 *                             - 'limit': number of entries to return.
	 *                             - 'offset': offset for pagination.
	 * @return array               Array of form entries as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when applying filters.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating filtered form submission reports and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_form_entries($wpdb, $form_id, $search_input = array()){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($search_input)){
			$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
			$field_names = array_map( 'sanitize_text_field', (array) $field_names );
			$search_value = isset($search_input['s']) && !empty($search_input['s']) ? sanitize_text_field($search_input['s']) : "";
			$from_date = isset($search_input['from_date']) && !empty($search_input['from_date']) ? sanitize_text_field($search_input['from_date']) : "";
			$to_date = isset($search_input['to_date']) && !empty($search_input['to_date']) ? sanitize_text_field($search_input['to_date']) : "";
			$limit = isset($search_input['limit']) && !empty($search_input['limit']) ? intval($search_input['limit']) : "";
			$offset = isset($search_input['offset']) && !empty($search_input['offset']) ? intval($search_input['offset']) : 0;

			$search_array = array();
			if(!empty($from_date) && !empty($to_date)){
				$from_date = date("Y-m-d", strtotime($from_date));
				$to_date = date("Y-m-d", strtotime($to_date));
				$search_array[] = $wpdb->prepare('submit_date_time >= %s',$from_date . ' 00:00:00');
    			$search_array[] = $wpdb->prepare('submit_date_time <= %s',$to_date . ' 23:59:59');
			}

			if(!empty($field_names) || !empty($search_value)){
				$entry_ids = $this->get_cfdb7_form_entries_submissions($wpdb, $form_id, $search_input);
				$entry_ids = !empty($entry_ids) ? wp_list_pluck($entry_ids, 'entry_id') : array();
				if(!empty($entry_ids)){
					$entry_ids_str = implode(', ', array_fill(0, count($entry_ids), '%d'));
					$search_array[] = $wpdb->prepare("entry_id IN ($entry_ids_str)", $entry_ids);
				}
			}
			
			if(!empty($search_array)){
				$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";
				return $wpdb->get_results("SELECT * FROM {$table_name} where $search_str order by `entry_id` desc", ARRAY_A );
			}else if($limit != "" && $offset != ""){
				return $wpdb->get_results("SELECT * FROM {$table_name} order by `entry_id` desc LIMIT $offset, $limit", ARRAY_A );
			}else{
				return array();
			}
		}else{
			return $wpdb->get_results("SELECT * FROM {$table_name} order by `entry_id` desc", ARRAY_A );
		}
	}

	/**
	 * Helper function to get entry IDs from the entries_submissions table based on search criteria.
	 *
	 * This function retrieves entry IDs from the entries_submissions table for the given form,
	 * filtered by specified field names and search value.
	 *
	 * @param wpdb   $wpdb         The WordPress database object.
	 * @param int    $form_id      The ID of the Contact Form 7 form.
	 * @param array  $search_input An associative array containing search parameters:
	 *                             - 'field_names': array of field names to filter by.
	 *                             - 's': search value to look for in field values.
	 * @return array               Array of entry IDs as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when applying filters.
	 * - Returns ARRAY_A for associative array output.
	 *
	 * @since 1.0.0
	*/
	private function get_cfdb7_form_entries_submissions( $wpdb, $form_id, $search_input ) {
	    $table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
	    $table_name = str_replace("{form_id}", $form_id, $table_name);

	    $field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? array_map( 'sanitize_text_field', $search_input['field_names'] ) : array();
	    $search_value = isset($search_input['s']) ? sanitize_text_field($search_input['s']) : '';

	    $where_clauses = array();
	    // Field names filter
	    if ( ! empty($field_names) ) {
	        $placeholders = implode(',', array_fill(0, count($field_names), '%s'));
	        $where_clauses[] = $wpdb->prepare("field_name IN ($placeholders)", $field_names);
	    }

	    // Search value filter
	    if ( ! empty($search_value) ) {
	        $where_clauses[] = $wpdb->prepare("field_value LIKE %s", '%' . $wpdb->esc_like($search_value) . '%');
	    }

	    $where_sql = $where_clauses ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
		
	    return $wpdb->get_results("SELECT `entry_id` FROM {$table_name} {$where_sql}", ARRAY_A );
	}

	/**
	 * Retrieve detailed information for a specific form entry.
	 *
	 * This function fetches all details from the entries_details table for a given form and entry ID.
	 * Useful for viewing or managing individual form submissions.
	 *
	 * @param wpdb   $wpdb     The WordPress database object.
	 * @param int    $form_id  The ID of the Contact Form 7 form.
	 * @param int    $entry_id The ID of the form entry.
	 * @return array           Associative array containing the entry details.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by entry ID.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for viewing and managing individual form submissions.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_form_entry_details($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} where entry_id=%d", $entry_id), ARRAY_A );
	}

	/**
	 * Retrieve detailed information for multiple form entries.
	 *
	 * This function fetches all details from the entries_details table for a given form and an array of entry IDs.
	 * Useful for viewing or managing multiple form submissions.
	 *
	 * @param wpdb   $wpdb      The WordPress database object.
	 * @param int    $form_id   The ID of the Contact Form 7 form.
	 * @param array  $entry_ids An array of form entry IDs.
	 * @return array            Array of entry details as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by entry IDs.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for viewing and managing multiple form submissions.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_entry_ids_details($wpdb, $form_id, $entry_ids){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$entry_ids_str = implode(', ', array_fill(0, count($entry_ids), '%d'));
		return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where entry_id IN ($entry_ids_str)", $entry_ids), ARRAY_A );
	}

	/**
	 * Retrieve submission information for multiple form entries.
	 *
	 * This function fetches all submissions from the entries_submissions table for a given form and an array of entry IDs.
	 * Useful for viewing or managing multiple form submissions.
	 *
	 * @param wpdb   $wpdb      The WordPress database object.
	 * @param int    $form_id   The ID of the Contact Form 7 form.
	 * @param array  $entry_ids An array of form entry IDs.
	 * @return array            Array of submission details as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by entry IDs.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for viewing and managing multiple form submissions.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_entry_ids_submissions($wpdb, $form_id, $entry_ids){	
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$entry_ids_str = implode(', ', array_fill(0, count($entry_ids), '%d'));
		return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where entry_id IN ($entry_ids_str)", $entry_ids), ARRAY_A );
	}

	/**
	 * Insert a new delete entries log for a specific Contact Form 7 form.
	 *
	 * This function adds a new row to the delete_entries_log table for the given form,
	 * storing information about deleted entries. Useful for tracking deletion activity.
	 *
	 * @param wpdb   $wpdb     The WordPress database object.
	 * @param int    $form_id  The ID of the Contact Form 7 form.
	 * @param array  $data     Associative array of data to insert into the log.
	 * @param array  $format   Array of formats corresponding to the data fields.
	 * @return int             The ID of the newly inserted row.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Ensure $data and $format are properly structured before insertion.
	 * - Returns $wpdb->insert_id for the new row's ID.
	 *
	 * @since 1.0.0
	*/
	public function save_cfdb7_delete_entries_log($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Insert a new delete entries submission for a specific Contact Form 7 form.
	 *
	 * This function adds a new row to the delete_entries_submissions table for the given form,
	 * storing information about deleted entry submissions. Useful for tracking deletion activity.
	 *
	 * @param wpdb   $wpdb     The WordPress database object.
	 * @param int    $form_id  The ID of the Contact Form 7 form.
	 * @param array  $data     Associative array of data to insert into the submission log.
	 * @param array  $format   Array of formats corresponding to the data fields.
	 * @return int             The ID of the newly inserted row.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Ensure $data and $format are properly structured before insertion.
	 * - Returns $wpdb->insert_id for the new row's ID.
	 *
	 * @since 1.0.0
	*/
	public function save_cfdb7_delete_entries_submission($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Delete a specific form entry from the entries_details table.
	 *
	 * This function removes a row from the entries_details table for the given form and entry ID.
	 * Useful for managing and cleaning up form submissions.
	 *
	 * @param wpdb   $wpdb     The WordPress database object.
	 * @param int    $form_id  The ID of the Contact Form 7 form.
	 * @param int    $entry_id The ID of the form entry to delete.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->delete() for safe data deletion.
	 * - Ensure $entry_id is properly sanitized before deletion.
	 *
	 * @since 1.0.0
	*/
	public function delete_cfdb7_form_entry($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	}

	/**
	 * Delete submissions for a specific form entry from the entries_submissions table.
	 *
	 * This function removes rows from the entries_submissions table for the given form and entry ID.
	 * Useful for managing and cleaning up form submissions.
	 *
	 * @param wpdb   $wpdb     The WordPress database object.
	 * @param int    $form_id  The ID of the Contact Form 7 form.
	 * @param int    $entry_id The ID of the form entry whose submissions are to be deleted.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->delete() for safe data deletion.
	 * - Ensure $entry_id is properly sanitized before deletion.
	 *
	 * @since 1.0.0
	*/
	public function delete_cfdb7_form_submissions($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	}

	/**
	 * Insert a new export log for a specific Contact Form 7 form.
	 *
	 * This function adds a new row to the export_log table for the given form,
	 * storing information about exports. Useful for tracking export activity.
	 *
	 * @param wpdb   $wpdb     The WordPress database object.
	 * @param int    $form_id  The ID of the Contact Form 7 form.
	 * @param array  $data     Associative array of data to insert into the export log.
	 * @param array  $format   Array of formats corresponding to the data fields.
	 * @return int             The ID of the newly inserted row.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->insert() for safe data insertion.
	 * - Ensure $data and $format are properly structured before insertion.
	 * - Returns $wpdb->insert_id for the new row's ID.
	 *
	 * @since 1.0.0
	*/
	public function save_cfdb7_export_log($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_export_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Get the count of delete entries logs for a specific Contact Form 7 form.
	 *
	 * This function returns the total number of delete entries log entries in the delete_entries_log table for the given form.
	 * Useful for reporting and analytics on deletion activity.
	 *
	 * @param wpdb $wpdb     The WordPress database object.
	 * @param int  $form_id  The ID of the Contact Form 7 form.
	 * @return array         Associative array containing the count of delete entries logs.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating deletion activity reports and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_delete_entries_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row("SELECT count(`entry_id`) as count FROM {$table_name}", ARRAY_A );
	}

	/**
	 * Retrieve delete entries logs for a specific Contact Form 7 form, with optional search filters.
	 *
	 * This function fetches delete entries log entries from the delete_entries_log table for the given form.
	 * It supports filtering by field names, search value, and date range.
	 * Useful for reporting, analytics, and tracking deletion activity.
	 *
	 * @param wpdb   $wpdb         The WordPress database object.
	 * @param int    $form_id      The ID of the Contact Form 7 form.
	 * @param array  $search_input (Optional) An associative array containing search parameters:
	 *                             - 'field_names': array of field names to filter by.
	 *                             - 's': search value to look for in field values.
	 *                             - 'from_date': start date for filtering logs (YYYY-MM-DD format).
	 *                             - 'to_date': end date for filtering logs (YYYY-MM-DD format).
	 * @return array               Array of delete entries log entries as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when applying filters.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating deletion activity reports and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_delete_entries($wpdb, $form_id, $search_input = array()){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($search_input)){
			$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
			$field_names = array_map( 'sanitize_text_field', (array) $field_names );
			$search_value = isset($search_input['s']) && !empty($search_input['s']) ? sanitize_text_field($search_input['s']) : "";
			$from_date = isset($search_input['from_date']) && !empty($search_input['from_date']) ? sanitize_text_field($search_input['from_date']) : "";
			$to_date = isset($search_input['to_date']) && !empty($search_input['to_date']) ? sanitize_text_field($search_input['to_date']) : "";

			$search_array = array();
			if(!empty($from_date) && !empty($to_date)){
				$from_date = date("Y-m-d", strtotime($from_date));
				$to_date = date("Y-m-d", strtotime($to_date));
				$search_array[] = $wpdb->prepare('submit_date_time >= %s',$from_date . ' 00:00:00');
    			$search_array[] = $wpdb->prepare('submit_date_time <= %s',$to_date . ' 23:59:59');
			}

			if(!empty($field_names) || !empty($search_value)){
				$entry_ids = $this->get_cfdb7_delete_entries_submissions($wpdb, $form_id, $search_input);
				$entry_ids = !empty($entry_ids) ? wp_list_pluck($entry_ids, 'entry_id') : array();
				if(!empty($entry_ids)){
					$entry_ids_str = implode(', ', array_fill(0, count($entry_ids), '%d'));
					$search_array[] = $wpdb->prepare("entry_id IN ($entry_ids_str)", $entry_ids);
				}
			}

			if(!empty($search_array)){
				$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";
				return $wpdb->get_results("SELECT * FROM {$table_name} where $search_str order by `id` desc", ARRAY_A );
			}else{
				return array();
			}
		}else{
			return $wpdb->get_results("SELECT * FROM {$table_name} order by `id` desc", ARRAY_A );
		}
	}

	/**
	 * Helper function to get entry IDs from the delete_entries_submissions table based on search criteria.
	 *
	 * This function retrieves entry IDs from the delete_entries_submissions table for the given form,
	 * filtered by specified field names and search value.
	 *
	 * @param wpdb   $wpdb         The WordPress database object.
	 * @param int    $form_id      The ID of the Contact Form 7 form.
	 * @param array  $search_input An associative array containing search parameters:
	 *                             - 'field_names': array of field names to filter by.
	 *                             - 's': search value to look for in field values.
	 * @return array               Array of entry IDs as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when applying filters.
	 * - Returns ARRAY_A for associative array output.
	 *
	 * @since 1.0.0
	*/
	private function get_cfdb7_delete_entries_submissions($wpdb, $form_id, $search_input){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? array_map( 'sanitize_text_field', $search_input['field_names'] ) : array();
		$search_value = isset($search_input['s']) && !empty($search_input['s']) ? $search_input['s'] : "";

		$where_clauses = array();
	    // Field names filter
	    if ( ! empty($field_names) ) {
	        $placeholders = implode(',', array_fill(0, count($field_names), '%s'));
	        $where_clauses[] = $wpdb->prepare("field_name IN ($placeholders)", $field_names);
	    }

	    // Search value filter
	    if ( ! empty($search_value) ) {
	        $where_clauses[] = $wpdb->prepare("field_value LIKE %s", '%' . $wpdb->esc_like($search_value) . '%');
	    }

	    $where_sql = $where_clauses ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
		
	    return $wpdb->get_results("SELECT `entry_id` FROM {$table_name} {$where_sql}", ARRAY_A );
	}

	/**
	 * Retrieve detailed information for multiple deleted form entries.
	 *
	 * This function fetches all details from the delete_entries_log table for a given form and an array of entry IDs.
	 * Useful for viewing or managing multiple deleted form submissions.
	 *
	 * @param wpdb   $wpdb      The WordPress database object.
	 * @param int    $form_id   The ID of the Contact Form 7 form.
	 * @param array  $entry_ids An array of form entry IDs.
	 * @return array            Array of deleted entry details as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by entry IDs.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for viewing and managing multiple deleted form submissions.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_delete_entry_ids_details($wpdb, $form_id, $entry_ids){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$entry_ids_str = implode(', ', array_fill(0, count($entry_ids), '%d'));
		return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where entry_id IN ($entry_ids_str)", $entry_ids), ARRAY_A );
	}

	/**
	 * Retrieve submission information for multiple deleted form entries.
	 *
	 * This function fetches all submissions from the delete_entries_submissions table for a given form and an array of entry IDs.
	 * Useful for viewing or managing multiple deleted form submissions.
	 *
	 * @param wpdb   $wpdb      The WordPress database object.
	 * @param int    $form_id   The ID of the Contact Form 7 form.
	 * @param array  $entry_ids An array of form entry IDs.
	 * @return array            Array of deleted submission details as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when filtering by entry IDs.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for viewing and managing multiple deleted form submissions.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_delete_entry_ids_submissions($wpdb, $form_id, $entry_ids){	
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$entry_ids_str = implode(', ', array_fill(0, count($entry_ids), '%d'));
		return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where entry_id IN ($entry_ids_str)", $entry_ids), ARRAY_A );
	}

	/**
	 * Delete a specific delete entry log from the delete_entries_log table.
	 *
	 * This function removes a row from the delete_entries_log table for the given form and entry ID.
	 * Useful for managing and cleaning up deletion logs.
	 *
	 * @param wpdb   $wpdb     The WordPress database object.
	 * @param int    $form_id  The ID of the Contact Form 7 form.
	 * @param int    $entry_id The ID of the delete entry log to delete.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->delete() for safe data deletion.
	 * - Ensure $entry_id is properly sanitized before deletion.
	 *
	 * @since 1.0.0
	*/
	public function delete_cfdb7_entry_delete_log($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	}

	/**
	 * Delete a specific delete entry submission from the delete_entries_submissions table.
	 *
	 * This function removes a row from the delete_entries_submissions table for the given form and entry ID.
	 * Useful for managing and cleaning up deletion submission logs.
	 *
	 * @param wpdb   $wpdb     The WordPress database object.
	 * @param int    $form_id  The ID of the Contact Form 7 form.
	 * @param int    $entry_id The ID of the delete entry submission to delete.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->delete() for safe data deletion.
	 * - Ensure $entry_id is properly sanitized before deletion.
	 *
	 * @since 1.0.0
	*/
	public function delete_cfdb7_entry_submission_log($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	} 

	/**
	 * Get the count of log entries for a specific Contact Form 7 form.
	 *
	 * This function returns the total number of log entries in the entries_log table for the given form.
	 * Useful for reporting and analytics on log activity.
	 *
	 * @param wpdb $wpdb     The WordPress database object.
	 * @param int  $form_id  The ID of the Contact Form 7 form.
	 * @return array         Associative array containing the count of log entries.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating log activity reports and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_log_entries_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row("SELECT count(`entry_id`) as count FROM {$table_name}", ARRAY_A );
	}

	/**
	 * Retrieve log entries for a specific Contact Form 7 form, with optional search filters.
	 *
	 * This function fetches log entries from the entries_log table for the given form.
	 * It supports filtering by field names, search value, and date range.
	 * Useful for reporting, analytics, and tracking log activity.
	 *
	 * @param wpdb   $wpdb         The WordPress database object.
	 * @param int    $form_id      The ID of the Contact Form 7 form.
	 * @param array  $search_input (Optional) An associative array containing search parameters:
	 *                             - 'field_names': array of field names to filter by.
	 *                             - 's': search value to look for in field values.
	 *                             - 'from_date': start date for filtering logs (YYYY-MM-DD format).
	 *                             - 'to_date': end date for filtering logs (YYYY-MM-DD format).
	 * @return array               Array of log entries as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when applying filters.
	 * - Returns ARRAY_A for associative array output.
	 * - Useful for generating log activity reports and analytics.
	 *
	 * @since 1.0.0
	*/
	public function get_cfdb7_log_entries($wpdb, $form_id, $search_input = array()){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($search_input)){
			$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
			$field_names = array_map( 'sanitize_text_field', (array) $field_names );
			$search_value = isset($search_input['s']) && !empty($search_input['s']) ? sanitize_text_field($search_input['s']) : "";
			$from_date = isset($search_input['from_date']) && !empty($search_input['from_date']) ? sanitize_text_field($search_input['from_date']) : "";
			$to_date = isset($search_input['to_date']) && !empty($search_input['to_date']) ? sanitize_text_field($search_input['to_date']) : "";

			$search_array = array();
			if(!empty($from_date) && !empty($to_date)){
				$from_date = date("Y-m-d", strtotime($from_date));
				$to_date = date("Y-m-d", strtotime($to_date));
				$search_array[] = $wpdb->prepare('date_time >= %s',$from_date . ' 00:00:00');
    			$search_array[] = $wpdb->prepare('date_time <= %s',$to_date . ' 23:59:59');
			}

			if(!empty($field_names) || !empty($search_value)){
				$entry_ids = $this->get_cfdb7_log_entries_submissions($wpdb, $form_id, $search_input);
				$entry_ids = !empty($entry_ids) ? wp_list_pluck($entry_ids, 'entry_id') : array();
				if(!empty($entry_ids)){
					$entry_ids_str = implode(', ', array_fill(0, count($entry_ids), '%d'));
					$search_array[] = $wpdb->prepare("entry_id IN ($entry_ids_str)", $entry_ids);
				}
			}

			if(!empty($search_array)){
				$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";
				return $wpdb->get_results("SELECT `id`,`lead_source`,`db7_forms_id`,`entry_id`,`original_entry`,`original_entry_fields`,`date_time` FROM {$table_name} where $search_str order by `id` desc", ARRAY_A );
			}else{
				return array();
			}
		}else{
			return $wpdb->get_results("SELECT `id`,`lead_source`,`db7_forms_id`,`entry_id`,`original_entry`,`original_entry_fields`,`date_time` FROM {$table_name} order by `id` desc", ARRAY_A );
		}
	}

	/**
	 * Helper function to get entry IDs from the entries_submissions_log table based on search criteria.
	 *
	 * This function retrieves entry IDs from the entries_submissions_log table for the given form,
	 * filtered by specified field names and search value.
	 *
	 * @param wpdb   $wpdb         The WordPress database object.
	 * @param int    $form_id      The ID of the Contact Form 7 form.
	 * @param array  $search_input An associative array containing search parameters:
	 *                             - 'field_names': array of field names to filter by.
	 *                             - 's': search value to look for in field values.
	 * @return array               Array of entry IDs as associative arrays.
	 *
	 * Coding Guide:
	 * - Table name is dynamically set for each form using {form_id}.
	 * - Use $wpdb->prepare() for safe SQL queries when applying filters.
	 * - Returns ARRAY_A for associative array output.
	 *
	 * @since 1.0.0
	*/
	private function get_cfdb7_log_entries_submissions($wpdb, $form_id, $search_input){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? array_map( 'sanitize_text_field', $search_input['field_names'] ) : array();
		$search_value = isset($search_input['s']) && !empty($search_input['s']) ? sanitize_text_field($search_input['s']) : "";

		$where_clauses = array();
	    // Field names filter
	    if ( ! empty($field_names) ) {
	        $placeholders = implode(',', array_fill(0, count($field_names), '%s'));
	        $where_clauses[] = $wpdb->prepare("field_name IN ($placeholders)", $field_names);
	    }

	    // Search value filter
	    if ( ! empty($search_value) ) {
	        $where_clauses[] = $wpdb->prepare("field_value LIKE %s", '%' . $wpdb->esc_like($search_value) . '%');
	    }

	    $where_sql = $where_clauses ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
		
	    return $wpdb->get_results("SELECT `entry_id` FROM {$table_name} {$where_sql}", ARRAY_A );
	}

	/**
	 * Get a single log entry from the log table by index ID for a specific form.
	 *
	 * @param wpdb  $wpdb     The WordPress database object.
	 * @param int   $form_id  The ID of the Contact Form 7 form.
	 * @param int   $index_id The index ID to retrieve.
	 * @return array|null     The log entry row as an associative array, or null if not found.
	 *
	 * Coding Guide:
	 * - Use $wpdb->prepare() for safe SQL queries.
	 *
	 * @since    1.0.0
	*/
	public function get_cfdb7_log_entry($wpdb, $form_id, $index_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} where id=%d", $index_id), ARRAY_A );
	}
}