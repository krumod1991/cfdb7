jQuery(document).ready(function () {
    function cfdb7_open_popup() {
        jQuery.magnificPopup.open({
            items: {
                src: '#popup-content'
            },
            type: 'inline',
            closeOnBgClick: false,
            enableEscapeKey: false,
            callbacks: {
                open: function () {
                    var bar = jQuery('.progress-bar');
                    bar.animate({ width: '0%' }, 5000, 'linear');
                },
                close: function () {
                    jQuery('.progress-bar').stop(true).css('width', '0%');
                }
            }
        });
    }

    jQuery("#cf7-id").change(function () {
        var cf7_id = jQuery(this).val();
        var nonce = jQuery("#indexing_entries_page_nonce").val();
        var current_url = new URL(window.location.href);
        current_url.searchParams.delete('cf7-id');
        if (cf7_id != "") {
            window.location = current_url + '&cf7-id=' + cf7_id + '&nonce=' + nonce;
        } else {
            window.location = current_url;
        }
    });

    var proceed_paged = 1;
    var max_paged = "";
    jQuery("#cfdb7-indexing").click(function () {
        jQuery("#notice").html('');
        jQuery('.notice').removeClass('notice-error');
        jQuery('.notice').css('display', 'none');
        var cf7_id = jQuery("#cf7-id").val();
        var nonce = jQuery("#indexing_entries_nonce").val();
        proceed_paged = 1;
        max_paged = "";

        jQuery.ajax({
            url: cfdb7_params.ajax_url,
            data: {
                'action': 'cfdb7_indexing_info',
                'cf7_id': cf7_id,
                'nonce': nonce,
            },
            type: 'POST',
            beforeSend: function (xhr) {
                jQuery(".cfdb7-indexing-entries .loader").css("display", 'flex');
            },
            success: function (data) {
                var result = JSON.parse(data);
                if (result.status == "success") {
                    max_paged = result.max_pages;
                    setTimeout(function () {
                        cfdb7_open_popup();
                        cfdb7_trigger_indexing(proceed_paged, max_paged, cf7_id, nonce);
                    }, 1000);
                } else {
                    jQuery("#notice").html(result.message);
                    jQuery('.notice').addClass('notice-error');
                    jQuery('.notice').css('display', 'block');
                    jQuery(".cfdb7-indexing-entries .loader").css("display", 'none');
                }
            },
            fail: function () {
                jQuery(".cfdb7-indexing-entries .loader").css("display", 'none');
            }
        });
    });

    function cfdb7_trigger_indexing(proceed_paged, max_paged, cf7_id, nonce) {
        jQuery.ajax({
            url: cfdb7_params.ajax_url,
            data: {
                'action': 'cfdb7_indexing_entries',
                'cf7_id': cf7_id,
                'nonce': nonce,
            },
            type: 'POST',
            success: function (data) {
                var result = JSON.parse(data);
                if (result.is_next_page == "yes") {
                    proceed_paged = parseInt(proceed_paged);
                    max_paged = parseInt(max_paged);
                    var proceed_ratio = (proceed_paged / max_paged) * 100;
                    console.log(proceed_paged + "::" + max_paged + "::" + proceed_ratio);
                    proceed_paged++;
                    setTimeout(function () {
                        var bar = jQuery('.progress-bar');
                        bar.css('width', proceed_ratio + '%');
                        cfdb7_trigger_indexing(proceed_paged, max_paged, cf7_id, nonce);
                    }, 1000);
                } else {
                    jQuery(".cfdb7-indexing-entries .loader").css("display", 'none');
                }

                if (proceed_paged == max_paged) {
                    jQuery("#notice").html(cfdb7_params.success_index_message);
                    jQuery('.notice').addClass('notice-success');
                    jQuery('.notice').css('display', 'block');
                    jQuery.magnificPopup.close();
                } else if (max_paged == 1) {
                    jQuery("#notice").html(cfdb7_params.success_index_message);
                    jQuery('.notice').addClass('notice-success');
                    jQuery('.notice').css('display', 'block');
                    jQuery.magnificPopup.close();
                }
            },
            fail: function () {
                jQuery(".cfdb7-indexing-entries .loader").css("display", 'none');
            }
        });
    }
});