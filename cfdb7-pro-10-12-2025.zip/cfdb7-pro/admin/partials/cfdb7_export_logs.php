<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Render the export logs UI for viewing and filtering export log entries.
 *
 * This logic prepares the export logs admin page, builds the form for selecting a form and filtering by date,
 * verifies nonce for security, and includes the export logs list table for valid forms. It also displays admin
 * notices for error states and enqueues required styles and scripts for UI functionality.
 *
 * Coding Guide:
 * - Only show forms with export logs available.
 * - Sanitize all input and output data.
 * - Use wp_nonce_field and wp_verify_nonce for security against CSRF.
 * - Use esc_html, esc_attr, and selected() for safe output.
 * - Provide clear admin notices for error states.
 * - Enqueue required styles and scripts for UI functionality.
 *
 * @since 1.0.0
 * @param array $forms_list List of all available forms.
 * @param int $_GET['cf7-id'] Selected form ID for export logs.
 * @param string $_GET['nonce'] Nonce for security verification.
 * @param string $_GET['from_date'] Optional filter start date.
 * @param string $_GET['to_date'] Optional filter end date.
*/

$cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? intval($_GET['cf7-id']) : "";
$nonce = isset($_GET['nonce']) && !empty($_GET['nonce']) ? sanitize_text_field($_GET['nonce']) : "";
$context = isset($_GET['page']) && !empty($_GET['page']) ? sanitize_text_field($_GET['page']) : "";
$url_args = array('page' => $context);
if(!empty($cf7_id) && !empty($nonce)){
    $url_args['cf7-id'] = $cf7_id;
    $url_args['nonce'] = $nonce;
}
// Add search/filter params if present
if (isset($_GET['from_date']) && !empty($_GET['from_date'])) {
    $url_args['from_date'] = sanitize_text_field($_GET['from_date']);
}
if (isset($_GET['to_date']) && !empty($_GET['to_date'])) {
    $url_args['to_date'] = sanitize_text_field($_GET['to_date']);
}
$admin_page_url = add_query_arg( $url_args, admin_url( 'admin.php' ) );

global $wpdb;
$obj = new Cfdb7_Queries();
$obj->init_cfdb7_tables();

$allowed_form_ids = array();
if(!empty($forms_list)){
    foreach($forms_list as $form){
        $entries_count = $obj->get_cfdb7_export_log_count($wpdb, $form->ID);
        if($entries_count['count'] > 0){
            $allowed_form_ids[] = $form;
        }
    }
}

wp_enqueue_style('cfdb7_export_log_style');
wp_enqueue_script('cfdb7_export_logs_script');
?>
<div class="wrap cfdb7-export-log">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Export Logs', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
    <form id="cfdb7-ids" method="post" action="<?php echo esc_url($admin_page_url); ?>" novalidate="novalidate">
        <table class="form-table">
            <tr class="form-field">
                <th><label for="cf7-id"><?php echo esc_html__('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></label></th>
                <td>
                    <select name="cf7-id" id="cf7-id">
                        <option value=""><?php echo esc_html__('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></option>
                        <?php 
                        if(!empty($allowed_form_ids)){
                            foreach($allowed_form_ids as $form){
                                ?><option value="<?php echo esc_attr($form->ID); ?>" <?php selected($cf7_id, $form->ID); ?>><?php echo esc_html($form->post_title); ?></option><?php
                            }
                        }
                        ?>
                    </select>
                    <?php wp_nonce_field('cfdb7_export_logs_page', 'cfdb7_export_logs_page_nonce'); ?>
                </td>
            </tr>
        </table>
    </form>
    <?php
    if(!empty($cf7_id) && !empty($nonce)){
        if(wp_verify_nonce($nonce, 'cfdb7_export_logs_page')){
            include_once plugin_dir_path( __DIR__ ).'partials/cfdb7_export_logs_list_table.php';
        }else{
            ?>
            <div class="notice notice-error"><p><?php echo esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
            <?php
        }
    }
    ?>
</div>
