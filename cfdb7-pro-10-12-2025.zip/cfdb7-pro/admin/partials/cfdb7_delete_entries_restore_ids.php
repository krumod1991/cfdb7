<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Main logic block for handling bulk restore of deleted entries in admin UI.
 *
 * - Validates and sanitizes incoming POST parameters: cf7-id, nonce, entry IDs.
 * - Verifies nonce for security before proceeding with restore.
 * - Splits entry IDs into chunks for efficient processing and UI feedback.
 * - Renders hidden input fields for each chunk and a progress bar for AJAX-driven restore.
 * - Handles error state for nonce failure with user-friendly message.
 *
 * @param int    $cf7_id      Contact Form 7 form ID (from POST)
 * @param string $nonce       Nonce for security verification (from POST)
 * @param array  $entry_ids   Array of entry IDs to restore (from POST)
 *
 * Coding Guide:
 * - Always sanitize and validate all incoming POST data.
 * - Use wp_verify_nonce for security before restoring entries.
 * - Use apply_filters for chunk size to allow extensibility.
 * - Render UI elements with proper escaping (esc_attr, esc_url).
 * - Use wp_die for error handling to prevent unauthorized access.
 *
 * Security Practices:
 * - Nonce verification prevents CSRF attacks.
 * - All output is properly escaped to prevent XSS.
 *
 * @since 1.0.0
*/

$cf7_id = isset($_POST['cf7-id']) && !empty($_POST['cf7-id']) ? intval($_POST['cf7-id']) : "";
$nonce = isset($_POST['cfdb7_deleted_entries_nonce']) && !empty($_POST['cfdb7_deleted_entries_nonce']) ? sanitize_text_field($_POST['cfdb7_deleted_entries_nonce']) : "";
$entry_ids = isset($_POST['ids']) && !empty($_POST['ids']) ? array_map('intval', $_POST['ids']) : array();
if(!empty($cf7_id) && !empty($nonce) && !empty($entry_ids)){
    $is_proceed_delete = false;
    if(wp_verify_nonce( $nonce, 'cfdb7_deleted_entries_'.$cf7_id )){
        $chunk_size = 10;
        $chunk_size = apply_filters( 'cfdb7_restore_entries_chunk_size', $chunk_size );
        //Split entry ids into chunks
        $chunk_ids = array_chunk($entry_ids, $chunk_size);

        $referer_url = isset($_POST['_wp_http_referer']) ? wp_unslash($_POST['_wp_http_referer']) : '';
        ?>
        <div class="wrap cfdb7-restore-entries">
            <div id="notice"></div>
            <input type="hidden" id="cf7-id" value="<?php echo esc_attr($cf7_id); ?>" />
            <input type="hidden" id="cfdb7_deleted_entries_nonce" value="<?php echo esc_attr($nonce); ?>" />
            <input type="hidden" id="referer_url" value="<?php echo esc_url($referer_url); ?>" />
            <?php 
            foreach($chunk_ids as $key => $ids){ 
                ?>
                <input type="hidden" class="entries-deleted-entries-restore-ids" data-index="<?php echo esc_attr($key + 1); ?>" value="<?php echo esc_attr(implode(",", $ids)); ?>" />
                <?php 
            } 
            ?>
        </div>
        <div id="popup-content" class="mfp-hide">
            <div class="modal-box">
                <div class="modal-header">
                    <h2><?php echo esc_html__('Processing Request', CFDB7_PRO_TEXT_DOMAIN); ?></h2>
                </div>
                <div class="modal-body">
                    <div class="processing-text">
                        <?php echo esc_html__('Your request is being processed. Please wait...', CFDB7_PRO_TEXT_DOMAIN); ?>
                    </div>
                    <div class="progress-bar-container">
                        <div class="progress-bar"></div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }else{
        ?>
        <div class="notice notice-error"><p><?php echo esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
        <?php
    }
}
?>