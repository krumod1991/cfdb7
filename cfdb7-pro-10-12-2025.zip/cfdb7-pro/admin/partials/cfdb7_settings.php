<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Handle saving and updating plugin settings for selected Contact Form 7 form.
 *
 * This logic processes the settings form submission, validates and sanitizes input,
 * verifies nonce for security, and saves or updates settings in the database.
 * It also logs previous settings before updating and provides user feedback via admin notices.
 *
 * Coding Guide:
 * - Always sanitize and validate all incoming $_POST data.
 * - Use wp_verify_nonce for security to prevent CSRF attacks.
 * - Use WordPress database API for safe queries and updates.
 * - Log previous settings before updating for audit trail.
 * - Provide clear admin notices for success and error states.
 * - Use apply_filters to allow extensibility for saving settings.
 *
 * @since 1.0.0
 * @param array $_POST All submitted settings fields.
 * @param string $_POST['cfdb7_setting_nonce'] Nonce for security verification.
 * @param int $_POST['cf7-id'] Selected Contact Form 7 form ID.
 * @param string $_POST['avoid-duplicate-submission'] Option to avoid duplicate submissions.
 * @param string $_POST['avoid-field'] Field used to check for duplicates.
 * @param array $_POST['excludes-fields'] Fields to exclude from saving.
 * @param int $_POST['enquiries-per-page'] Entries per page setting.
 * @param int $_POST['character-limit'] Character limit for entry display.
*/

global $wpdb;
$obj = new Cfdb7_Queries();
$obj->init_cfdb7_tables();

if(isset($_POST)){
    $nonce = isset($_POST['cfdb7_setting_nonce']) && !empty($_POST['cfdb7_setting_nonce']) ? sanitize_text_field($_POST['cfdb7_setting_nonce']) : "";
    if(!empty($nonce)){
        if(wp_verify_nonce($nonce, 'cfdb7_settings')){
            $cf7_id = isset($_POST['cf7-id']) && !empty($_POST['cf7-id']) ? intval($_POST['cf7-id']) : "";
            if(!empty($cf7_id)){
                $cfdb7_avoid_duplicate_submission = isset($_POST['avoid-duplicate-submission'][$cf7_id]) && !empty($_POST['avoid-duplicate-submission'][$cf7_id]) ? sanitize_text_field($_POST['avoid-duplicate-submission'][$cf7_id]) : "";

                $cfdb7_avoid_field = isset($_POST['avoid-field'][$cf7_id]) && !empty($_POST['avoid-field'][$cf7_id]) ? sanitize_text_field($_POST['avoid-field'][$cf7_id]) : "";

                $cfdb7_excludes_fields = isset($_POST['excludes-fields'][$cf7_id]) && !empty($_POST['excludes-fields'][$cf7_id]) ? array_map('sanitize_text_field', $_POST['excludes-fields'][$cf7_id]) : array();

                $enquiries_per_page = isset($_POST['enquiries-per-page'][$cf7_id]) && !empty($_POST['enquiries-per-page'][$cf7_id]) ? intval($_POST['enquiries-per-page'][$cf7_id]) : 10;

                $character_limit = isset($_POST['character-limit'][$cf7_id]) && !empty($_POST['character-limit'][$cf7_id]) ? intval($_POST['character-limit'][$cf7_id]) : 30;

                if($enquiries_per_page < 10){
                    $enquiries_per_page = 10;
                }

                if($character_limit < 30){
                    $character_limit = 30;
                }

                $cfdb_settings = array(
                    'avoid_duplicate_submission' => $cfdb7_avoid_duplicate_submission,
                    'avoid_field' => $cfdb7_avoid_field,
                    'excludes_fields' => $cfdb7_excludes_fields,
                    'enquiries_per_page' => $enquiries_per_page,
                    'character_limit' => $character_limit,
                );
                $cfdb_settings = apply_filters( 'cfdb7_setting_page_save_form_fields', $cfdb_settings, $_POST);

                $user_info = cfdb7_get_logged_in_user_info();
                $user_id = $user_info['user_id'];
                $display_name = $user_info['display_name'];

                $date_time = current_time("Y-m-d H:i:s");
                $ip_address = cfdb7_get_ip_address();

                $setting_info = array(
                    'form_id' => $cf7_id,
                    'settings' => maybe_serialize($cfdb_settings),
                    'entry_by' => $user_id,
                    'entry_display_name' => $display_name,
                    'entry_date_time' => $date_time,
                    'entry_ip_address' => $ip_address,
                );

                $sql_format = array_fill(0, count($setting_info), '%s');

                $get_setting = $obj->get_cfdb7_form_setting($wpdb, $cf7_id);
                if(!empty($get_setting)){
                    $previous_entry = array(
                        'form_id'             => isset($get_setting['form_id']) ? intval($get_setting['form_id']) : '',
                        'settings'            => isset($get_setting['settings']) ? $get_setting['settings'] : '',
                        'entry_by'            => isset($get_setting['entry_by']) ? intval($get_setting['entry_by']) : 0,
                        'entry_display_name'  => isset($get_setting['entry_display_name']) ? sanitize_text_field($get_setting['entry_display_name']) : '',
                        'entry_date_time'     => isset($get_setting['entry_date_time']) ? sanitize_text_field($get_setting['entry_date_time']) : '',
                        'entry_ip_address'    => isset($get_setting['entry_ip_address']) ? sanitize_text_field($get_setting['entry_ip_address']) : '',
                    );

                    $previous_entry_format = array_fill(0, count($previous_entry), '%s');

                    $where = array(
                        'form_id' => $cf7_id,
                    );
                    $where_format = array('%d');

                    //Save setting log
                    $obj->save_cfdb7_setting_log($wpdb, $previous_entry, $previous_entry_format);
                    //Update cfdb7 setting
                    $obj->update_cfdb7_form_setting($wpdb, $setting_info, $sql_format, $where, $where_format);
                }else{
                    //Save cfdb7 setting
                    $obj->save_cfdb7_form_setting($wpdb, $setting_info, $sql_format);
                }
                
                ?>
                <div class="notice notice-success"><p><?php echo esc_html__( 'Settings saved successfully.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
                <?php
            }else{
                ?>
                <div class="notice notice-error"><p><?php echo esc_html__( 'Please select a form.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
                <?php
            }
        }else{
            ?>
            <div class="notice notice-error"><p><?php echo esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
            <?php
        }
    }
}

$cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? intval($_GET['cf7-id']) : "";
$nonce = isset($_GET['nonce']) && !empty($_GET['nonce']) ? sanitize_text_field($_GET['nonce']) : "";
$page = isset($_GET['page']) && !empty($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
$url_args = array('page' => $page);

$get_setting = array();
if(!empty($cf7_id) && !empty($nonce)){
    $get_setting = $obj->get_cfdb7_form_setting($wpdb, $cf7_id);
    $get_setting = isset($get_setting['settings']) && !empty($get_setting['settings']) ? maybe_unserialize($get_setting['settings']) : array();

    $url_args['cf7-id'] = $cf7_id;
    $url_args['nonce'] = $nonce;
}

$admin_page_url = add_query_arg( $url_args, admin_url( 'admin.php' ) );

wp_enqueue_style('cfdb7_chosen_style');
wp_enqueue_script('cfdb7_chosen_script');
wp_enqueue_style('cfdb7_setting_style');
wp_enqueue_script('cfdb7_setting_script');
?>
<div class="wrap cfdb7-settings">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Settings', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
    <form method="post" action="<?php echo esc_url($admin_page_url); ?>" novalidate="novalidate">
        <table class="form-table">
            <tr class="form-field">
                <th><label for="cf7-id"><?php echo esc_html__('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></label></th>
                <td>
                    <select name="cf7-id" id="cf7-id">
                        <option value=""><?php echo esc_html__('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></option>
                        <?php 
                        if(!empty($forms_list)){
                            foreach($forms_list as $form){
                                ?><option value="<?php echo $form->ID; ?>" <?php selected($cf7_id, $form->ID); ?>><?php echo $form->post_title; ?></option><?php
                            }
                        }
                        ?>
                    </select>
                    <?php wp_nonce_field('cfdb7_setting_page', 'cfdb7_setting_page_nonce'); ?>
                </td>
            </tr>
            <?php
            if(!empty($nonce)){
                if(wp_verify_nonce($nonce, 'cfdb7_setting_page')){
                    if(!empty($cf7_id)){
                        $tags = cfdb7_get_form_tags($cf7_id);
                        //Set fields list
                        $fields = array();
                        $avoid_fields = array();
                        if(!empty($tags)){
                            foreach ( $tags as $tag ){
                                if(!empty($tag->name)){
                                    if($tag->basetype != "email"){
                                        $fields[] = sanitize_text_field($tag->name);
                                    }

                                    if($tag->basetype == "email" || $tag->basetype == "hidden"){
                                        $avoid_fields[] = sanitize_text_field($tag->name);
                                    }
                                }
                            }
                        }

                        $cfdb7_avoid_duplicate_submission = isset($get_setting['avoid_duplicate_submission']) && !empty($get_setting['avoid_duplicate_submission']) ? sanitize_text_field($get_setting['avoid_duplicate_submission']) : "";

                        $cfdb7_avoid_field = isset($get_setting['avoid_field']) && !empty($get_setting['avoid_field']) ? sanitize_text_field($get_setting['avoid_field']) : "";

                        $cfdb7_excludes_fields = isset($get_setting['excludes_fields']) && !empty($get_setting['excludes_fields']) ? array_map('sanitize_text_field', $get_setting['excludes_fields']) : array();

                        $enquiries_per_page = isset($get_setting['enquiries_per_page']) && !empty($get_setting['enquiries_per_page']) ? intval($get_setting['enquiries_per_page']) : 10;

                        $character_limit = isset($get_setting['character_limit']) && !empty($get_setting['character_limit']) ? intval($get_setting['character_limit']) : 30;
                        ?>
                        <tr>
                            <th>
                                <label for="avoid-duplicate-submission"><?php echo esc_html__('Avoid duplicate submission', CFDB7_PRO_TEXT_DOMAIN); ?></label>
                                <span class="cfdb7-tooltip">
                                    <span class="dashicons dashicons-editor-help" style="color: #666; cursor: help; vertical-align: middle; margin-left: 5px;"></span>
                                    <span class="tooltiptext"><?php echo esc_html__('Enable this option to prevent duplicate form submissions. When enabled, the system will check the selected avoid field to identify and block duplicate entries.', CFDB7_PRO_TEXT_DOMAIN); ?></span>
                                </span>
                            </th>
                            <td>
                                <label class="switch">
                                    <input type="checkbox" name="avoid-duplicate-submission[<?php echo $cf7_id; ?>]" id="toggleSwitch" class="avoid-duplicate-submission" <?php echo  $cfdb7_avoid_duplicate_submission == "on" ? "checked" : ""; ?> >
                                    <span class="slider">
                                        <span class="on" style="display: none;">ON</span>
                                        <span class="off" style="display: none;">OFF</span>
                                    </span>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label for="avoid-field"><?php echo esc_html__('Avoid field', CFDB7_PRO_TEXT_DOMAIN); ?></label>
                                <span class="cfdb7-tooltip">
                                    <span class="dashicons dashicons-editor-help" style="color: #666; cursor: help; vertical-align: middle; margin-left: 5px;"></span>
                                    <span class="tooltiptext"><?php echo esc_html__('Select the field to use for checking duplicate submissions. This field will be used to identify and prevent duplicate form entries.', CFDB7_PRO_TEXT_DOMAIN); ?></span>
                                </span>
                            </th>
                            <td>
                                <select name="avoid-field[<?php echo $cf7_id; ?>]" id="avoid-field">
                                    <option value=""><?php echo esc_html__('Select Field', CFDB7_PRO_TEXT_DOMAIN); ?></option>
                                    <?php 
                                    if(!empty($avoid_fields)){
                                        foreach($avoid_fields as $avoid_field){
                                            ?><option value="<?php echo $avoid_field; ?>" <?php selected($cfdb7_avoid_field, $avoid_field); ?>><?php echo $avoid_field; ?></option><?php
                                        }
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label for="excludes-fields"><?php echo esc_html__('Exclude fields', CFDB7_PRO_TEXT_DOMAIN); ?></label>
                                <span class="cfdb7-tooltip">
                                    <span class="dashicons dashicons-editor-help" style="color: #666; cursor: help; vertical-align: middle; margin-left: 5px;"></span>
                                    <span class="tooltiptext"><?php echo esc_html__('Select form fields that you want to exclude from being saved in the database. Excluded fields will not appear in the entries list.', CFDB7_PRO_TEXT_DOMAIN); ?></span>
                                </span>
                            </th>
                            <td>
                                <select name="excludes-fields[<?php echo $cf7_id; ?>][]" id="excludes-fields" multiple placeholder="Choose fields" data-allow-clear="1">
                                    <option></option>
                                    <?php 
                                    if(!empty($fields)){
                                        foreach($fields as $field){
                                            $is_selected = "";
                                            if(in_array($field, $cfdb7_excludes_fields)){
                                                $is_selected = "selected";
                                            }
                                            ?><option value="<?php echo $field; ?>" <?php echo $is_selected; ?>><?php echo $field; ?></option><?php
                                        }
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label for="enquiries-per-page"><?php echo esc_html__('Enquiries per page', CFDB7_PRO_TEXT_DOMAIN); ?></label>
                                <span class="cfdb7-tooltip">
                                    <span class="dashicons dashicons-editor-help" style="color: #666; cursor: help; vertical-align: middle; margin-left: 5px;"></span>
                                    <span class="tooltiptext"><?php echo esc_html__('Set the number of form entries to display per page in the entries list. Minimum value is 10.', CFDB7_PRO_TEXT_DOMAIN); ?></span>
                                </span>
                            </th>
                            <td>
                                <input type="number" name="enquiries-per-page[<?php echo $cf7_id; ?>]" id="enquiries-per-page" class="enquiries-per-page" value="<?php echo $enquiries_per_page; ?>" min="10" placeholder="10">
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <label for="character-limit"><?php echo esc_html__('Character Limit', CFDB7_PRO_TEXT_DOMAIN); ?></label>
                                <span class="cfdb7-tooltip">
                                    <span class="dashicons dashicons-editor-help" style="color: #666; cursor: help; vertical-align: middle; margin-left: 5px;"></span>
                                    <span class="tooltiptext"><?php echo esc_html__('Set the maximum number of characters to display for long text fields in the entries list. Minimum value is 20.', CFDB7_PRO_TEXT_DOMAIN); ?></span>
                                </span>
                            </th>
                            <td>
                                <input type="number" name="character-limit[<?php echo $cf7_id; ?>]" id="character-limit" class="character-limit" value="<?php echo $character_limit; ?>" min="20" placeholder="20">
                            </td>
                        </tr>
                        <?php 
                        do_action( 'cfdb7_setting_page_add_form_fields', $get_setting);
                        ?>
                        <tr>
                            <th colspan="2"><input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes', CFDB7_PRO_TEXT_DOMAIN); ?>"></th>
                            <?php wp_nonce_field('cfdb7_settings', 'cfdb7_setting_nonce'); ?>
                        </tr>
                        <?php
                    }else{
                        ?>
                        <div class="notice notice-error"><p><?php echo esc_html__( 'Please select a form.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
                        <?php
                    }
                }else{
                    ?>
                    <div class="notice notice-error"><p><?php echo esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
                    <?php
                }
            }
            ?>
        </table>
    </form>
</div>