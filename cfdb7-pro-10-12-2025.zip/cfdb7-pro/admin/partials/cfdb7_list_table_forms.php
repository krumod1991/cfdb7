<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

switch ( $filter_type ) {
    /**
     * Render the date filter form for filtering entries by date range.
     *
     * This block displays a form allowing the admin to filter entries by specifying a from and to date.
     * All input is sanitized and the form uses GET method for filtering.
     *
     * Coding Guide:
     * - Sanitize all incoming $_GET data.
     * - Use esc_url and esc_attr for outputting URLs and attributes.
     * - Use proper labels and accessibility for form fields.
     * - Use nonce for security if needed.
     *
     * @since 1.0.0
     * @param string $_GET['from_date'] Start date for filtering.
     * @param string $_GET['to_date'] End date for filtering.
    */
    case 'date_filter':
        $from_date = isset($_GET['from_date']) && !empty($_GET['from_date']) ? sanitize_text_field($_GET['from_date']) : '';
        $to_date = isset($_GET['to_date']) && !empty($_GET['to_date']) ? sanitize_text_field($_GET['to_date']) : '';
        ?>
        <form id="date-filter" method="GET" action="<?php echo esc_url($this->admin_page_url); ?>" novalidate="novalidate">
            <input type="hidden" name="page" value="<?php echo esc_attr($this->context); ?>" />
			<input type="hidden" name="cf7-id" value="<?php echo esc_attr($this->cf7_id); ?>" />
            <input type="hidden" name="nonce" value="<?php echo esc_attr($this->nonce); ?>" />
            <div class="form-group">
                <div class="form-label">
                    <label for="from_date"><?php echo esc_html__('From Date', CFDB7_PRO_TEXT_DOMAIN); ?></label>
                </div>
                <div class="form-input">
                    <input type="text" id="from_date" name="from_date" value="<?php echo $from_date; ?>"/>
                </div>
            </div>
            <div class="form-group">
                <div class="form-label">
                    <label for="to_date"><?php echo esc_html__('To Date', CFDB7_PRO_TEXT_DOMAIN); ?></label>
                </div>
                <div class="form-input">
                    <input type="text" id="to_date" name="to_date" value="<?php echo $to_date; ?>"/>
                </div>
            </div>
            <div class="form-group">
                <div class="form-input">
                    <input type="submit" name="search_entries" id="search_entries" class="button" value="<?php echo esc_html__('Search', CFDB7_PRO_TEXT_DOMAIN); ?>"/>
                </div>
            </div>
        </form>
        <?php
        break;
    /**
     * Render the display settings form for customizing field display in the entries table.
     *
     * This block allows the admin to rename fields, show/hide fields, and reorder fields for the entries table.
     * All input is sanitized and the form uses POST method for saving settings.
     *
     * Coding Guide:
     * - Sanitize all field names and values before use.
     * - Use esc_url and esc_attr for outputting URLs and attributes.
     * - Use wp_nonce_field for security against CSRF.
     * - Use submit_button for WordPress style consistency.
     * - Support drag-and-drop ordering and toggling fields.
     *
     * @since 1.0.0
     * @param array $this->field_names List of available field names.
     * @param array $this->rename_fields Renamed field values.
     * @param array $this->enable_fields Enabled/disabled field states.
     * @param array $this->field_order Custom field order.
    */
    case 'display_settings':
        if(!empty($this->field_names)){
            $current_fields = !empty($this->field_names) ? wp_list_pluck($this->field_names, 'field_name') : array();
            $current_fields = !empty($current_fields) ? array_map('sanitize_text_field', $current_fields) : array();

            $renamed_fields = $this->rename_fields;
            if(!empty($renamed_fields)){
                $clean_rename = array();
                foreach ($renamed_fields as $key => $val) {
                    $clean_rename[sanitize_text_field($key)] = sanitize_text_field($val);
                }
                $renamed_fields = $clean_rename;
            }

            $enabled_fields = $this->enable_fields;
            if(!empty($enabled_fields)){
                $clean_rename = array();
                foreach ($enabled_fields as $key => $val) {
                    $clean_rename[sanitize_text_field($key)] = sanitize_text_field($val);
                }
                $enabled_fields = $clean_rename;
            }

            $field_order = $this->field_order;
            $field_order = !empty($field_order) ? array_map('sanitize_text_field', $field_order) : array();
 
            $final_order = array();
            if (!empty($field_order)) {
                // First: fields that appear in $field_order (in that order)
                $exclude_fields = array();
                foreach ($field_order as $field_name) {
                    if(in_array($field_name, $current_fields)){
                        $final_order[] = $field_name;
                        $exclude_fields[] = $field_name;
                    }
                }
                // Second: remaining fields (not listed in $field_order)
                foreach ($current_fields as $field_name) {
                    if(!in_array($field_name, $exclude_fields)){
                        $final_order[] = $field_name;
                    }
                }
            } else {
                // Use default field order
                $final_order = $current_fields;
            }
            ?>
            <form id="save-display-settings" method="POST" action="<?php echo esc_url($this->admin_page_url); ?>" novalidate="novalidate">
                <input type="hidden" name="page" value="<?php echo esc_attr($this->context); ?>" />
			    <input type="hidden" name="cf7-id" value="<?php echo esc_attr($this->cf7_id); ?>" />
                <table border="1">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Field Name', CFDB7_PRO_TEXT_DOMAIN); ?></th>
                            <th><?php echo esc_html__('Rename Field', CFDB7_PRO_TEXT_DOMAIN); ?></th>
                            <th><?php echo esc_html__('Show/Hide Field', CFDB7_PRO_TEXT_DOMAIN); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        foreach($final_order as $field_name){
                            ?>
                            <tr class="ui-sortable-handle">
                                <td><?php echo esc_attr($field_name); ?></td>
                                <td><input type="text" name="rename_field[<?php echo esc_attr($field_name); ?>]" placeholder="<?php echo esc_html__('Rename field', CFDB7_PRO_TEXT_DOMAIN); ?>" value="<?php echo isset($renamed_fields[$field_name]) ? esc_attr($renamed_fields[$field_name]) : ''; ?>"></td>
                                <td>
                                    <label class="cfdb7-toggle-switch">
                                        <?php 
                                        $is_checked = "checked";
                                        if(!empty($enabled_fields)){
                                            $is_checked = isset($enabled_fields[$field_name]) ? 'checked' : '';
                                        }
                                        ?>
                                        <input type="checkbox" name="enable_field[<?php echo esc_attr($field_name); ?>]" <?php echo $is_checked; ?>>
                                        <span class="cfdb7-slider"></span>
                                    </label>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3">
                                <?php submit_button(esc_html__('Save Settings', CFDB7_PRO_TEXT_DOMAIN), 'secondary', 'display-settings', false); ?>
                                <?php wp_nonce_field('cfdb7_display_setting', 'cfdb7_display_setting_nonce'); ?>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </form>
            <?php
        }
        break;
    /**
     * Render the search filter form for filtering entries by field names and search term.
     *
     * This block displays a form allowing the admin to filter entries by selected fields and a search term.
     * All input is sanitized and the form uses GET method for filtering.
     *
     * Coding Guide:
     * - Sanitize all incoming $_GET data.
     * - Use esc_url and esc_attr for outputting URLs and attributes.
     * - Use proper labels and accessibility for form fields.
     * - Use nonce for security if needed.
     *
     * @since 1.0.0
     * @param array $_GET['field_names'] Selected field names for filtering.
     * @param string $_GET['s'] Search term for filtering entries.
    */
    case 'search_filter':
        $field_names = isset($_GET['field_names']) && !empty($_GET['field_names']) ? array_map('sanitize_text_field',$_GET['field_names']) : array();
        $search = isset($_GET['s']) && !empty($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        ?>
        <form id="search-filter" method="GET" action="<?php echo esc_url($this->admin_page_url); ?>" novalidate="novalidate">
            <input type="hidden" name="page" value="<?php echo esc_attr($this->context); ?>" />
			<input type="hidden" name="cf7-id" value="<?php echo esc_attr($this->cf7_id); ?>" />
            <input type="hidden" name="nonce" value="<?php echo esc_attr($this->nonce); ?>" />
            <div class="form-group">
                <div class="form-label">
                    <label for="field_name"><?php echo esc_html__('Field Names', CFDB7_PRO_TEXT_DOMAIN); ?></label>
                </div>
                <div class="form-input chosen-field" style="width:100%;">
                    <select name="field_names[]" id="field_name" multiple placeholder="<?php echo esc_html__('Choose fields', CFDB7_PRO_TEXT_DOMAIN); ?>" data-allow-clear="1">
                        <?php 
                        if(!empty($this->field_names)){
                            foreach($this->field_names as $field_name){
                                if($field_name['entry_count'] > 0){
                                    $is_selected = "";
                                    if(in_array($field_name['field_name'], $field_names)){
                                        $is_selected = "selected";
                                    }
                                    ?><option value="<?php echo esc_attr($field_name['field_name']); ?>" <?php echo $is_selected; ?>><?php echo esc_attr($field_name['field_name']); ?></option><?php
                                }
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="form-label">
                    <label for="search"><?php echo esc_html__('Search', CFDB7_PRO_TEXT_DOMAIN); ?></label>
                </div>
                <div class="form-input">
                    <input type="text" id="search" name="s" value="<?php echo $search; ?>" style="width:100%;"/>
                </div>
            </div>
            <div class="form-group">
                <div class="form-input">
                    <input type="submit" name="search_entries" id="search_entries" class="button" value="<?php echo esc_html__('Search', CFDB7_PRO_TEXT_DOMAIN); ?>"/>
                </div>
            </div>
        </form>
        <?php
        break;
    default:
        break;
}