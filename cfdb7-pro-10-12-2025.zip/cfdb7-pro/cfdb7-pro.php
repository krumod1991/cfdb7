<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://na
 * @since             1.0.0
 * @package           Cfdb7_Pro
 *
 * @wordpress-plugin
 * Plugin Name:       CFDB7 Pro
 * Description:       Easily save all Contact Form 7 submissions to the database. View, sort, export, and import data with ease. Customize field labels and manage entries efficiently using CSV files.
 * Version:           1.0.0
 * Author:            Krunal Modi
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       cfdb7-pro
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
if ( ! function_exists( 'is_plugin_active' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}
/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'CFDB7_PRO_VERSION', '1.0.0' );
/**
 * Define base plugin name
 */
define( 'CFDB7_PRO_BASE_NAME', plugin_basename(__FILE__) );
/**
 * Define base plugin path
 */
define( 'CFDB7_PRO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
/**
 * Define base plugin check related to activation
 */
if (is_plugin_active('contact-form-cfdb7/contact-form-cfdb-7.php')){
	define( 'CFDB7_ACTIVATED', true );
}else{
	define( 'CFDB7_ACTIVATED', false );
}
/**
 * Define text domain for wpml
 */
define( 'CFDB7_PRO_TEXT_DOMAIN', 'CFDB7_PRO_TEXT_DOMAIN' );
/**
 * 
 */
define( 'CFDB7_UPLOAD_FOLDER', 'cfdb7_csv' );
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-cfdb7-pro-activator.php
 */
function activate_cfdb7_pro() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-cfdb7-pro-activator.php';
	Cfdb7_Pro_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-cfdb7-pro-deactivator.php
 */
function deactivate_cfdb7_pro() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-cfdb7-pro-deactivator.php';
	Cfdb7_Pro_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_cfdb7_pro' );
register_deactivation_hook( __FILE__, 'deactivate_cfdb7_pro' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-cfdb7-pro.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_cfdb7_pro() {

	$plugin = new Cfdb7_Pro();
	$plugin->run();

}
run_cfdb7_pro();


add_action('admin_init', function() {
    if(isset($_GET['cfdb7_drop_tables'])){
        global $wpdb;
        // Find tables containing 'cfdb7'
        $tables = $wpdb->get_col( "SHOW TABLES LIKE '%cfdb7%'" );
        if (!empty( $tables )){
            echo "<pre>";
            print_r($tables);
            echo "</pre>";
            foreach ( $tables as $table ) {
                $wpdb->query( "DROP TABLE IF EXISTS `$table`" );
            }
            exit;
        }
    }
});