jQuery(document).ready(function () {
    jQuery("#cf7-id").change(function () {
        var cf7_id = jQuery(this).val();
        var current_url = new URL(window.location.href);
        current_url.searchParams.delete('cf7-id');
        if (cf7_id != "") {
            window.location = current_url + '&cf7-id=' + cf7_id;
        } else {
            window.location = current_url;
        }
    });

    jQuery('#excludes-fields').chosen({
        width: "100%",              // expand to full width of container (or set px)
        no_results_text: "No matches found", // text when filtering has no results
        placeholder_text_multiple: "Select fields"
    });
});