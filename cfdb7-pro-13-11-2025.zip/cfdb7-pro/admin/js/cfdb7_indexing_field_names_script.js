jQuery(document).ready(function () {
    jQuery("#cf7-id").change(function () {
        var cf7_id = jQuery(this).val();
        var current_url = new URL(window.location.href);
        current_url.searchParams.delete('cf7-id');
        if (cf7_id != "") {
            window.location = current_url + '&cf7-id=' + cf7_id;
        } else {
            window.location = current_url;
        }
    });

    jQuery("#cfdb7-indexing").click(function () {
        jQuery("#notice-1").html('');
        jQuery("#notice-2").html('');
        jQuery("#notice-3").html('');
        jQuery("#notice-4").html('');
        jQuery('.notice').removeClass('notice-error');
        jQuery('.notice').css('display', 'none');
        jQuery(".cfdb7-indexing-field-names .loader").css("display", 'flex');

        var cf7_id = jQuery("#cf7-id").val();
        cfdb7_trigger_indexing_field_names(cf7_id);
    });

    function cfdb7_trigger_indexing_field_names(cf7_id) {
        jQuery.ajax({
            url: cfdb7_params.ajax_url,
            data: {
                'action': 'cfdb7_indexing_entries_field_names',
                'cf7_id': cf7_id,
            },
            type: 'POST',
            success: function (response) {
                var result = JSON.parse(response);
                if (result.status == 'success') {
                    jQuery("#notice-1").html(result.message);
                    jQuery('.notice-1').addClass('notice-success');
                    jQuery('.notice-1').css('display', 'block');
                } else {
                    jQuery("#notice-1").html(result.message);
                    jQuery('.notice-1').addClass('notice-error');
                    jQuery('.notice-1').css('display', 'block');
                }
            },
            complete: function (data) {
                cfdb7_trigger_indexing_edit_entries_field_names(cf7_id);
            },
            fail: function () {
                cfdb7_trigger_indexing_edit_entries_field_names(cf7_id);
            }
        });
    }

    function cfdb7_trigger_indexing_edit_entries_field_names(cf7_id) {
        jQuery.ajax({
            url: cfdb7_params.ajax_url,
            data: {
                'action': 'cfdb7_indexing_edit_entries_field_names',
                'cf7_id': cf7_id,
            },
            type: 'POST',
            success: function (response) {
                var result = JSON.parse(response);
                if (result.status == 'success') {
                    jQuery("#notice-2").html(result.message);
                    jQuery('.notice-2').addClass('notice-success');
                    jQuery('.notice-2').css('display', 'block');
                } else {
                    jQuery("#notice-2").html(result.message);
                    jQuery('.notice-2').addClass('notice-error');
                    jQuery('.notice-2').css('display', 'block');
                }
            },
            complete: function (data) {
                cfdb7_trigger_indexing_delete_entries_field_names(cf7_id);
            },
            fail: function () {
                cfdb7_trigger_indexing_delete_entries_field_names(cf7_id);
            }
        });
    }

    function cfdb7_trigger_indexing_delete_entries_field_names(cf7_id) {
        jQuery.ajax({
            url: cfdb7_params.ajax_url,
            data: {
                'action': 'cfdb7_indexing_delete_entries_field_names',
                'cf7_id': cf7_id,
            },
            type: 'POST',
            success: function (response) {
                var result = JSON.parse(response);
                if (result.status == 'success') {
                    jQuery("#notice-3").html(result.message);
                    jQuery('.notice-3').addClass('notice-success');
                    jQuery('.notice-3').css('display', 'block');
                } else {
                    jQuery("#notice-3").html(result.message);
                    jQuery('.notice-3').addClass('notice-error');
                    jQuery('.notice-3').css('display', 'block');
                }
            },
            complete: function (data) {
                cfdb7_trigger_indexing_log_entries_field_names(cf7_id);
            },
            fail: function () {
                cfdb7_trigger_indexing_log_entries_field_names(cf7_id);
            }
        });
    }

    function cfdb7_trigger_indexing_log_entries_field_names(cf7_id) {
        jQuery.ajax({
            url: cfdb7_params.ajax_url,
            data: {
                'action': 'cfdb7_indexing_log_entries_field_names',
                'cf7_id': cf7_id,
            },
            type: 'POST',
            success: function (response) {
                var result = JSON.parse(response);
                if (result.status == 'success') {
                    jQuery("#notice-4").html(result.message);
                    jQuery('.notice-4').addClass('notice-success');
                    jQuery('.notice-4').css('display', 'block');
                } else {
                    jQuery("#notice-4").html(result.message);
                    jQuery('.notice-4').addClass('notice-error');
                    jQuery('.notice-4').css('display', 'block');
                }
            },
            complete: function (data) {
                jQuery(".cfdb7-indexing-field-names .loader").css("display", 'none');
            },
            fail: function () {
                jQuery(".cfdb7-indexing-field-names .loader").css("display", 'none');
            }
        });
    }
});