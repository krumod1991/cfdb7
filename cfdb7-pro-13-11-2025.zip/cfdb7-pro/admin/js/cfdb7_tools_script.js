jQuery(document).ready(function () {
    jQuery("#generate-tables").click(function () {
        jQuery.ajax({
            url: cfdb7_params.ajax_url,
            data: {
                'action': 'cfdb7_generate_tables',
            },
            type: 'POST',
            beforeSend: function (xhr) {
                jQuery(".cfdb7-tools .loader").css("display", 'flex');
            },
            success: function (data) {

            },
            complete: function () {
                jQuery(".cfdb7-tools .loader").css("display", 'none');
            },
            fail: function () {
                jQuery(".cfdb7-tools .loader").css("display", 'none');
            }
        });
    });
});