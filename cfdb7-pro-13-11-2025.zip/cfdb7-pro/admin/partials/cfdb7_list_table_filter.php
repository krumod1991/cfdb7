<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

switch ( $filter_type ) {
    case 'date_filter':
        $from_date = isset($_GET['from_date']) && !empty($_GET['from_date']) ? sanitize_text_field($_GET['from_date']) : '';
        $to_date = isset($_GET['to_date']) && !empty($_GET['to_date']) ? sanitize_text_field($_GET['to_date']) : '';
        ?>
        <div class="form-group">
            <div class="form-label">
                <label for="from_date"><?php echo __('From Date', CFDB7_PRO_TEXT_DOMAIN); ?></label>
            </div>
            <div class="form-input">
                <input type="text" id="from_date" name="from_date" value="<?php echo $from_date; ?>" form="wp-list-table"/>
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label for="to_date"><?php echo __('To Date', CFDB7_PRO_TEXT_DOMAIN); ?></label>
            </div>
            <div class="form-input">
                <input type="text" id="to_date" name="to_date" value="<?php echo $to_date; ?>" form="wp-list-table"/>
            </div>
        </div>
        <div class="form-group">
            <div class="form-input">
                <input type="submit" name="search_entries" id="search_entries" class="button" value="<?php echo __('Search', CFDB7_PRO_TEXT_DOMAIN); ?>" form="wp-list-table">
            </div>
        </div>
        <?php
        break;
    case 'display_settings':
        if(!empty($this->field_names)){
            $renamed_fields = $this->rename_fields;
            $enabled_fields = $this->enable_fields;
            ?>
            <table border="1">
                <thead>
                    <tr>
                        <th><?php echo __('Field Name', CFDB7_PRO_TEXT_DOMAIN); ?></th>
                        <th><?php echo __('Rename Field', CFDB7_PRO_TEXT_DOMAIN); ?></th>
                        <th><?php echo __('Show/Hide Field', CFDB7_PRO_TEXT_DOMAIN); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    foreach($this->field_names as $field_name){
                        ?>
                        <tr>
                            <td><?php echo esc_attr($field_name['field_name']); ?></td>
                            <td><input type="text" name="rename_field[<?php echo esc_attr($field_name['field_name']); ?>]" placeholder="<?php echo __('Rename field', CFDB7_PRO_TEXT_DOMAIN); ?>" value="<?php echo isset($renamed_fields[$field_name['field_name']]) ? esc_attr($renamed_fields[$field_name['field_name']]) : ''; ?>"></td>
                            <td>
                                <label class="cfdb7-toggle-switch">
                                    <?php 
                                    $is_checked = "checked";
                                    if(!empty($enabled_fields)){
                                        $is_checked = isset($enabled_fields[$field_name['field_name']]) ? 'checked' : '';
                                    }
                                    ?>
                                    <input type="checkbox" name="enable_field[<?php echo esc_attr($field_name['field_name']); ?>]" <?php echo $is_checked; ?>>
                                    <span class="cfdb7-slider"></span>
                                </label>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3">
                            <?php submit_button(__('Save Settings', CFDB7_PRO_TEXT_DOMAIN), 'secondary', 'display-settings', false); ?>
                        </td>
                    </tr>
                </tfoot>
            </table>
            <?php
        }
        break;
    case 'search_filter':
        $field_names = isset($_GET['field_names']) && !empty($_GET['field_names']) ? array_map('sanitize_text_field',$_GET['field_names']) : array();
        $search = isset($_GET['s']) && !empty($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        ?>
        <div class="form-group">
            <div class="form-label">
                <label for="field_name"><?php echo __('Field Names', CFDB7_PRO_TEXT_DOMAIN); ?></label>
            </div>
            <div class="form-input chosen-field" style="width:100%;">
                <select name="field_names[]" id="field_name" multiple placeholder="<?php echo __('Choose fields', CFDB7_PRO_TEXT_DOMAIN); ?>" data-allow-clear="1" form="wp-list-table">
                    <?php 
                    if(!empty($this->field_names)){
                        foreach($this->field_names as $field_name){
                            if($field_name['entry_count'] > 0){
                                $is_selected = "";
                                if(in_array($field_name['field_name'], $field_names)){
                                    $is_selected = "selected";
                                }
                                ?><option value="<?php echo $field_name['field_name']; ?>" <?php echo $is_selected; ?>><?php echo $field_name['field_name']; ?></option><?php
                            }
                        }
                    }
                    ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label for="search"><?php echo __('Search', CFDB7_PRO_TEXT_DOMAIN); ?></label>
            </div>
            <div class="form-input">
                <input type="text" id="search" name="s" value="<?php echo $search; ?>" form="wp-list-table"/>
            </div>
        </div>
        <div class="form-group">
            <div class="form-input">
                <input type="submit" name="search_entries" id="search_entries" class="button" value="<?php echo __('Search', CFDB7_PRO_TEXT_DOMAIN); ?>" form="wp-list-table">
            </div>
        </div>
        <?php
        break;
    default:
        break;
}