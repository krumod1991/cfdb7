<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

$cf7_id = isset($_POST['cf7-id']) && !empty($_POST['cf7-id']) ? intval(sanitize_text_field($_POST['cf7-id'])) : "";
if(!empty($cf7_id)){
	$user_info = cfdb7_get_logged_in_user_info();
	$capabilities = $user_info['capabilities'];

	$has_import_capability = false;
	if(in_array("manage_options", $capabilities)){
		$has_import_capability = true;
	}
	if(in_array("cfdb7_form_import_entry_".$cf7_id, $capabilities)){
		$has_import_capability = true;
	}
	//Check import capability for current user
	if($has_import_capability == true){
		$csv_fields = array();
		$csv_data = array();
		if(isset($_FILES['uploaded_csv']) && !empty($_FILES['uploaded_csv'])){
			$allowed_extention = array('text/plain', 'text/csv', 'application/vnd.ms-excel', 'application/csv');
			$file_type = mime_content_type($_FILES["uploaded_csv"]['tmp_name']);
			if(in_array($file_type,$allowed_extention)){
				// Read and parse CSV
				if(($handle = fopen($_FILES["uploaded_csv"]['tmp_name'], 'r')) !== false){
					//Get Header details from CSV sheet
					$csv_fields = fgetcsv($handle);
					$temp = array();
					if(!empty($csv_fields)){
						foreach ($csv_fields as $key => $value) {
							if($key == 0){
								$result = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $value);
								$temp[] = $result;
								//For remove u+fffd like � character from first field
							}else{
								$temp[] = $value;
							}
						}
					}
					$csv_fields = $temp;

					while (($rows = fgetcsv($handle)) !== false){
						$row_data = array(); 
						foreach($rows as $rkey => $rvalue){
							$row_data[$csv_fields[$rkey]] = sanitize_text_field($rvalue);
						}
						$csv_data[] = $row_data;
					}
					fclose($handle);
				}
			}
		}

		if(!empty($csv_data) && !empty($csv_fields)){
			global $wpdb;
			$obj = new Cfdb7_Queries();
			$obj->init_cfdb7_tables();

			$tags = cfdb7_get_form_tags($cf7_id);
			//Set fields list
			$cf7_tags = array();
			if(!empty($tags)){
				foreach ( $tags as $tag ){
					if(!empty($tag->name)){
						$cf7_tags[$tag->name] = $tag->basetype;
					}
				}
			}
			$cf7_fields = array_keys($cf7_tags);

			//Check csv field exist in contact form 7 fields
			$field_fail_count = 0;
			foreach($csv_fields as $csv_field){
				if(!in_array($csv_field, $cf7_fields)){
					$field_fail_count++;
				}
			}
			
			// Check if all values of $array1 exist in $array2
			if($field_fail_count == 0 && !empty($cf7_tags)){
				//$form_setting use to applied setting to form data
				$form_setting = cfdb7_get_form_setting($wpdb, $obj, $cf7_id);

				$user_info = cfdb7_get_logged_in_user_info();
				$user_id = $user_info['user_id'];
				$display_name = $user_info['display_name'];

				$date_time = current_time("Y-m-d H:i:s");
				$ip_address = cfdb7_get_ip_address();

				foreach($csv_data as $field_data){
					if(!empty($field_data)){
						$original_field_data = $field_data;
						$field_data = apply_filters( 'cfdb7_sanitize_field_data', $field_data);

						$original_entry_fields = array();
						$original_entry_fields = apply_filters( 'cfdb7_form_data_after_applied_field_type', $original_entry_fields, $field_data, $cf7_tags);

						$form_entry = array(
							'form_post_id' => $cf7_id,
							'form_value' => maybe_serialize($field_data),
							'form_date' => current_time("Y-m-d H:i:s"),
							'lead_source' => 'import',
						);
						$form_entry_format = array("%s","%s","%s","%s");
						
						$db7_forms_id = $obj->save_db7_forms_entry($wpdb, $form_entry, $form_entry_format);

						$logger = array();
						$logger['date_time'] = $date_time;
						$logger['lead_source'] = 'import';
						$logger['form_setting'] = $form_setting;
						$logger['db7_forms_id'] = $db7_forms_id;
						$logger['original_entry'] = $field_data;
						$logger['original_entry_fields'] = $original_entry_fields;
						$logger['form_entry'] = $form_entry;

						if (!empty($db7_forms_id)){

							$field_data = apply_filters( 'cfdb7_form_data_after_applied_settings', $field_data, $form_setting, $cf7_id, $obj, $wpdb);
							$logger['proceed_entry'] = $field_data;

							$proceed_entry_fields = array();
							$proceed_entry_fields = apply_filters( 'cfdb7_form_data_after_applied_field_type', $proceed_entry_fields, $field_data, $cf7_tags);
							$logger['proceed_entry_fields'] = $proceed_entry_fields;

							if(!empty($field_data)){

								$entry_details = array(
									'db7_forms_id' => $db7_forms_id,
									'lead_source' => 'import',
									'form_submissions' => maybe_serialize($field_data),
									'form_submission_fields' => maybe_serialize($proceed_entry_fields),
									'submit_by' => $user_id,
									'submit_display_name' => $display_name,
									'submit_date_time' => $date_time,
									'submit_ip_address' => $ip_address,
								);
								$entry_details_format = array("%s","%s","%s","%s","%s","%s","%s","%s");
								$entry_id = $obj->save_cfdb7_entry($wpdb, $cf7_id, $entry_details, $entry_details_format);
								$logger['entry_id'] = $entry_id;
								$logger['entry_details'] = $entry_details;

								if (!empty($entry_id)){
									foreach($field_data as $field_name => $field_value){
										$field_name = sanitize_text_field($field_name);
										//Convert special character to html entity
										//It is prevent XSS attack
										$field_value = htmlspecialchars($field_value);
										//It is prevent JS injection
										$field_value = sanitize_textarea_field(trim($field_value));

										$entry_submission = array(
											'entry_id' => $entry_id,
											'db7_forms_id' => $db7_forms_id,
											'lead_source' => 'import',
											'field_name' => $field_name,
											'field_type' => isset($cf7_tags[$field_name]) && !empty($cf7_tags[$field_name]) ? $cf7_tags[$field_name] : "text",
											'field_value' => $field_value,
										);
										$entry_submission_format = array("%s","%s","%s","%s","%s","%s");
										$obj->save_cfdb7_entry_submissions($wpdb, $cf7_id, $entry_submission, $entry_submission_format);
									}

									foreach($original_field_data as $original_field_name => $original_field_value){
										$original_field_name = sanitize_text_field($original_field_name);
										//Convert special character to html entity
										//It is prevent XSS attack
										$original_field_value = htmlspecialchars($original_field_value);
										//It is prevent JS injection
										$original_field_value = sanitize_textarea_field(trim($original_field_value));

										$entry_submission = array(
											'entry_id' => $entry_id,
											'db7_forms_id' => $db7_forms_id,
											'lead_source' => 'import',
											'field_name' => $original_field_name,
											'field_type' => isset($cf7_tags[$original_field_name]) && !empty($cf7_tags[$original_field_name]) ? $cf7_tags[$original_field_name] : "text",
											'field_value' => $original_field_value,
										);
										$entry_submission_format = array("%s","%s","%s","%s","%s","%s");
										$obj->save_cfdb7_log_submissions($wpdb, $cf7_id, $entry_submission, $entry_submission_format);
									}

									do_action( 'cfdb7_after_save_entry', $entry_details, $entry_id, $cf7_id, $obj, $wpdb);
								}
							}
						}
						//Save logs for import entries
						$obj->save_entry_log($wpdb, $cf7_id, $logger);
					}
				}
				
				do_action( 'cfdb7_save_report_field_for_field_name_options', $csv_fields, $cf7_id, $obj, $wpdb);
				
				?>
				<div class="notice notice-success is-dismissible"><p><?php echo __( 'Data import successfully.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
				<?php
			}else{
				?>
				<div class="notice notice-error is-dismissible"><p><?php echo __( 'Invalid CSV file.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
				<?php
			}
		}
	}
}

?>