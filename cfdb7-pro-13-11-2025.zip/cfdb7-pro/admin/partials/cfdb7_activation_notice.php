<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}
?>
<div class="notice notice-warning">
	<p><?php echo __('Please activate the Contact Form 7 Database Addon – CFDB7 to ensure full functionality.', CFDB7_PRO_TEXT_DOMAIN); ?> <a href="https://wordpress.org/plugins/contact-form-cfdb7/" target="_blank"><?php echo __('Click here to download it.', CFDB7_PRO_TEXT_DOMAIN); ?></a></p>
</div>