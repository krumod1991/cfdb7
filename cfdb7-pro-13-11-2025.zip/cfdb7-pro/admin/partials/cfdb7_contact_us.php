<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

wp_enqueue_style( 'cfdb7_contact_us_style' );
?>
<div class="wrap cfdb7-contact-us">
    <h1 class="wp-heading-inline"><?php echo __('Contact Us', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
</div>
