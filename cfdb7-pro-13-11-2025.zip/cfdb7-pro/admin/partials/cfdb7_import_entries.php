<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

if(isset($_POST)){
    include plugin_dir_path(__FILE__).'cfdb7_import_request.php';
}

$cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? sanitize_text_field($_GET['cf7-id']) : "";
$url_args = array('page' => $_GET['page']);
if(!empty($cf7_id)){
	$url_args['cf7-id'] = $cf7_id;
}
$admin_page_url = add_query_arg( $url_args, admin_url().'admin.php' );

$user_info = cfdb7_get_logged_in_user_info();
$capabilities = $user_info['capabilities'];

wp_enqueue_style( 'cfdb7_import_entries_style' );
wp_enqueue_script( 'cfdb7_import_entries_script' );

?>
<div class="wrap cfdb7-import-entries">
    <h1 class="wp-heading-inline"><?php echo __('Import CSV', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
	<form method="post" id="import_data" action="<?php echo $admin_page_url; ?>" novalidate="novalidate" enctype="multipart/form-data">
		<table class="form-table">
			<tr class="form-field">
                <th><label for="cf7-id"><?php echo __('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></label></th>
                <td>
                    <select name="cf7-id" id="cf7-id">
                        <option value=""><?php echo __('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></option>
                        <?php 
                        if(!empty($forms_list)){
                            foreach($forms_list as $form){
                                $is_selected = "";
                                if(!empty($cf7_id)){
                                    if($cf7_id == $form->ID){
                                        $is_selected = "selected";
                                    }
                                }
                                
                                if(in_array("cfdb7_form_import_entry_".$form->ID, $capabilities) || in_array("manage_options", $capabilities)){
                                    ?><option value="<?php echo $form->ID; ?>" <?php echo $is_selected; ?>><?php echo $form->post_title; ?></option><?php
                                }
                            }
                        }
                        ?>
                    </select>
                </td>
            </tr>
		</table>
        <?php 
        if(!empty($cf7_id)){
            $tags = cfdb7_get_form_tags($cf7_id);
            //Set fields list
            $fields = array();
            if(!empty($tags)){
                foreach ( $tags as $tag ){
                    if(!empty($tag->name)){
                        if($tag->basetype != "file"){
                            $fields[] = array(
                                'field_name' => $tag->name,
                                'field_type' => $tag->basetype,
                            );
                        }
                    }
                }
            }

            if(!empty($fields)){
                ?>
                <table class="form-table inner-row wrap">
                    <tr class="form-field">
                        <th><?php echo __('Field Name', CFDB7_PRO_TEXT_DOMAIN); ?></th>
                        <th><?php echo __('Field Type', CFDB7_PRO_TEXT_DOMAIN); ?></th>
                    </tr>
                    <?php 
                    foreach($fields as $field){
                        ?>
                        <tr class="form-field">
                            <td><?php echo $field['field_name']; ?></td>
                            <td><?php echo $field['field_type']; ?></td>
                        </tr>
                        <?php
                    }
                    ?>
                </table>
                <div class="notice notice-error" style="display:none;"><p id="notice"></p></div>
                <table class="form-table">
                    <tr>
                        <td><?php echo __('Upload CSV', CFDB7_PRO_TEXT_DOMAIN); ?></td>
                        <td><input type="file" name="uploaded_csv" id="upload_csv" accept=".csv"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" name="submit" value="<?php echo __('Import Data', CFDB7_PRO_TEXT_DOMAIN); ?>" class="button button-primary"></td>
                    </tr>
                </table>
                <?php
            }
        }
        ?>
	</form>
</div>