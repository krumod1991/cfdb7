<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

$cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? sanitize_text_field($_GET['cf7-id']) : "";
$url_args = array('page' => $_GET['page']);
if(!empty($cf7_id)){
	$url_args['cf7-id'] = $cf7_id;
}
$admin_page_url = add_query_arg( $url_args, admin_url().'admin.php' );

if (!class_exists('WP_List_Table')) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

wp_enqueue_style('cfdb7_magnific_popup_style');
wp_enqueue_style('jquery-ui-css');
wp_enqueue_style('cfdb7_chosen_style');
wp_enqueue_script('cfdb7_magnific_popup_script');
wp_enqueue_script('jquery-ui-datepicker');
wp_enqueue_script('cfdb7_chosen_script');

class Custom_WP_List_Table extends WP_List_Table {
    private $cf7_id;
    private $wpdb;
    private $obj;
    private $user_id;
    private $form_settings = array();
    private $field_names = array();
    private $rename_fields = array();
    private $enable_fields = array();
    private $edit_capability = "";
    private $delete_capability = "";

    public function __construct($obj_data) {
        parent::__construct([
            'singular' => 'item',
            'plural'   => 'items',
            'ajax'     => false
        ]);

        $context = sanitize_text_field($_GET['page']);

        $this->cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? sanitize_text_field($_GET['cf7-id']) : "";;
        $this->wpdb = $obj_data['wpdb'];
        $this->obj = $obj_data['obj'];

        $user_info = $obj_data['user_info'];
		$this->user_id = $user_info['user_id'];

        $this->edit_capability = $obj_data['edit_capability'];
        $this->delete_capability = $obj_data['delete_capability'];

        $this->form_settings = $this->obj->get_cfdb7_form_setting($this->wpdb, $this->cf7_id);
        $this->field_names = $this->obj->get_cfdb7_report_field_name_options($this->wpdb, $this->cf7_id);

        $display_settings = $this->obj->get_cfdb7_form_display_settings($this->wpdb, $this->cf7_id, $this->user_id, $context);
        $this->rename_fields = array();
        $this->enable_fields = array();
        if(!empty($display_settings)){
            $saved_settings = isset($display_settings['settings']) && !empty($display_settings['settings']) ? maybe_unserialize($display_settings['settings']) : array();
            if(!empty($saved_settings)){
                $this->rename_fields = isset($saved_settings['rename_field']) ? $saved_settings['rename_field'] : array();    
                $this->enable_fields = isset($saved_settings['enable_field']) ? $saved_settings['enable_field'] : array();
            }
        }
    }

    public function get_columns() {
        $columns = array();
        if($this->delete_capability == "exist"){
            $columns['cb'] = '<input type="checkbox" />';
        }
        $columns['entry_cta'] = __('Entry CTA', CFDB7_PRO_TEXT_DOMAIN);
        $columns['lead_source'] = __('Lead Source', CFDB7_PRO_TEXT_DOMAIN);

        if(!empty($this->field_names)){
            $rename_fields = !empty($this->rename_fields) ? $this->rename_fields : array();
            $enable_fields = !empty($this->enable_fields) ? $this->enable_fields : array();
            foreach($this->field_names as $field_name){
                if(!empty($enable_fields)){
                    if(isset($enable_fields[$field_name['field_name']])){
                        $columns[$field_name['field_name']] = isset($rename_fields[$field_name['field_name']]) && !empty($rename_fields[$field_name['field_name']]) ? esc_html($rename_fields[$field_name['field_name']]) : esc_html($field_name['field_name']);
                    }
                }else{
                    $columns[$field_name['field_name']] = isset($rename_fields[$field_name['field_name']]) && !empty($rename_fields[$field_name['field_name']]) ? esc_html($rename_fields[$field_name['field_name']]) : esc_html($field_name['field_name']);
                }
            }
        }
        $columns['submit_date_time'] = __('Submit Date Time', CFDB7_PRO_TEXT_DOMAIN);
        $columns['edit_date_time'] = __('Edit Date Time', CFDB7_PRO_TEXT_DOMAIN);
        $columns['submit_ip_address'] = __('Submit Ip Address', CFDB7_PRO_TEXT_DOMAIN);
        return $columns;
    }

    public function column_cb( $item ) {
        if($this->delete_capability == "exist"){
            return sprintf(
                '<input type="checkbox" name="ids[]" value="%s" />',
                $item['ID']
            );
        }else{
            return '';
        }
    }

    public function column_default($item, $column_name) {
        if(isset($item[$column_name])){
            switch ($column_name) {
                case 'lead_source':
                    return $item[$column_name];
                case 'submit_date_time':
                case 'edit_date_time':
                    return $item[$column_name];
                case 'submit_ip_address':
                    return $item[$column_name];
                default:
                    return $item[$column_name];
            }
        }else{
            switch ($column_name){
                case 'entry_cta':
                    return $this->cfdb7_entry_ctas($this->edit_capability, $item['ID']);
                default:
                    return "";
            }
        }
    }

    public function cfdb7_entry_ctas($edit_capability, $entry_id){
        ?><input type="button" class="button cfdb7-view-entry" data-index='<?php echo $entry_id; ?>' data-cf7_id='<?php echo $this->cf7_id; ?>' value="<?php echo __('View', CFDB7_PRO_TEXT_DOMAIN); ?>"><?php
        if($edit_capability == "exist"){
            ?><input type="button" class="button cfdb7-edit-entry" data-index='<?php echo $entry_id; ?>' data-cf7_id='<?php echo $this->cf7_id; ?>' value="<?php echo __('Edit', CFDB7_PRO_TEXT_DOMAIN); ?>"><?php
        }
        ?><input type="button" class="button cfdb7-view-edit-history" data-index='<?php echo $entry_id; ?>' data-cf7_id='<?php echo $this->cf7_id; ?>' value="<?php echo __('View Edit History', CFDB7_PRO_TEXT_DOMAIN); ?>"><?php
    }

    public function get_bulk_actions() {
        return array(
            'delete' => 'Delete',
            'export' => 'Export'
        );
    }

    public function no_items() {
        _e( 'No enquiries found.', CFDB7_PRO_TEXT_DOMAIN );
    }

    public function prepare_items() {
        $enquiries_per_page = 10;
        $character_limit = 30;
        if(!empty( $this->form_settings)){
            $form_settings = isset($form_settings['settings']) && !empty($form_settings['settings']) ? maybe_unserialize($form_settings['settings']) : array();
            $enquiries_per_page = isset($form_settings['enquiries_per_page']) && !empty($form_settings['enquiries_per_page']) ? $form_settings['enquiries_per_page'] : 10;
            $character_limit = isset($form_settings['character_limit']) && !empty($form_settings['character_limit']) ? $form_settings['character_limit'] : 30;
        }

        $per_page = $enquiries_per_page;
        $current_page = $this->get_pagenum();

        $from_date = !empty($_GET['from_date']) ? sanitize_text_field($_GET['from_date']) : '';
        $to_date   = !empty($_GET['to_date'])   ? sanitize_text_field($_GET['to_date'])   : '';
        $field_names = isset($_GET['field_names']) && !empty($_GET['field_names']) ? $_GET['field_names'] : array();
		$field_names = array_map( 'sanitize_text_field', (array) $field_names );
		$search_value = isset($_GET['s']) && !empty($_GET['s']) ? sanitize_text_field(trim($_GET['s'])) : "";

        if (!empty($from_date) && !empty($to_date) && strtotime($from_date) > strtotime($to_date)) {
            add_settings_error('date_filter_error', 'invalid_date_range', __('Invalid date range: From Date is later than To Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        } else if (!empty($from_date) && empty($to_date)) {
            add_settings_error('date_filter_error', 'missing_to_date', __('Kindly select To Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        } else if (empty($from_date) && !empty($to_date)) {
            add_settings_error('date_filter_error', 'missing_from_date', __('Kindly select From Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        }

        $search_input = array();
        if(!empty($from_date) || !empty($to_date) || !empty($field_names) || !empty($search_value)){
            $search_input = array(
                'from_date' => $from_date,
                'to_date'   => $to_date,
                'field_names' => $field_names,
                's' => $search_value,
            );
        }
        $all_data = $this->get_data($search_input);
        
        $total_items = count($all_data);

        // Pagination
        $paged_data_before = array_slice($all_data, ($current_page - 1) * $per_page, $per_page);

        $paged_data_after = array();
        if(!empty($paged_data_before)){
            foreach($paged_data_before as $data){
                $entry_data = maybe_unserialize($data['form_submissions']);
                $form_submission_fields = maybe_unserialize($data['form_submission_fields']);

                $row = array(
                    'ID' => esc_html($data['entry_id']),
                    'lead_source' => esc_html($data['lead_source']),
                );
                if(!empty($this->field_names)){
                    foreach($this->field_names as $field_name){
                        $field_key = $field_name['field_name'];
                        //Get field type of form fields
                        $field_type = isset($form_submission_fields[$field_key]) && !empty($form_submission_fields[$field_key]) ? $form_submission_fields[$field_key] : '';
                        if(!empty($field_type)){
                            if($field_type == "file"){
                                $field_value = isset($entry_data[$field_key]) && !empty($entry_data[$field_key]) ? esc_url($entry_data[$field_key]) : '';
                                if(filter_var($field_value, FILTER_VALIDATE_URL) !== false){
                                    $row[$field_key] = '<a href="'.esc_url($field_value).'" target="_blank" title="'.esc_url($field_value).'" download>'.esc_html(basename($field_value)).'</a>';
                                }
                            }else{
                                $field_value = isset($entry_data[$field_key]) && !empty($entry_data[$field_key]) ? esc_html(html_entity_decode($entry_data[$field_key])) : '';
                                if(strlen($field_value) > $character_limit){
                                    $row[$field_key] = esc_html(substr($field_value, 0, $character_limit)).'...';
                                }else{
                                    $row[$field_key] = $field_value;
                                }
                            }
                        }
                    }
                }
                $row['submit_date_time'] = date("d-m-Y H:i:s", strtotime($data['submit_date_time']));
                $row['edit_date_time'] = isset($data['edit_date_time']) && !empty($data['edit_date_time']) ? date("d-m-Y H:i:s", strtotime($data['edit_date_time'])) : "";
                $row['submit_ip_address'] = $data['submit_ip_address'];
                $paged_data_after[] = $row;
            }
        }

        $this->items = $paged_data_after;

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ]);

        $this->_column_headers = [$this->get_columns(), [], []];
    }

    public function process_bulk_action() {
        if ( empty( $_POST['ids'] ) ) return;
        $ids = array_map( 'intval', $_POST['ids'] );

        if ( 'delete' === $this->current_action() ) {
            // Delete logic here
            //echo '<div class="updated notice"><p>Deleted IDs: ' . implode( ', ', $ids ) . '</p></div>';
        }

        if ( 'export' === $this->current_action() ) {
            // Export CSV
            // header( 'Content-Type: text/csv' );
            // header( 'Content-Disposition: attachment; filename="export.csv"' );
            // $out = fopen( 'php://output', 'w' );
            // fputcsv( $out, ['ID', 'Name', 'Type'] );
            // foreach ( $this->data as $row ) {
            //     if ( in_array( $row['ID'], $ids ) ) {
            //         fputcsv( $out, $row );
            //     }
            // }
            // fclose( $out );
            exit;
        }
    }

    public function get_data($search_input = array()) {
        $cf7_id = $this->cf7_id;
        $wpdb = $this->wpdb;
        $obj = $this->obj;  

        $data = $obj->get_cfdb7_form_entries($wpdb, $cf7_id, $search_input);
        return $data;
    }

    public function get_display_setting(){
        $filter_type = 'display_settings';
        include CFDB7_PRO_PLUGIN_DIR . 'admin/partials/cfdb7_list_table_filter.php';
    }

    public function get_date_filters() {
        $filter_type = "date_filter";
        include CFDB7_PRO_PLUGIN_DIR . 'admin/partials/cfdb7_list_table_filter.php';
    }

    public function get_search_filter(){
        $filter_type = "search_filter";
        include CFDB7_PRO_PLUGIN_DIR . 'admin/partials/cfdb7_list_table_filter.php';
    }
}


$obj_data = array(
    'wpdb' => $wpdb,
    'obj' => $obj,
    'user_info' => $user_info,
    'edit_capability' => $edit_capability,
    'delete_capability' => $delete_capability,
);

$table = new Custom_WP_List_Table($obj_data);
$table->prepare_items();
?>
<div class="wrap cfdb7-entries-list-table">
	<h3><?php echo __('View Submissions', CFDB7_PRO_TEXT_DOMAIN); ?></h3>
	<div class="loader" style="display:none;"></div>
	<div id="cfdb7-entries-ctas-container">
		<button class="display-settings" class="button"><?php echo __('Display Settings', CFDB7_PRO_TEXT_DOMAIN); ?></button>
		<button class="reset-settings" class="button"><?php echo __('Reset All', CFDB7_PRO_TEXT_DOMAIN); ?></button>
	</div>
	<div id="display-settings-container">
		<form id="save-display-settings" method="POST" action="<?php echo $admin_page_url; ?>" novalidate="novalidate">
			<input type="hidden" name="page" value="<?php echo esc_attr(sanitize_text_field($_GET['page'])); ?>" />
			<input type="hidden" name="cf7-id" value="<?php echo esc_attr($cf7_id); ?>" />
			<?php $table->get_display_setting(); ?>
		</form>
	</div>
	<div id="date-filter-container">
		<?php $table->get_date_filters(); ?>
	</div>
	<div id="search-filter-container">
		<?php $table->get_search_filter(); ?>
	</div>
	<div id="wp-list-table-container">
		<form id="wp-list-table" method="get" action="<?php echo $admin_page_url; ?>" novalidate="novalidate">
			<input type="hidden" name="page" value="<?php echo esc_attr(sanitize_text_field($_GET['page'])); ?>" />
			<input type="hidden" name="cf7-id" value="<?php echo esc_attr($cf7_id); ?>" />
			<?php $table->display(); ?>
		</form>
	</div>
</div>
<div id="popup-content" class="mfp-hide">
	<div class="entries-popup-container">
	</div>
</div>