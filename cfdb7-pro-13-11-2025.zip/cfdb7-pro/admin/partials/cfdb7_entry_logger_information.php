<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

global $wpdb;
$obj = new Cfdb7_Queries();
$obj->init_cfdb7_tables();

$logger_entry = $get_setting = $obj->get_cfdb7_log_entry($wpdb, $cf7_id, $index);
if(!empty($logger_entry)){
	$form_setting = isset($logger_entry['form_setting']) && !empty($logger_entry['form_setting']) ? maybe_unserialize($logger_entry['form_setting']) : array();
	
	$avoid_duplicate_submission = "";
	$avoid_field = "";
	$excludes_fields = "";
	if(!empty($form_setting)){
		$avoid_duplicate_submission = isset($form_setting['avoid_duplicate_submission']) && !empty($form_setting['avoid_duplicate_submission']) ? $form_setting['avoid_duplicate_submission'] : "";
        
		$avoid_field = isset($form_setting['avoid_field']) && !empty($form_setting['avoid_field']) ? $form_setting['avoid_field'] : "";
    	
		$excludes_fields = isset($form_setting['excludes_fields']) && !empty($form_setting['excludes_fields']) ? $form_setting['excludes_fields'] : array();
		$excludes_fields = !empty($excludes_fields) ? implode(",", $excludes_fields) : "";
	}
	?>
	<table border="1" class="logger-setting-information">
		<tr>
			<td><?php echo __('Avoid duplicate submission', CFDB7_PRO_TEXT_DOMAIN); ?></td>
			<td><?php echo $avoid_duplicate_submission; ?></td>
		</tr>
		<tr>
			<td><?php echo __('Avoid field', CFDB7_PRO_TEXT_DOMAIN); ?></td>
			<td><?php echo $avoid_field; ?></td>
		</tr>
		<tr>
			<td><?php echo __('Exclude fields', CFDB7_PRO_TEXT_DOMAIN); ?></td>
			<td><?php echo $excludes_fields; ?></td>
		</tr>
	</table>
	<?php

	$original_entry = isset($logger_entry['original_entry']) && !empty($logger_entry['original_entry']) ? maybe_unserialize($logger_entry['original_entry']) : array();
	$original_entry_fields = isset($logger_entry['original_entry_fields']) && !empty($logger_entry['original_entry_fields']) ? maybe_unserialize($logger_entry['original_entry_fields']) : array();
	if(!empty($original_entry)){
		?>
		<table border="1" class="logger-original-information">
			<thead>
				<tr>
					<th><?php echo __('Field Name', CFDB7_PRO_TEXT_DOMAIN); ?></th>
					<th><?php echo __('Field Value', CFDB7_PRO_TEXT_DOMAIN); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php 
				foreach($original_entry as $entry_name => $entry_value){
					$field_type = isset($original_entry_fields[$entry_name]) && !empty($original_entry_fields[$entry_name]) ? $original_entry_fields[$entry_name] : '';
					if($field_type == 'file'){
						$entry_value = '<a href="'.esc_url($entry_value).'" target="_blank">'.basename($entry_value).'</a>';
					}	
					?>
					<tr>
						<td><?php echo $entry_name; ?></td>
						<td><?php echo $entry_value; ?></td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
		<?php
	}

	$proceed_entry = isset($logger_entry['proceed_entry']) && !empty($logger_entry['proceed_entry']) ? maybe_unserialize($logger_entry['proceed_entry']) : array();
	$proceed_entry_fields = isset($logger_entry['proceed_entry_fields']) && !empty($logger_entry['proceed_entry_fields']) ? maybe_unserialize($logger_entry['proceed_entry_fields']) : array();
	if(!empty($proceed_entry)){
		?>
		<table border="1" class="logger-proceed-information">
			<thead>
				<tr>
					<th><?php echo __('Field Name', CFDB7_PRO_TEXT_DOMAIN); ?></th>
					<th><?php echo __('Field Value', CFDB7_PRO_TEXT_DOMAIN); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php 
				foreach($proceed_entry as $entry_name => $entry_value){
					$field_type = isset($proceed_entry_fields[$entry_name]) && !empty($proceed_entry_fields[$entry_name]) ? $proceed_entry_fields[$entry_name] : '';
					if($field_type == 'file'){
						$entry_value = '<a href="'.esc_url($entry_value).'" target="_blank">'.basename($entry_value).'</a>';
					}
					?>
					<tr>
						<td><?php echo $entry_name; ?></td>
						<td><?php echo $entry_value; ?></td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
		<?php
	}
}