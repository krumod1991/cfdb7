<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

wp_enqueue_style('cfdb7_indexing_entries_style');
wp_enqueue_script('cfdb7_indexing_entries_script');
wp_enqueue_style('cfdb7_magnific_popup_style');
wp_enqueue_script('cfdb7_magnific_popup_script');

$cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? sanitize_text_field($_GET['cf7-id']) : "";
?>
<div class="wrap cfdb7-indexing-entries">
	<div class="loader" style="display:none;"></div>
	<div class="notice" style="display:none;"><p id="notice"></p></div>
    <h1 class="wp-heading-inline"><?php echo __('Indexing Entries', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
	<table class="form-table">
		<tr class="form-field">
			<th><label for="cf7-id"><?php echo __('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></label></th>
			<td>
				<select name="cf7-id" id="cf7-id">
					<option value=""><?php echo __('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></option>
					<?php 
					if(!empty($forms_list)){
						foreach($forms_list as $form){
							$is_selected = "";
							if(!empty($cf7_id)){
								if($cf7_id == $form->ID){
									$is_selected = "selected";
								}
							}
							
							?><option value="<?php echo $form->ID; ?>" <?php echo $is_selected; ?>><?php echo $form->post_title; ?></option><?php
						}
					}
					?>
				</select>
			</td>
		</tr>
		<?php 
		if(!empty($cf7_id)){
			?>
			<tr class="form-field">
				<th></th>
				<td><button type="button" id="cfdb7-indexing" class="button button-primary"><?php echo __('Indexing', CFDB7_PRO_TEXT_DOMAIN); ?></button></td>
			</tr>
			<?php
		}
		?>
	</table>
</div>
<div id="popup-content" class="mfp-hide">
	<div class="progress-bar-container">
		<div class="progress-bar"></div>
	</div>
</div>
