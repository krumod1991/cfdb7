<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

$cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? sanitize_text_field($_GET['cf7-id']) : "";
$url_args = array('page' => $_GET['page']);
if(!empty($cf7_id)){
    $url_args['cf7-id'] = $cf7_id;
}
$admin_page_url = add_query_arg( $url_args, admin_url().'admin.php' );

global $wpdb;
$obj = new Cfdb7_Queries();
$obj->init_cfdb7_tables();

//Save display settings
if(isset($_POST['display-settings'])){
    do_action('cfdb7_save_display_user_settings', $_POST, $wpdb, $obj);
}

$allowed_form_ids = array();
if(!empty($forms_list)){
    foreach($forms_list as $form){
        $entries_count = $obj->get_cfdb7_log_entries_count($wpdb, $form->ID);
        if(!empty($entries_count)){
            if($entries_count['count'] > 0){
                $allowed_form_ids[] = $form;
            }
        }
    }
}

wp_enqueue_script( 'cfdb7_entry_logger_script' );
wp_enqueue_style( 'cfdb7_entry_logger_style' );
?>
<div class="wrap cfdb7-entries-logger">
    <h1 class="wp-heading-inline"><?php echo __('Logger', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
    <form id="cfdb7-ids" method="post" action="<?php echo $admin_page_url; ?>" novalidate="novalidate">
        <table class="form-table">
            <tr class="form-field">
                <th><label for="cf7-id"><?php echo __('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></label></th>
                <td>
                    <select name="cf7-id" id="cf7-id">
                        <option value=""><?php echo __('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></option>
                        <?php 
                        if(!empty($allowed_form_ids)){
                        foreach($allowed_form_ids as $form){
                                $is_selected = "";
                                if(!empty($cf7_id)){
                                    if($cf7_id == $form->ID){
                                        $is_selected = "selected";
                                    }
                                }
                                ?><option value="<?php echo $form->ID; ?>" <?php echo $is_selected; ?>><?php echo $form->post_title; ?></option><?php
                            }
                        }
                        ?>
                    </select>
                </td>
            </tr>
        </table>
    </form>    
    <?php
    if(!empty($cf7_id)){
        include_once plugin_dir_path( __DIR__ ).'partials/cfdb7_entry_logger_list_table.php';
    }
    ?>
</div>
