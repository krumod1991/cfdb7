<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/public
 * @author     Pinky dev
 */
class Cfdb7_Pro_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Cfdb7_Pro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Cfdb7_Pro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/cfdb7-pro-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Cfdb7_Pro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Cfdb7_Pro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/cfdb7-pro-public.js', array( 'jquery' ), $this->version, false );

	}

	public function cfdb7_form_data_after_applied_settings($field_data, $form_setting, $cf7_id, $obj, $wpdb){
		$field_data = cfdb7_form_data_after_applied_settings($field_data, $form_setting, $cf7_id, $obj, $wpdb);
		return $field_data;
	}

	public function cfdb7_save_entry($insert_id, $form_data){
		global $wpdb;
		$obj = new Cfdb7_Queries();
		$obj->init_cfdb7_tables();

		$entry_info = $obj->get_db7_forms_entry($wpdb, $insert_id);
		if(!empty($entry_info)){
			$form_post_id = isset($entry_info['form_post_id']) && !empty($entry_info['form_post_id']) ? $entry_info['form_post_id'] : "";//It is called cf7_id
			$form_value = isset($entry_info['form_value']) && !empty($entry_info['form_value']) ? $entry_info['form_value'] : "";
			$field_data = !empty($form_value) ? maybe_unserialize($form_value) : array();
			$form_date = isset($entry_info['form_date']) && !empty($entry_info['form_date']) ? $entry_info['form_date'] : "";
			if(!empty($form_post_id) && !empty($field_data) && !empty($form_date)){
				//Get CF7 form tags
				$tags = cfdb7_get_form_tags($form_post_id);
				//Set fields list
				$cf7_tags = array();
				if(!empty($tags)){
					foreach ( $tags as $tag ){
						if(!empty($tag->name)){
							$cf7_tags[$tag->name] = $tag->basetype;
						}
					}
				}
				//$form_setting use to applied setting to form data
				$form_setting = cfdb7_get_form_setting($wpdb, $obj, $form_post_id);

				$original_field_data = $field_data;
				$field_data = apply_filters( 'cfdb7_sanitize_field_data', $field_data);
				
				if(!empty($original_field_data)){
					if(isset($original_field_data['cfdb7_status'])){
						unset($original_field_data['cfdb7_status']);
					}
				}

				$original_entry_fields = array();
				$original_entry_fields = apply_filters( 'cfdb7_form_data_after_applied_field_type', $original_entry_fields, $field_data, $cf7_tags);

				$logger = array();
				$logger['date_time'] = $form_date;
				$logger['lead_source'] = 'cf7';
				$logger['form_setting'] = $form_setting;
				$logger['db7_forms_id'] = $insert_id;
				$logger['original_entry'] = $field_data;
				$logger['original_entry_fields'] = $original_entry_fields;
				$logger['form_entry'] = $entry_info;
				
				$field_data = apply_filters( 'cfdb7_form_data_after_applied_settings', $field_data, $form_setting, $form_post_id, $obj, $wpdb);
				$logger['proceed_entry'] = $field_data;

				$proceed_entry_fields = array();
				$proceed_entry_fields = apply_filters( 'cfdb7_form_data_after_applied_field_type', $proceed_entry_fields, $field_data, $cf7_tags);
				$logger['proceed_entry_fields'] = $proceed_entry_fields;

				if(!empty($field_data)){
					$ip_address = cfdb7_get_ip_address();

					$entry_details = array(
						'db7_forms_id' => $insert_id,
						'lead_source' => 'cf7',
						'form_submissions' => maybe_serialize($field_data),
						'form_submission_fields' => maybe_serialize($proceed_entry_fields),
						'submit_by' => '',
						'submit_display_name' => '',
						'submit_date_time' => $form_date,
						'submit_ip_address' => $ip_address,
					);

					$entry_details_format = array("%s","%s","%s","%s","%s","%s","%s","%s");
					$entry_id = $obj->save_cfdb7_entry($wpdb, $form_post_id, $entry_details, $entry_details_format);
					$logger['entry_id'] = $entry_id;
					$logger['entry_details'] = $entry_details;

					if (!empty($entry_id)){
						foreach($field_data as $field_name => $field_value){
							$field_name = sanitize_text_field($field_name);
							//Convert special character to html entity
							//It is prevent XSS attack
							$field_value = htmlspecialchars($field_value);
							//It is prevent JS injection
							$field_value = sanitize_textarea_field(trim($field_value));

							$entry_submission = array(
								'entry_id' => $entry_id,
								'db7_forms_id' => $insert_id,
								'lead_source' => 'cf7',
								'field_name' => $field_name,
								'field_type' => isset($cf7_tags[$field_name]) && !empty($cf7_tags[$field_name]) ? $cf7_tags[$field_name] : "text",
								'field_value' => $field_value,
							);
							$entry_submission_format = array("%s","%s","%s","%s","%s","%s");
							$obj->save_cfdb7_entry_submissions($wpdb, $form_post_id, $entry_submission, $entry_submission_format);
						}

						foreach($original_field_data as $original_field_name => $original_field_value){
							$original_field_name = sanitize_text_field($original_field_name);
							//Convert special character to html entity
							//It is prevent XSS attack
							$original_field_value = htmlspecialchars($original_field_value);
							//It is prevent JS injection
							$original_field_value = sanitize_textarea_field(trim($original_field_value));

							$entry_submission = array(
								'entry_id' => $entry_id,
								'db7_forms_id' => $insert_id,
								'lead_source' => 'cf7',
								'field_name' => $original_field_name,
								'field_type' => isset($cf7_tags[$original_field_name]) && !empty($cf7_tags[$original_field_name]) ? $cf7_tags[$original_field_name] : "text",
								'field_value' => $original_field_value,
							);
							$entry_submission_format = array("%s","%s","%s","%s","%s","%s");
							$obj->save_cfdb7_log_submissions($wpdb, $form_post_id, $entry_submission, $entry_submission_format);
						}

						do_action( 'cfdb7_after_save_entry', $entry_details, $entry_id, $form_post_id, $obj, $wpdb);
					}

					do_action( 'cfdb7_save_report_field_for_field_name_options', array_keys($original_field_data), $form_post_id, $obj, $wpdb);
				}
				//Save logs for submissions
				$obj->save_entry_log($wpdb, $form_post_id, $logger);
			}
		}
	}

	public function cfdb7_save_report_field_for_field_name_options($available_fields, $cf7_id, $obj, $wpdb){
		cfdb7_save_report_field_for_field_name_options($available_fields, $cf7_id, $obj, $wpdb);
	}

	public function cfdb7_sanitize_field_data($field_data){
		return cfdb7_sanitize_field_data($field_data);
	}

	public function cfdb7_form_data_after_applied_field_type($entry_fields, $field_data, $cf7_tags){
		return cfdb7_form_data_after_applied_field_type($entry_fields, $field_data, $cf7_tags);
	}
}
