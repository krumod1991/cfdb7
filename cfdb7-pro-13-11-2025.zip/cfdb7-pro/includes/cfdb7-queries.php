<?php

/**
 * Fired during plugin activation
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/includes
 * @author     Pinky dev
 */
class Cfdb7_Queries {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	private $cfdb7_settings;
	private $cfdb7_settings_log;
	private $cfdb7_db;

	private $cfdb7_entries_details;
	private $cfdb7_entries_submissions;
	private $cfdb7_entries_field_name_options;

	private $cfdb7_edit_entries_log;
	private $cfdb7_edit_entries_submissions;
	private $cfdb7_edit_entries_field_name_options;

	private $cfdb7_delete_entries_log;
	private $cfdb7_delete_entries_submissions;
	private $cfdb7_delete_entries_field_name_options;

	private $cfdb7_entries_log;
	private $cfdb7_entries_submissions_log;
	private $cfdb7_entries_field_name_options_log;

	private $cfdb7_display_settings;
	private $cfdb7_export_log;
	
	public function init_cfdb7_tables(){
		$this->cfdb7_settings = 'cfdb7_settings';
		$this->cfdb7_settings_log = 'cfdb7_settings_log';
		$this->cfdb7_db = 'db7_forms';

		$this->cfdb7_entries_details = 'cfdb7_entries_details_form_{form_id}';
		$this->cfdb7_entries_submissions = 'cfdb7_entries_submission_form_{form_id}';
		$this->cfdb7_entries_field_name_options = 'cfdb7_entries_field_name_options_form_{form_id}';

		$this->cfdb7_edit_entries_log = 'cfdb7_edit_entries_logs_form_{form_id}';
		$this->cfdb7_edit_entries_submissions = 'cfdb7_edit_entries_submission_form_{form_id}';
		$this->cfdb7_edit_entries_field_name_options = 'cfdb7_edit_entries_field_name_options_form_{form_id}';

		$this->cfdb7_delete_entries_log = 'cfdb7_delete_entries_logs_form_{form_id}';
		$this->cfdb7_delete_entries_submissions = 'cfdb7_delete_entries_submission_form_{form_id}';
		$this->cfdb7_delete_entries_field_name_options = 'cfdb7_delete_entries_field_name_options_form_{form_id}';

		$this->cfdb7_entries_log = 'cfdb7_entries_logs_form_{form_id}';
		$this->cfdb7_entries_submissions_log = 'cfdb7_entries_logs_submission_form_{form_id}';
		$this->cfdb7_entries_field_name_options_log = 'cfdb7_entries_logs_field_name_options_form_{form_id}';
		
		$this->cfdb7_display_settings = 'cfdb7_display_settings_form_{form_id}';
		$this->cfdb7_export_log = 'cfdb7_export_logs_form_{form_id}';
		
	}

	public function get_cfdb7_form_setting($wpdb, $form_id) {
		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}{$this->cfdb7_settings} where form_id='{$form_id}'"), ARRAY_A );
	}

	public function save_cfdb7_form_setting($wpdb, $data, $format) {
		$table_name = "{$wpdb->prefix}{$this->cfdb7_settings}";
		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	public function update_cfdb7_form_setting($wpdb, $data, $format, $where, $where_format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_settings}";
		return $wpdb->update($table_name, $data, $where, $format, $where_format);
	}

	public function save_cfdb7_setting_log($wpdb, $data, $format) {
		$table_name = "{$wpdb->prefix}{$this->cfdb7_settings_log}";
		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	public function save_db7_forms_entry($wpdb, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_db}";
		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	public function save_cfdb7_entry($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}
	
	public function save_cfdb7_entry_submissions($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	public function get_db7_forms_entries_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT count('id') as count FROM {$wpdb->prefix}{$this->cfdb7_db} where form_post_id='{$form_id}' and form_id NOT IN (SELECT `db7_forms_id` FROM {$table_name} where db7_forms_id!='')"), ARRAY_A );
	}
	
	public function get_db7_forms_indexing_entries($wpdb, $form_id, $limit){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}{$this->cfdb7_db} where form_post_id='{$form_id}' and form_id NOT IN (SELECT `db7_forms_id` FROM {$table_name} where db7_forms_id!='') LIMIT $limit"), ARRAY_A );
	}

	public function get_db7_forms_entry($wpdb, $entry_id){
		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}{$this->cfdb7_db} where form_id='{$entry_id}'"), ARRAY_A );
	}

	public function check_Cfdb7_submission($wpdb, $form_id, $avoid_field, $field_value){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} where field_name='{$avoid_field}' and field_value='{$field_value}'"), ARRAY_A );
	}

	public function save_entry_log($wpdb, $form_id, $logger){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$logger_data = array(
			'lead_source' => isset($logger['lead_source']) && !empty($logger['lead_source']) ? $logger['lead_source'] : "",
			'form_setting' => isset($logger['form_setting']) && !empty($logger['form_setting']) ? maybe_serialize($logger['form_setting']) : "",
			'db7_forms_id' => isset($logger['db7_forms_id']) && !empty($logger['db7_forms_id']) ? $logger['db7_forms_id'] : "",
			'original_entry' => isset($logger['original_entry']) && !empty($logger['original_entry']) ? maybe_serialize($logger['original_entry']) : "",
			'original_entry_fields' => isset($logger['original_entry_fields']) && !empty($logger['original_entry_fields']) ? maybe_serialize($logger['original_entry_fields']) : "",
			'form_entry' => isset($logger['form_entry']) && !empty($logger['form_entry']) ? maybe_serialize($logger['form_entry']) : "",
			'proceed_entry' => isset($logger['proceed_entry']) && !empty($logger['proceed_entry']) ? maybe_serialize($logger['proceed_entry']) : "",
			'proceed_entry_fields' => isset($logger['proceed_entry_fields']) && !empty($logger['proceed_entry_fields']) ? maybe_serialize($logger['proceed_entry_fields']) : "",
			'entry_id' => isset($logger['entry_id' ]) && !empty($logger['entry_id' ]) ? $logger['entry_id' ] : "",
			'entry_details' => isset($logger['entry_details']) && !empty($logger['entry_details']) ? maybe_serialize($logger['entry_details']) : "",
			'date_time' => isset($logger['date_time']) && !empty($logger['date_time']) ? $logger['date_time'] : "",
		);

		$logger_format = array("%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s");

		$wpdb->insert($table_name, $logger_data, $logger_format);
		return $wpdb->insert_id;
	}

	public function save_cfdb7_log_submissions($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	public function get_cfdb7_report_field_name_options_count($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);
		
		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} where field_name='{$field_name}' GROUP BY field_name"), ARRAY_A );
		}else{
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} GROUP BY field_name"), ARRAY_A );
		}
	}

	public function get_cfdb7_report_field_name_options($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where field_name='{$field_name}'"), ARRAY_A );	
		}else{
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name}"), ARRAY_A );	
		}
	}

	public function truncate_cfdb7_report_field_name_options($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->query("TRUNCATE TABLE {$table_name}");
	}

	public function save_cfdb7_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'field_name' => $field_name,
			'entry_count' => $field_count,
		);
		$field_format = array("%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	public function update_cfdb7_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'entry_count' => $field_count,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'field_name' => $field_name,
		);
		$where_field_format = array("%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	public function get_cfdb7_edit_report_field_name_options_count($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_edit_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);
		
		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} where field_name='{$field_name}' GROUP BY field_name"), ARRAY_A );
		}else{
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} GROUP BY field_name"), ARRAY_A );
		}
	}

	public function get_cfdb7_edit_report_field_name_options($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_edit_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where field_name='{$field_name}'"), ARRAY_A );	
		}else{
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name}"), ARRAY_A );	
		}
	}

	public function truncate_cfdb7_edit_report_field_name_options($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_edit_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->query("TRUNCATE TABLE {$table_name}");
	}

	public function save_cfdb7_edit_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_edit_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'field_name' => $field_name,
			'entry_count' => $field_count,
		);
		$field_format = array("%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	public function update_cfdb7_edit_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_edit_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'entry_count' => $field_count,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'field_name' => $field_name,
		);
		$where_field_format = array("%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	public function get_cfdb7_delete_report_field_name_options_count($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);
		
		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} where field_name='{$field_name}' GROUP BY field_name"), ARRAY_A );
		}else{
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} GROUP BY field_name"), ARRAY_A );
		}
	}

	public function get_cfdb7_delete_report_field_name_options($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where field_name='{$field_name}'"), ARRAY_A );	
		}else{
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name}"), ARRAY_A );	
		}
	}

	public function truncate_cfdb7_delete_report_field_name_options($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->query("TRUNCATE TABLE {$table_name}");
	}

	public function save_cfdb7_delete_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'field_name' => $field_name,
			'entry_count' => $field_count,
		);
		$field_format = array("%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	public function update_cfdb7_delete_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'entry_count' => $field_count,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'field_name' => $field_name,
		);
		$where_field_format = array("%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	public function get_cfdb7_log_report_field_name_options_count($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);
		
		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} where field_name='{$field_name}' GROUP BY field_name"), ARRAY_A );
		}else{
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} GROUP BY field_name"), ARRAY_A );
		}
	}

	public function get_cfdb7_log_report_field_name_options($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where field_name='{$field_name}'"), ARRAY_A );	
		}else{
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name}"), ARRAY_A );	
		}
	}

	public function truncate_cfdb7_log_report_field_name_options($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->query("TRUNCATE TABLE {$table_name}");
	}

	public function save_cfdb7_log_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'field_name' => $field_name,
			'entry_count' => $field_count,
		);
		$field_format = array("%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	public function update_cfdb7_log_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'entry_count' => $field_count,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'field_name' => $field_name,
		);
		$where_field_format = array("%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	public function get_cfdb7_export_log_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_export_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		//return 
		return $wpdb->get_row($wpdb->prepare("SELECT count('id') as count FROM {$table_name}"), ARRAY_A );	
	}

	public function get_cfdb7_export_log($wpdb, $form_id, $from_date = "", $to_date = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_export_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$search_array = array();
		if(!empty($from_date) && !empty($to_date)){
			$from_date = date("Y-m-d", strtotime($from_date));
			$to_date = date("Y-m-d", strtotime($to_date));
			$search_array[] = 'date_time >= "'.$from_date.'  00:00:00"';
			$search_array[] = 'date_time <= "'.$to_date.'  23:59:59"';
		}

		$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";

		return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where $search_str order by `id` desc"), ARRAY_A );
	}
	
	public function get_cfdb7_export_log_indexing_entries($wpdb, $form_id, $limit){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_export_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} LIMIT $limit"), ARRAY_A );
	}

	public function delete_cfdb7_export_log($wpdb, $form_id, $index_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_export_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'id' => $index_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	}

	public function get_cfdb7_form_display_settings($wpdb, $form_id, $user_id, $context){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_display_settings}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} where user_id='{$user_id}' AND context='{$context}'"), ARRAY_A );
	}

	public function save_cfdb7_form_display_settings($wpdb, $form_id, $user_id, $context, $settings){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_display_settings}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'user_id' => $user_id,
			'context' => $context,
			'settings' => $settings,
		);
		$field_format = array("%s","%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	public function update_cfdb7_form_display_settings($wpdb, $form_id, $user_id, $context, $settings){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_display_settings}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'settings' => $settings,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'user_id' => $user_id,
			'context' => $context,
		);
		$where_field_format = array("%s","%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	public function get_cfdb7_form_entries_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT count(`entry_id`) as count FROM {$table_name}"), ARRAY_A );
	}

	public function get_cfdb7_form_entries($wpdb, $form_id, $search_input = array()){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($search_input)){
			$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
			$field_names = array_map( 'sanitize_text_field', (array) $field_names );
			$search_value = isset($search_input['s']) && !empty($search_input['s']) ? sanitize_text_field($search_input['s']) : "";
			$from_date = isset($search_input['from_date']) && !empty($search_input['from_date']) ? sanitize_text_field($search_input['from_date']) : "";
			$to_date = isset($search_input['to_date']) && !empty($search_input['to_date']) ? sanitize_text_field($search_input['to_date']) : "";

			$search_array = array();
			if(!empty($from_date) && !empty($to_date)){
				$from_date = date("Y-m-d", strtotime($from_date));
				$to_date = date("Y-m-d", strtotime($to_date));
				$search_array[] = 'date_time >= "'.$from_date.'  00:00:00"';
				$search_array[] = 'date_time <= "'.$to_date.'  23:59:59"';
			}

			if(!empty($field_names) || !empty($search_value)){
				$entry_ids = $this->get_cfdb7_form_entries_submissions($wpdb, $form_id, $search_input);
				$entry_ids = !empty($entry_ids) ? wp_list_pluck($entry_ids, 'entry_id') : array();
				if(!empty($entry_ids)){
					$entry_ids_str = implode(",", $entry_ids);
					$search_array[] = 'entry_id IN ('.$entry_ids_str.')';
				}
			}

			if(!empty($search_array)){
				$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";

				return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where $search_str order by `entry_id` desc"), ARRAY_A );
			}else{
				return array();
			}
		}else{
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} order by `entry_id` desc"), ARRAY_A );
		}
	}

	private function get_cfdb7_form_entries_submissions($wpdb, $form_id, $search_input){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
		$field_names = array_map( 'sanitize_text_field', (array) $field_names );
		$search_value = isset($search_input['s']) && !empty($search_input['s']) ? $search_input['s'] : "";

		$search_array = array();
		if(!empty($field_names)){
			$field_names_str = implode('","', $field_names);
			$search_array[] = 'field_name IN ("'.$field_names_str.'")';
		}

		if(!empty($search_value)){
			$search_array[] = 'field_value like "%'.$search_value.'%"';
		}

		$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";

		return $wpdb->get_results($wpdb->prepare("SELECT `entry_id` FROM {$table_name} where $search_str"), ARRAY_A );
	}

	public function get_cfdb7_form_entry_details($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} where entry_id='{$entry_id}'"), ARRAY_A );
	}

	public function get_cfdb7_form_entry_submissions($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where entry_id='{$entry_id}'"), ARRAY_A );
	}

	public function get_cfdb7_form_entry_revisions($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_edit_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where entry_id='{$entry_id}'"), ARRAY_A );
	}

	public function update_cfdb7_form_entry($wpdb, $form_id, $entry_id, $details){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'form_submissions' => isset($details['form_submissions']) && !empty($details['form_submissions']) ? $details['form_submissions'] : "",
			'edit_by' => isset($details['edit_by']) && !empty($details['edit_by']) ? $details['edit_by'] : "",
			'edit_display_name' => isset($details['edit_display_name']) && !empty($details['edit_display_name']) ? $details['edit_display_name'] : "",
			'edit_date_time' => isset($details['edit_date_time']) && !empty($details['edit_date_time']) ? $details['edit_date_time'] : "",
			'edit_ip_address' => isset($details['edit_ip_address']) && !empty($details['edit_ip_address']) ? $details['edit_ip_address'] : "",
		);
		$field_format = array("%s","%s","%s","%s","%s");

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	public function update_cfdb7_form_submissions($wpdb, $form_id, $field_name, $field_value, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'field_value' => $field_value,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'field_name' => $field_name,
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s","%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	public function save_cfdb7_edit_entries_log($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_edit_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	public function save_cfdb7_edit_entries_submission($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_edit_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	public function save_cfdb7_delete_entries_log($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	public function save_cfdb7_delete_entries_submission($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	public function delete_cfdb7_form_entry($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	}

	public function delete_cfdb7_form_submissions($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	}

	public function save_cfdb7_export_log($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_export_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	public function get_cfdb7_edit_entries_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_edit_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT count(`entry_id`) as count FROM {$table_name}"), ARRAY_A );
	}

	public function get_cfdb7_edit_entries($wpdb, $form_id, $search_input = array()){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_edit_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($search_input)){
			$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
			$field_names = array_map( 'sanitize_text_field', (array) $field_names );
			$search_value = isset($search_input['s']) && !empty($search_input['s']) ? sanitize_text_field($search_input['s']) : "";
			$from_date = isset($search_input['from_date']) && !empty($search_input['from_date']) ? sanitize_text_field($search_input['from_date']) : "";
			$to_date = isset($search_input['to_date']) && !empty($search_input['to_date']) ? sanitize_text_field($search_input['to_date']) : "";

			$search_array = array();
			if(!empty($from_date) && !empty($to_date)){
				$from_date = date("Y-m-d", strtotime($from_date));
				$to_date = date("Y-m-d", strtotime($to_date));
				$search_array[] = 'date_time >= "'.$from_date.'  00:00:00"';
				$search_array[] = 'date_time <= "'.$to_date.'  23:59:59"';
			}

			if(!empty($field_names) || !empty($search_value)){
				$entry_ids = $this->get_cfdb7_edit_entries_submissions($wpdb, $form_id, $search_input);
				$entry_ids = !empty($entry_ids) ? wp_list_pluck($entry_ids, 'entry_id') : array();
				if(!empty($entry_ids)){
					$entry_ids_str = implode(",", $entry_ids);
					$search_array[] = 'entry_id IN ('.$entry_ids_str.')';
				}
			}

			if(!empty($search_array)){
				$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";

				return $wpdb->get_results($wpdb->prepare("SELECT `id`,`lead_source`,`db7_forms_id`,`entry_id`,`date_time` FROM {$table_name} where $search_str order by `id` desc"), ARRAY_A );
			}else{
				return array();
			}
		}else{
			return $wpdb->get_results($wpdb->prepare("SELECT `id`,`lead_source`,`db7_forms_id`,`entry_id`,`date_time` FROM {$table_name} order by `id` desc"), ARRAY_A );
		}
	}

	private function get_cfdb7_edit_entries_submissions($wpdb, $form_id, $search_input){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_edit_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
		$field_names = array_map( 'sanitize_text_field', (array) $field_names );
		$search_value = isset($search_input['s']) && !empty($search_input['s']) ? $search_input['s'] : "";

		$search_array = array();
		if(!empty($field_names)){
			$field_names_str = implode('","', $field_names);
			$search_array[] = 'field_name IN ("'.$field_names_str.'")';
		}

		if(!empty($search_value)){
			$search_array[] = 'field_value like "%'.$search_value.'%"';
		}

		$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";

		return $wpdb->get_results($wpdb->prepare("SELECT `entry_id` FROM {$table_name} where $search_str"), ARRAY_A );
	}

	public function get_cfdb7_delete_entries_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT count(`entry_id`) as count FROM {$table_name}"), ARRAY_A );
	}

	public function get_cfdb7_delete_entries($wpdb, $form_id, $search_input = array()){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($search_input)){
			$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
			$field_names = array_map( 'sanitize_text_field', (array) $field_names );
			$search_value = isset($search_input['s']) && !empty($search_input['s']) ? sanitize_text_field($search_input['s']) : "";
			$from_date = isset($search_input['from_date']) && !empty($search_input['from_date']) ? sanitize_text_field($search_input['from_date']) : "";
			$to_date = isset($search_input['to_date']) && !empty($search_input['to_date']) ? sanitize_text_field($search_input['to_date']) : "";

			$search_array = array();
			if(!empty($from_date) && !empty($to_date)){
				$from_date = date("Y-m-d", strtotime($from_date));
				$to_date = date("Y-m-d", strtotime($to_date));
				$search_array[] = 'date_time >= "'.$from_date.'  00:00:00"';
				$search_array[] = 'date_time <= "'.$to_date.'  23:59:59"';
			}

			if(!empty($field_names) || !empty($search_value)){
				$entry_ids = $this->get_cfdb7_delete_entries_submissions($wpdb, $form_id, $search_input);
				$entry_ids = !empty($entry_ids) ? wp_list_pluck($entry_ids, 'entry_id') : array();
				if(!empty($entry_ids)){
					$entry_ids_str = implode(",", $entry_ids);
					$search_array[] = 'entry_id IN ('.$entry_ids_str.')';
				}
			}

			if(!empty($search_array)){
				$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";

				return $wpdb->get_results($wpdb->prepare("SELECT `id`,`lead_source`,`db7_forms_id`,`entry_id`,`date_time` FROM {$table_name} where $search_str order by `id` desc"), ARRAY_A );
			}else{
				return array();
			}
		}else{
			return $wpdb->get_results($wpdb->prepare("SELECT `id`,`lead_source`,`db7_forms_id`,`entry_id`,`date_time` FROM {$table_name} order by `id` desc"), ARRAY_A );
		}
	}

	private function get_cfdb7_delete_entries_submissions($wpdb, $form_id, $search_input){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
		$field_names = array_map( 'sanitize_text_field', (array) $field_names );
		$search_value = isset($search_input['s']) && !empty($search_input['s']) ? $search_input['s'] : "";

		$search_array = array();
		if(!empty($field_names)){
			$field_names_str = implode('","', $field_names);
			$search_array[] = 'field_name IN ("'.$field_names_str.'")';
		}

		if(!empty($search_value)){
			$search_array[] = 'field_value like "%'.$search_value.'%"';
		}

		$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";

		return $wpdb->get_results($wpdb->prepare("SELECT `entry_id` FROM {$table_name} where $search_str"), ARRAY_A );
	}

	public function delete_cfdb7_entry_delete_log($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	}

	public function delete_cfdb7_entry_submission_log($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	} 

	public function get_cfdb7_log_entries_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT count(`entry_id`) as count FROM {$table_name}"), ARRAY_A );
	}

	public function get_cfdb7_log_entries($wpdb, $form_id, $search_input = array()){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($search_input)){
			$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
			$field_names = array_map( 'sanitize_text_field', (array) $field_names );
			$search_value = isset($search_input['s']) && !empty($search_input['s']) ? sanitize_text_field($search_input['s']) : "";
			$from_date = isset($search_input['from_date']) && !empty($search_input['from_date']) ? sanitize_text_field($search_input['from_date']) : "";
			$to_date = isset($search_input['to_date']) && !empty($search_input['to_date']) ? sanitize_text_field($search_input['to_date']) : "";

			$search_array = array();
			if(!empty($from_date) && !empty($to_date)){
				$from_date = date("Y-m-d", strtotime($from_date));
				$to_date = date("Y-m-d", strtotime($to_date));
				$search_array[] = 'date_time >= "'.$from_date.'  00:00:00"';
				$search_array[] = 'date_time <= "'.$to_date.'  23:59:59"';
			}

			if(!empty($field_names) || !empty($search_value)){
				$entry_ids = $this->get_cfdb7_log_entries_submissions($wpdb, $form_id, $search_input);
				$entry_ids = !empty($entry_ids) ? wp_list_pluck($entry_ids, 'entry_id') : array();
				if(!empty($entry_ids)){
					$entry_ids_str = implode(",", $entry_ids);
					$search_array[] = 'entry_id IN ('.$entry_ids_str.')';
				}
			}

			if(!empty($search_array)){
				$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";

				return $wpdb->get_results($wpdb->prepare("SELECT `id`,`lead_source`,`db7_forms_id`,`entry_id`,`original_entry`,`original_entry_fields`,`date_time` FROM {$table_name} where $search_str order by `id` desc"), ARRAY_A );
			}else{
				return array();
			}
		}else{
			return $wpdb->get_results($wpdb->prepare("SELECT `id`,`lead_source`,`db7_forms_id`,`entry_id`,`original_entry`,`original_entry_fields`,`date_time` FROM {$table_name} order by `id` desc"), ARRAY_A );
		}
	}

	private function get_cfdb7_log_entries_submissions($wpdb, $form_id, $search_input){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
		$field_names = array_map( 'sanitize_text_field', (array) $field_names );
		$search_value = isset($search_input['s']) && !empty($search_input['s']) ? $search_input['s'] : "";

		$search_array = array();
		if(!empty($field_names)){
			$field_names_str = implode('","', $field_names);
			$search_array[] = 'field_name IN ("'.$field_names_str.'")';
		}

		if(!empty($search_value)){
			$search_array[] = 'field_value like "%'.$search_value.'%"';
		}

		$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";
		
		return $wpdb->get_results($wpdb->prepare("SELECT `entry_id` FROM {$table_name} where $search_str"), ARRAY_A );
	}

	public function get_cfdb7_log_entry($wpdb, $form_id, $index_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} where id='{$index_id}'"), ARRAY_A );
	}
}