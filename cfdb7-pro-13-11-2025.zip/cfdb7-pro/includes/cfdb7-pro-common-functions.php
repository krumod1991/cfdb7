<?php

function cfdb7_get_contact_forms_list($cf7_id = ""){
    $args = array(
        'post_type'      => 'wpcf7_contact_form',
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC', // or 'DESC' for descending
    );


    if(!empty($cf7_id)){
        $args['include'] = $cf7_id;
    }

    $forms_list = get_posts($args);

    return $forms_list;
}

function cfdb7_get_form_tags($cf7_id){
    // Get form by ID
    $form = WPCF7_ContactForm::get_instance($cf7_id);
    // Parse tags
    return $form->scan_form_tags();
}

function cfdb7_generate_basic_tables(){
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    // Get all table names
    $tables = $wpdb->get_col("SHOW TABLES");

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $table_name1 = $wpdb->prefix.'cfdb7_settings';
    if(!in_array($table_name1, $tables)){
        $sql = "CREATE TABLE {$table_name1} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT(20),
            settings LONGTEXT,
            entry_by BIGINT(20) UNSIGNED,
            entry_display_name VARCHAR(50),
            entry_date_time DATETIME,
            entry_ip_address VARCHAR(100),
            PRIMARY KEY  (id)
        ) $charset_collate;";

        dbDelta($sql);
    }

    $table_name2 = $wpdb->prefix.'cfdb7_settings_log';
    if(!in_array($table_name2, $tables)){
        $sql = "CREATE TABLE {$table_name2} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT(20),
            settings LONGTEXT,
            entry_by BIGINT(20) UNSIGNED,
            entry_display_name VARCHAR(50),
            entry_date_time DATETIME,
            entry_ip_address VARCHAR(100),
            PRIMARY KEY  (id)
        ) $charset_collate;";

        dbDelta($sql);
    }
}

function cfdb7_generate_entries_table($cf7_id = ""){
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    // Get all table names
    $tables = $wpdb->get_col("SHOW TABLES");

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $forms_list = cfdb7_get_contact_forms_list($cf7_id);
    if(!empty($forms_list)){
        foreach($forms_list as $form){
            $form_id = $form->ID;

            $table_name1 = $wpdb->prefix.'cfdb7_entries_details_form_'.$form_id;
            if(!in_array($table_name1, $tables)){
                $sql = "CREATE TABLE {$table_name1} (
                    entry_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    db7_forms_id BIGINT(20) UNSIGNED,
                    lead_source VARCHAR(100),
                    form_submissions LONGTEXT,
                    form_submission_fields LONGTEXT,
                    submit_by BIGINT(20) UNSIGNED,
                    submit_display_name VARCHAR(50),
                    submit_date_time DATETIME,
                    submit_ip_address VARCHAR(100),
                    edit_by BIGINT(20) UNSIGNED,
                    edit_display_name VARCHAR(50),
                    edit_date_time DATETIME,
                    edit_ip_address VARCHAR(100),
                    PRIMARY KEY  (entry_id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name2 = $wpdb->prefix.'cfdb7_entries_submission_form_'.$form_id;
            if(!in_array($table_name2, $tables)){
                $sql = "CREATE TABLE {$table_name2} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    entry_id BIGINT(20) UNSIGNED,
                    db7_forms_id BIGINT(20) UNSIGNED,
                    lead_source VARCHAR(100),
                    field_name VARCHAR(100),
                    field_type VARCHAR(50),
                    field_value LONGTEXT,
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name3 = $wpdb->prefix.'cfdb7_entries_field_name_options_form_'.$form_id;
            if(!in_array($table_name3, $tables)){
                $sql = "CREATE TABLE {$table_name3} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    field_name VARCHAR(100),
                    entry_count VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name4 = $wpdb->prefix.'cfdb7_export_logs_form_'.$form_id;
            if(!in_array($table_name4, $tables)){
                $sql = "CREATE TABLE {$table_name4} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    form_id BIGINT(20),
                    export_type VARCHAR(100),
                    export_file_path VARCHAR(100),
                    export_by BIGINT(20) UNSIGNED,
                    export_display_name VARCHAR(50),
                    export_date_time DATETIME,
                    export_ip_address VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name5 = $wpdb->prefix.'cfdb7_edit_entries_logs_form_'.$form_id;
            if(!in_array($table_name5, $tables)){
                $sql = "CREATE TABLE {$table_name5} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    form_id BIGINT(20),
                    entry_id BIGINT(20),
                    db7_forms_id BIGINT(20) UNSIGNED,
                    lead_source VARCHAR(100),
                    form_submissions LONGTEXT,
                    form_submission_fields LONGTEXT,
                    submit_by BIGINT(20) UNSIGNED,
                    submit_display_name VARCHAR(50),
                    submit_date_time DATETIME,
                    submit_ip_address VARCHAR(100),
                    edit_by BIGINT(20) UNSIGNED,
                    edit_display_name VARCHAR(50),
                    edit_date_time DATETIME,
                    edit_ip_address VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name6 = $wpdb->prefix.'cfdb7_edit_entries_submission_form_'.$form_id;
            if(!in_array($table_name6, $tables)){
                $sql = "CREATE TABLE {$table_name6} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    entry_id BIGINT(20) UNSIGNED,
                    db7_forms_id BIGINT(20) UNSIGNED,
                    lead_source VARCHAR(100),
                    field_name VARCHAR(100),
                    field_type VARCHAR(50),
                    field_value LONGTEXT,
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name7 = $wpdb->prefix.'cfdb7_edit_entries_field_name_options_form_'.$form_id;
            if(!in_array($table_name7, $tables)){
                $sql = "CREATE TABLE {$table_name7} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    field_name VARCHAR(100),
                    entry_count VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name8 = $wpdb->prefix.'cfdb7_delete_entries_logs_form_'.$form_id;
            if(!in_array($table_name8, $tables)){
                $sql = "CREATE TABLE {$table_name8} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    form_id BIGINT(20),
                    entry_id BIGINT(20),
                    db7_forms_id BIGINT(20) UNSIGNED,
                    lead_source VARCHAR(100),
                    form_submissions LONGTEXT,
                    form_submission_fields LONGTEXT,
                    submit_by BIGINT(20) UNSIGNED,
                    submit_display_name VARCHAR(50),
                    submit_date_time DATETIME,
                    submit_ip_address VARCHAR(100),
                    edit_by BIGINT(20) UNSIGNED,
                    edit_display_name VARCHAR(50),
                    edit_date_time DATETIME,
                    edit_ip_address VARCHAR(100),
                    delete_by BIGINT(20) UNSIGNED,
                    delete_display_name VARCHAR(50),
                    delete_date_time DATETIME,
                    delete_ip_address VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name9 = $wpdb->prefix.'cfdb7_delete_entries_submission_form_'.$form_id;
            if(!in_array($table_name9, $tables)){
                $sql = "CREATE TABLE {$table_name9} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    entry_id BIGINT(20) UNSIGNED,
                    db7_forms_id BIGINT(20) UNSIGNED,
                    lead_source VARCHAR(100),
                    field_name VARCHAR(100),
                    field_type VARCHAR(50),
                    field_value LONGTEXT,
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name10 = $wpdb->prefix.'cfdb7_delete_entries_field_name_options_form_'.$form_id;
            if(!in_array($table_name10, $tables)){
                $sql = "CREATE TABLE {$table_name10} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    field_name VARCHAR(100),
                    entry_count VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name11 = $wpdb->prefix.'cfdb7_display_settings_form_'.$form_id;
            if(!in_array($table_name11, $tables)){
                $sql = "CREATE TABLE {$table_name11} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id VARCHAR(100),
                    context VARCHAR(100),
                    settings LONGTEXT,
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name12 = $wpdb->prefix.'cfdb7_entries_logs_form_'.$form_id;
            if(!in_array($table_name12, $tables)){
                $sql = "CREATE TABLE {$table_name12} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    lead_source VARCHAR(100),
                    form_setting LONGTEXT,
                    db7_forms_id BIGINT(20) UNSIGNED,
                    original_entry LONGTEXT,
                    original_entry_fields LONGTEXT,
                    form_entry LONGTEXT,
                    proceed_entry LONGTEXT,
                    proceed_entry_fields LONGTEXT,
                    entry_id BIGINT(20) UNSIGNED,
                    entry_details LONGTEXT,
                    date_time DATETIME,
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name13 = $wpdb->prefix.'cfdb7_entries_logs_submission_form_'.$form_id;
            if(!in_array($table_name13, $tables)){
                $sql = "CREATE TABLE {$table_name13} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    entry_id BIGINT(20) UNSIGNED,
                    db7_forms_id BIGINT(20) UNSIGNED,
                    lead_source VARCHAR(100),
                    field_name VARCHAR(100),
                    field_type VARCHAR(50),
                    field_value LONGTEXT,
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }

            $table_name14 = $wpdb->prefix.'cfdb7_entries_logs_field_name_options_form_'.$form_id;
            if(!in_array($table_name14, $tables)){
                $sql = "CREATE TABLE {$table_name14} (
                    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                    field_name VARCHAR(100),
                    entry_count VARCHAR(100),
                    PRIMARY KEY  (id)
                ) $charset_collate;";

                dbDelta($sql);
            }
        }
    }
}

function cfdb7_get_logged_in_user_info(){
    $user_id = get_current_user_id();
    if(!empty($user_id)){
        $subject = new WP_User($user_id);   

        $all_capabilities = $subject->allcaps;
        $all_capabilities = !empty($all_capabilities) ? $all_capabilities : array();

        $is_administrator = false; 
        if ( current_user_can('administrator') ){
            $all_capabilities[] = "manage_options";
        }
	    return array('capabilities' => $all_capabilities, 'display_name' => $subject->data->display_name, 'user_id' => $user_id) ;
    }else{  
	    return array('capabilities' => "", 'display_name' => "", 'user_id' => "") ;
    }
}

function cfdb7_get_ip_address(){
    $ip_address = (isset($_SERVER['X_FORWARDED_FOR']) && !empty(rest_is_ip_address(sanitize_text_field($_SERVER['X_FORWARDED_FOR'])))) ?  sanitize_text_field($_SERVER['X_FORWARDED_FOR']) : "";

    if(empty($ip_address)){
        $ip_address = (isset($_SERVER['REMOTE_ADDR']) && !empty(rest_is_ip_address(sanitize_text_field($_SERVER['REMOTE_ADDR'])))) ?  sanitize_text_field($_SERVER['REMOTE_ADDR']) : "";
    }

    return $ip_address;
}

function cfdb7_get_form_setting($wpdb, $obj, $form_post_id){
    $form_setting = $obj->get_cfdb7_form_setting($wpdb, $form_post_id);
    $form_setting = isset($form_setting['settings']) && !empty($form_setting['settings']) ? maybe_unserialize($form_setting['settings']) : array();

    $avoid_duplicate_submission = "";
    $avoid_field = "";
    $excludes_fields = "";
    if(!empty($form_setting)){
        $avoid_duplicate_submission = isset($form_setting['avoid_duplicate_submission']) && !empty($form_setting['avoid_duplicate_submission']) ? $form_setting['avoid_duplicate_submission'] : "";
        $avoid_field = isset($form_setting['avoid_field']) && !empty($form_setting['avoid_field']) ? $form_setting['avoid_field'] : "";
        $excludes_fields = isset($form_setting['excludes_fields']) && !empty($form_setting['excludes_fields']) ? $form_setting['excludes_fields'] : array();
    }

    return array('avoid_duplicate_submission' => $avoid_duplicate_submission, 'avoid_field' => $avoid_field, 'excludes_fields' => $excludes_fields);
}

function cfdb7_form_data_after_applied_settings($field_data, $form_setting, $cf7_id, $obj, $wpdb){
    $cfdb7_avoid_duplicate_submission = isset($form_setting['avoid_duplicate_submission']) && !empty($form_setting['avoid_duplicate_submission']) ? $form_setting['avoid_duplicate_submission'] : "";
    $cfdb7_avoid_field = isset($form_setting['avoid_field']) && !empty($form_setting['avoid_field']) ? $form_setting['avoid_field'] : "";
    $cfdb7_excludes_fields = isset($form_setting['excludes_fields']) && !empty($form_setting['excludes_fields']) ? $form_setting['excludes_fields'] : array();

    if($cfdb7_avoid_duplicate_submission == "on" && !empty($cfdb7_avoid_field)){
        $field_value = isset($field_data[$cfdb7_avoid_field]) && !empty($field_data[$cfdb7_avoid_field]) ? $field_data[$cfdb7_avoid_field] : "";
        if(!empty($field_value)){
            $submitted_data = $obj->check_Cfdb7_submission($wpdb, $cf7_id, $cfdb7_avoid_field, $field_value);
            if(!empty($submitted_data)){
                $field_data = array();
            }
        }
    }

    if(!empty($cfdb7_excludes_fields) && !empty($field_data)){
        $submission_names = array_keys($field_data);
        foreach($cfdb7_excludes_fields as $excludes_field){
            if(in_array($excludes_field, $submission_names)){
                unset($field_data[$excludes_field]);
            }
        }   
    }

    if(isset($field_data['cfdb7_status'])){
        unset($field_data['cfdb7_status']);
    }
    
    return $field_data;
}

function cfdb7_save_report_field_for_field_name_options($field_names, $cf7_id, $obj, $wpdb){
    if(!empty($field_names)){
        foreach($field_names as $field_name){
            $field_info = $obj->get_cfdb7_report_field_name_options_count($wpdb, $cf7_id, $field_name);
            if(!empty($field_info)){
                $field_option_info = $obj->get_cfdb7_report_field_name_options($wpdb, $cf7_id, $field_name);
                if(!empty($field_option_info)){
                    $obj->update_cfdb7_report_field_name_options($wpdb, $cf7_id, $field_info[0]['field_name'], $field_info[0]['count']);
                }else{
                    $obj->save_cfdb7_report_field_name_options($wpdb, $cf7_id, $field_info[0]['field_name'], $field_info[0]['count']);
                }
            }

            $log_field_info = $obj->get_cfdb7_log_report_field_name_options_count($wpdb, $cf7_id, $field_name);
            if(!empty($log_field_info)){
                $field_option_info = $obj->get_cfdb7_log_report_field_name_options($wpdb, $cf7_id, $field_name);
                if(!empty($field_option_info)){
                    $obj->update_cfdb7_log_report_field_name_options($wpdb, $cf7_id, $log_field_info[0]['field_name'], $log_field_info[0]['count']);
                }else{
                    $obj->save_cfdb7_log_report_field_name_options($wpdb, $cf7_id, $log_field_info[0]['field_name'], $log_field_info[0]['count']);
                }
            }
        }
    }
}

function cfdb7_sanitize_field_data($field_data){
    $sanitized_data = array();
    if(!empty($field_data)){
        foreach($field_data as $key => $value){
            $sanitized_key = sanitize_text_field($key);
            //Convert special character to html entity
            //It is prevent XSS attack
            $sanitized_value = htmlspecialchars($value);
            //It is prevent JS injection
            $sanitized_value = sanitize_textarea_field($sanitized_value);

            $sanitized_data[$sanitized_key] = $sanitized_value;
        }
    }
    return $sanitized_data;
}

function cfdb7_form_data_after_applied_field_type($entry_fields, $field_data, $cf7_tags){
    if(!empty($field_data) && is_array($field_data)){
        foreach($field_data as $field_name => $field_value){
            $field_name = sanitize_text_field($field_name);
            // Get field type from CF7 tags, default to 'text' if not found
            $entry_fields[$field_name] = isset($cf7_tags[$field_name]) && !empty($cf7_tags[$field_name]) ? $cf7_tags[$field_name] : "text";
        }
    }
    return $entry_fields;
}

?>