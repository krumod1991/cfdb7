<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin
*/

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin
 * @author     Pinky dev
*/
class Cfdb7_Pro_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	*/
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	*/
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	*/
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	*/
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Cfdb7_Pro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Cfdb7_Pro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/cfdb7-pro-admin.css', array(), $this->version.'_'.time(), 'all' );
		//Other functionality styles
		wp_register_style( 'cfdb7_chosen_style', plugin_dir_url( __FILE__ ) . 'css/chosen.min.css', array(), $this->version, 'all' );
		wp_register_style( 'cfdb7_magnific_popup_style', plugin_dir_url( __FILE__ ) . 'css/magnific-popup.css', array(), $this->version, 'all' );
		wp_register_style('jquery-ui-css', plugin_dir_url( __FILE__ ).'css/jquery-ui.css', array(), $this->version, 'all' );
		//Pages styles
		wp_register_style( 'cfdb7_entries_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_entries_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_entries_bulk_action_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_entries_bulk_action.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_delete_entries_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_delete_entries_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_export_log_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_export_logs_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_entry_logger_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_entry_logger_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_indexing_entries_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_indexing_entries.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_indexing_field_names_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_indexing_field_names_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_import_entries_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_import_entries_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_setting_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_setting_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_tools_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_tools_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_contact_us_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_contact_us_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_document_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_documentation_style.css', array(), $this->version.'_'.time(), 'all' );
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	*/
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Cfdb7_Pro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Cfdb7_Pro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_register_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/cfdb7-pro-admin.js', array( 'jquery' ), $this->version.'_'.time(), false );

		$cfdb7_params = array(
			'ajax_url' => admin_url('admin-ajax.php'),
			'require_massage' => esc_html__( 'Please select a file.', CFDB7_PRO_TEXT_DOMAIN ),
			'invalid_file_massage' => esc_html__( 'Invalid file. Please select a CSV file.', CFDB7_PRO_TEXT_DOMAIN ),
			'fail_index_message' => esc_html__( 'Something went wrong.', CFDB7_PRO_TEXT_DOMAIN ),
			'success_index_message' => esc_html__( 'Indexing successfully completed.', CFDB7_PRO_TEXT_DOMAIN ),
			'return_to_entries' => esc_html__( 'Return to the entries.', CFDB7_PRO_TEXT_DOMAIN ),
			'return_to_delete_entries' => esc_html__( 'Return to the deleted entries log.', CFDB7_PRO_TEXT_DOMAIN ),
			'chosen_placeholder' => esc_html__( 'Select fields', CFDB7_PRO_TEXT_DOMAIN ),
			'chosen_no_results' => esc_html__( 'No matches found.', CFDB7_PRO_TEXT_DOMAIN ),
		);
		wp_localize_script( $this->plugin_name, 'cfdb7_params', $cfdb7_params );

		// Enqueued script with localized data.
		wp_enqueue_script( $this->plugin_name );
		//Pages scripts
		wp_register_script( 'cfdb7_entries_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_entries_script.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_entries_bulk_action_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_entries_bulk_action.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_delete_entries_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_delete_entries_script.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_export_logs_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_export_logs_script.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_entry_logger_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_entry_logger_script.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_indexing_entries_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_indexing_entries.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_indexing_field_names_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_indexing_field_names_script.js', array( 'jquery' ), $this->version.'_'.time(), false );			
		wp_register_script( 'cfdb7_import_entries_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_import_entries_script.js', array( 'jquery' ), $this->version.'_'.time(), false );			
		wp_register_script( 'cfdb7_setting_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_setting_script.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_tools_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_tools_script.js', array( 'jquery' ), $this->version.'_'.time(), false );
		//Other functionality scripts
		wp_register_script( 'cfdb7_chosen_script', plugin_dir_url( __FILE__ ) . 'js/chosen.jquery.min.js', array( 'jquery' ), $this->version, false );
		wp_register_script( 'cfdb7_magnific_popup_script', plugin_dir_url( __FILE__ ) . 'js/magnific-popup.min.js', array( 'jquery' ), $this->version, false );
		wp_register_script( 'cfdb7_display_setting_sortable', plugin_dir_url( __FILE__ ) . 'js/cfdb7-display-setting-sortable.js', array( 'jquery' ), $this->version, false );
	}

	/**
	 * Check if the required plugin is installed and activated.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_check_required_plugin(){
		// The plugin you depend on — path relative to plugins directory
		$required_plugin = 'contact-form-7/wp-contact-form-7.php';

		// Check if the required plugin is active
		if (!is_plugin_active($required_plugin)){
			$this->cfdb7_display_deactivation_notice($required_plugin, 'Contact Form 7');
		}else{
			$required_plugin = 'contact-form-cfdb7/contact-form-cfdb-7.php';
			if (!is_plugin_active($required_plugin)){
				$this->cfdb7_display_deactivation_notice($required_plugin, 'Contact Form CFDB7');
			}
		}
	}

	/**
	 * Display an admin notice when a required plugin is missing or inactive.
	 *
	 * @since    1.0.0
	 * @param    string    $required_plugin       The name of the required plugin.
	 * @param    string    $parent_plugin_name    The name of the parent plugin depending on it.
	*/
	private function cfdb7_display_deactivation_notice($required_plugin, $parent_plugin_name){
		// Deactivate *this* plugin
		deactivate_plugins(plugin_basename(__FILE__));

		// Optional: show an admin notice
		add_action('admin_notices', function() use ($required_plugin, $parent_plugin_name) {
			$plugin_data = get_plugin_data(__FILE__);

			echo '<div class="notice notice-error"><p>';
			printf(
				/* translators: 1: Plugin name, 2: Required parent plugin name */
				esc_html__(
					'%1$s requires %2$s to be active. The plugin has been deactivated.',
					CFDB7_PRO_TEXT_DOMAIN
				),
				esc_html($plugin_data['Name']),
				'<strong>' . esc_html($parent_plugin_name) . '</strong>'
			);
			echo '</p></div>';
		});
	}

	/**
	 * Add a settings link to the plugin action links.
	 *
	 * @since    1.0.0
	 * @param    array    $links    The existing plugin action links.
	 * @return   array              The modified plugin action links.
	*/
	public function cfdb7_add_setting_link_plugin($links){
		$settings_link = '<a href="admin.php?page=cfdb7-settings">'.esc_html__('Settings', CFDB7_PRO_TEXT_DOMAIN).'</a>';
		array_unshift($links, $settings_link);
		return $links;
	}

	/**
	 * Register the custom admin menu for the plugin.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_custom_admin_menu(){
		$user_info = cfdb7_get_logged_in_user_info();
		$capabilities = !empty($user_info['capabilities']) && is_array($user_info['capabilities']) ? array_map('sanitize_text_field', $user_info['capabilities']) : array();

		$view_capability = "";
		$import_capability = "";
		$has_access = false;
		if(!empty($capabilities)){
			if(in_array("manage_options", $capabilities)){
				$view_capability = "manage_options";
				$import_capability = "manage_options";
			}

			$view_cfdb7_form = !empty(preg_grep('/^cfdb7_form_view_entry/', array_keys($capabilities)));
			if($view_cfdb7_form == true){
				$view_capability = "exist";
			}

			$import_cfdb7_entry = !empty(preg_grep('/^cfdb7_form_import_entry/', array_keys($capabilities)));
			if($import_cfdb7_entry == true){
				$import_capability = "exist";
			}
		}

		if(!empty($view_capability)){
			add_menu_page(esc_html__('CFDB7 Entries', CFDB7_PRO_TEXT_DOMAIN), esc_html__('CFDB7 Entries', CFDB7_PRO_TEXT_DOMAIN), $view_capability, 'cfdb7-entries', array($this, 'cfdb7_entries_page'), 'dashicons-email-alt2', 25);
			if (CFDB7_ACTIVATED == true){
				add_submenu_page('cfdb7-entries', esc_html__('Delete & Restore', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Delete & Restore', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-delete-and-restore', array($this, 'cfdb7_delete_and_restore_page'));
				add_submenu_page('cfdb7-entries', esc_html__('Export Logs', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Export Logs', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-export-logs', array($this, 'cfdb7_export_logs_page'));
				add_submenu_page('cfdb7-entries', esc_html__('Entry Logger', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Entry Logger', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-entry-logger', array($this, 'cfdb7_entry_logger_page'));
				add_submenu_page('cfdb7-entries', esc_html__('Indexing Entries', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Indexing Entries', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-indexing-entries', array($this, 'cfdb7_indexing_entries_page'));
				add_submenu_page('cfdb7-entries', esc_html__('Indexing Field Names', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Indexing Field Names', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-indexing-field-name', array($this, 'cfdb7_indexing_field_name_page'));
				if(!empty($import_capability)){
					add_submenu_page('cfdb7-entries', esc_html__('Import Entries', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Import Entries', CFDB7_PRO_TEXT_DOMAIN), $import_capability, 'cfdb7-import-entries', array($this, 'cfdb7_import_entries_page'));
				}
				add_submenu_page('cfdb7-entries', esc_html__('Settings', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Settings', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-settings', array($this, 'cfdb7_settings_page'));
				add_submenu_page('cfdb7-entries', esc_html__('Tools', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Tools', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-tools', array($this, 'cfdb7_tools_page'));
				
				add_submenu_page('cfdb7-entries', esc_html__('Contact Us', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Contact Us', CFDB7_PRO_TEXT_DOMAIN), 'exist', 'cfdb7-contact-us', array($this, 'cfdb7_contact_us_page'));
				add_submenu_page('cfdb7-entries', esc_html__('Documentation', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Documentation', CFDB7_PRO_TEXT_DOMAIN), 'exist', 'cfdb7-documentation', array($this, 'cfdb7_documentation_page'));
				//Action for add sub menu page
				do_action( 'cfdb7_add_submenu_page', 'cfdb7-entries' );
			}
		}
	}

	/**
	 * Renders and processes the CFDB7 entries admin page.
	 *
	 * This method handles two main behaviors:
	 * 
	 * 1. **Display Mode** (default):
	 *    - When no bulk action or export request is posted, it loads the form list
	 *      and displays the entries page template.
	 *
	 * 2. **Action Mode** (bulk actions and exports):
	 *    - Enqueues required styles and scripts for bulk actions.
	 *    - Validates and reads the posted `page` and `action` values.
	 *    - Based on the action, loads the appropriate partial:
	 *        - `delete`       → Deletes selected entry IDs.
	 *        - `export`       → Exports selected entry IDs.
	 *        - `export-all`   → Exports all entries for the selected form.
	 *
	 * @since    1.0.0
	 * @return void
	*/
	public function cfdb7_entries_page() {
		if(!isset($_POST['bulk_action']) && !isset($_POST['cfdb7-entries-export-all'])){
			$forms_list = $this->get_contact_forms_list();
			include_once plugin_dir_path(__FILE__).'partials/cfdb7_entries.php';
		}else if(isset($_POST['bulk_action']) || isset($_POST['cfdb7-entries-export-all'])){
			wp_enqueue_style('cfdb7_entries_bulk_action_style');
			wp_enqueue_style('cfdb7_magnific_popup_style');
			wp_enqueue_script('cfdb7_entries_bulk_action_script');
			wp_enqueue_script('cfdb7_magnific_popup_script');

			$page = isset($_POST['page']) && !empty($_POST['page']) ? sanitize_text_field($_POST['page']) : "";
			$action = isset($_POST['action']) && !empty($_POST['action']) ? sanitize_text_field($_POST['action']) : "";
			if($page == "cfdb7-entries" && $action == "delete"){
				include_once plugin_dir_path(__FILE__).'partials/cfdb7_entries_delete_entry_ids.php';
			}else if($page == "cfdb7-entries" && $action == "export"){
				include_once plugin_dir_path(__FILE__).'partials/cfdb7_entries_export_entry_ids.php';
			}else if($page == "cfdb7-entries" && $action == "export-all"){
				include_once plugin_dir_path(__FILE__).'partials/cfdb7_entries_export_all_entry_ids.php';
			}
		}
	}

	/**
	 * Displays and processes the CFDB7 “Delete & Restore” entries page.
	 *
	 * This method supports two modes:
	 *
	 * 1. **Display Mode** (default):
	 *    - When no bulk action is posted, retrieves the list of forms and loads
	 *      the delete/restore management page template.
	 *
	 * 2. **Action Mode** (bulk delete or restore):
	 *    - Enqueues required styles and scripts for handling bulk operations.
	 *    - Sanitizes and reads the posted `page` and `action` parameters.
	 *    - Loads the appropriate partial based on the requested action:
	 *        - `delete`  → Permanently deletes selected entry IDs.
	 *        - `restore` → Restores selected entry IDs to active entries.
	 *
	 * @since    1.0.0
	 * @return void
	*/
	public function cfdb7_delete_and_restore_page() {
		if(!isset($_POST['bulk_action'])){
			$forms_list = $this->get_contact_forms_list();
			include_once plugin_dir_path(__FILE__).'partials/cfdb7_delete_and_restore_entries.php';
		}else if(isset($_POST['bulk_action'])){
			wp_enqueue_style('cfdb7_entries_bulk_action_style');
			wp_enqueue_style('cfdb7_magnific_popup_style');
			wp_enqueue_script('cfdb7_entries_bulk_action_script');
			wp_enqueue_script('cfdb7_magnific_popup_script');

			$page = isset($_POST['page']) && !empty($_POST['page']) ? sanitize_text_field($_POST['page']) : "";
			$action = isset($_POST['action']) && !empty($_POST['action']) ? sanitize_text_field($_POST['action']) : "";
			if($page == "cfdb7-delete-and-restore" && $action == "delete"){
				include_once plugin_dir_path(__FILE__).'partials/cfdb7_delete_entries_delete_ids.php';
			}else if($page == "cfdb7-delete-and-restore" && $action == "restore"){
				include_once plugin_dir_path(__FILE__).'partials/cfdb7_delete_entries_restore_ids.php';
			}
		}
	}

	/**
	 * Display the export logs page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_export_logs_page() {
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_export_logs.php';
	}

	/**
	 * Display the entry logger page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_entry_logger_page(){
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_entry_logger.php';
	}

	/**
	 * Display the indexing entries page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_entries_page() {
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_indexing_entries.php';
	}

	/**
	 * Display the indexing field name page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_field_name_page() {
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_indexing_field_names.php';
	}

	/**
	 * Display the import entries page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_import_entries_page() {
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_import_entries.php';
	}

	/**
	 * Display the plugin settings page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_settings_page() {
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_settings.php';
	}

	/**
	 * Display the plugin tools page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_tools_page(){
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_tools.php';
	}

	/**
	 * Display the Contact Us page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_contact_us_page(){
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_contact_us.php';
	}

	/**
	 * Display the plugin documentation page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_documentation_page(){
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_documentation.php';
	}

	/**
	 * Retrieve a list of all Contact Form 7 forms.
	 *
	 * @since    1.0.0
	 * @return   array    An array of contact forms.
	*/
	private function get_contact_forms_list(){
		$forms_list = cfdb7_get_contact_forms_list();
		return $forms_list;
	}

	/**
	 * Generate necessary database tables for storing form entries.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_generate_tables(){
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		if(!empty($nonce)){
			$result = array();
			if(wp_verify_nonce($nonce, 'generate_tables')){
				$result['status'] = "success";
				add_lead_source_column();
				cfdb7_generate_basic_tables();
        		cfdb7_generate_entries_table();
				$result['message'] = esc_html__( 'Table generated successfully.', CFDB7_PRO_TEXT_DOMAIN );
			}else{
				$result['status'] = "fail";
				$result['message'] = esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN );
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Index the field names of form entries for faster searching.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_entries_field_names(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		if(!empty($cf7_id) && !empty($nonce)){
			$result = array();
			if(wp_verify_nonce($nonce, 'indexing_field_names')){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();
				//Delete all options from db
				$obj->truncate_cfdb7_report_field_name_options($wpdb, $cf7_id);
				
				$fields_list = $obj->get_cfdb7_report_field_name_options_count($wpdb, $cf7_id);
				if(!empty($fields_list)){
					foreach($fields_list as $field_list){
						$field_name_safe = isset($field_list['field_name']) ? sanitize_text_field($field_list['field_name']) : '';
						$count_safe = isset($field_list['count']) ? intval($field_list['count']) : 0;
						$obj->save_cfdb7_report_field_name_options($wpdb, $cf7_id, $field_name_safe, $count_safe);
					}
					$result['status'] = "success";
					$result['message'] = esc_html__( 'Indexing successfully for form entries.', CFDB7_PRO_TEXT_DOMAIN );
				}else{
					$result['message'] = esc_html__( 'No Entries found for form entries.', CFDB7_PRO_TEXT_DOMAIN );
					$result['status'] = "fail";
				}
			}else{
				$result['message'] = esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN );
				$result['status'] = "fail";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Index the field names of form entries for faster searching.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_delete_entries_field_names(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		if(!empty($cf7_id) && !empty($nonce)){
			$result = array();
			if(wp_verify_nonce($nonce, 'indexing_field_names')){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();
				//Delete all options from db
				$obj->truncate_cfdb7_delete_report_field_name_options($wpdb, $cf7_id);
				
				$fields_list = $obj->get_cfdb7_delete_report_field_name_options_count($wpdb, $cf7_id);
				if(!empty($fields_list)){
					foreach($fields_list as $field_list){
						$field_name_safe = sanitize_text_field($field_list['field_name']);
						$count_safe = intval($field_list['count']);
						$obj->save_cfdb7_delete_report_field_name_options($wpdb, $cf7_id, $field_name_safe, $count_safe);
					}
					$result['status'] = "success";
					$result['message'] = esc_html__( 'Indexing successfully for delete entries.', CFDB7_PRO_TEXT_DOMAIN );
				}else{
					$result['message'] = esc_html__( 'No Entries found for delete entries.', CFDB7_PRO_TEXT_DOMAIN );
					$result['status'] = "fail";
				}
			}else{
				$result['message'] = esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN );
				$result['status'] = "fail";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Index the field names of form entries for faster searching.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_log_entries_field_names(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		if(!empty($cf7_id) && !empty($nonce)){
			$result = array();
			if(wp_verify_nonce($nonce, 'indexing_field_names')){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();
				//Delete all options from db
				$obj->truncate_cfdb7_log_report_field_name_options($wpdb, $cf7_id);
				
				$fields_list = $obj->get_cfdb7_log_report_field_name_options_count($wpdb, $cf7_id);
				if(!empty($fields_list)){
					foreach($fields_list as $field_list){
						$field_name_safe = sanitize_text_field($field_list['field_name']); 
						$count_safe = intval($field_list['count']);
						$obj->save_cfdb7_log_report_field_name_options($wpdb, $cf7_id, $field_name_safe, $count_safe);
					}
					$result['status'] = "success";
					$result['message'] = esc_html__( 'Indexing successfully for log entries.', CFDB7_PRO_TEXT_DOMAIN );
				}else{
					$result['message'] = esc_html__( 'No Entries found for log entries.', CFDB7_PRO_TEXT_DOMAIN );
					$result['status'] = "fail";
				}
			}else{
				$result['message'] = esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN );
				$result['status'] = "fail";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Callback triggered after a Contact Form 7 form is created.
	 *
	 * @since    1.0.0
	 * @param    object    $contact_form    The newly created Contact Form 7 form object.
	*/
	public function cfdb7_wpcf7_after_create($contact_form){
		$cf7_id = intval($contact_form->id);
		cfdb7_generate_entries_table($cf7_id);
	}

	/**
	 * Display indexing information for form entries.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_info(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		if(!empty($cf7_id) && !empty($nonce)){
			$result = array();
			if(wp_verify_nonce($nonce, 'indexing_entries')){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();

				$entries_count = $obj->get_cfdb7_delete_entries_count($wpdb, $cf7_id);
				$enquiry_info = $obj->get_db7_forms_entries_count($wpdb, $cf7_id, $entries_count['count']);
				if(!empty($enquiry_info)){
					if($enquiry_info['count'] > 0){
						$ppp = 50;
						$ppp = apply_filters( 'cfdb7_indexing_ppp', $ppp );

						$result['status'] = "success";
						$result['count'] = $enquiry_info['count'];
						$result['max_pages'] = ceil($enquiry_info['count']/$ppp);
					}else{
						$result['message'] = esc_html__( 'No entries found for indexing.', CFDB7_PRO_TEXT_DOMAIN );
						$result['status'] = "fail";
					}
				}else{
					$result['message'] = esc_html__( 'No entries found for indexing.', CFDB7_PRO_TEXT_DOMAIN );
					$result['status'] = "fail";
				}
			}else{
				$result['message'] = esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN );
				$result['status'] = "fail";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Index cfdb-7 form entries for retrieval.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_entries(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		if(!empty($cf7_id) && !empty($nonce)){
			$result = array();
			if(wp_verify_nonce($nonce, 'indexing_entries')){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();

				$ppp = 50;
				$ppp = intval(apply_filters( 'cfdb7_indexing_ppp', $ppp ));

				$entries_count = $obj->get_cfdb7_delete_entries_count($wpdb, $cf7_id);
				$indexing_entries = $obj->get_db7_forms_indexing_entries($wpdb, $cf7_id, $ppp, $entries_count['count']);
				if(!empty($indexing_entries)){
					$result['is_next_page'] = "yes";
					
					$tags = cfdb7_get_form_tags($cf7_id);
					//Set fields list
					$cf7_tags = array();
					if(!empty($tags)){
						foreach ( $tags as $tag ){
							if(!empty($tag->name)){
								$safe_name = sanitize_text_field($tag->name);
								$safe_type = sanitize_text_field($tag->basetype);
								$cf7_tags[$safe_name] = $safe_type;
							}
						}
					}

					//$form_setting use to applied setting to form data
					$form_setting = cfdb7_get_form_setting($wpdb, $obj, $cf7_id);
					$date_time = current_time("Y-m-d H:i:s");

					$available_field_names = array();
					foreach($indexing_entries as $indexing_entry){
						$field_data = isset($indexing_entry['form_value']) && !empty($indexing_entry['form_value']) ? maybe_unserialize($indexing_entry['form_value']) : array();
						
						$db7_forms_id = isset($indexing_entry['form_id']) && !empty($indexing_entry['form_id']) ? intval($indexing_entry['form_id']) : "";

						$entry_date_time = isset($indexing_entry['form_date']) && !empty($indexing_entry['form_date']) ? sanitize_text_field($indexing_entry['form_date']) : "";

						$lead_source = isset($indexing_entry['lead_source']) && !empty($indexing_entry['lead_source']) ? sanitize_text_field($indexing_entry['lead_source']) : "cf7";

						$field_names = array_keys($field_data);
						foreach($field_names as $proceed_name){
							if(!in_array($proceed_name, $available_field_names)){
								$available_field_names[] = $proceed_name;
							}
						}

						$original_field_data = $field_data;
						//Sanitize existing field data
						$original_field_data = cfdb7_sanitize_field_data($original_field_data);
						$field_data = cfdb7_sanitize_field_data($field_data);

						if(!empty($original_field_data)){
							if(isset($original_field_data['cfdb7_status'])){
								unset($original_field_data['cfdb7_status']);
							}
						}

						//Apply field type processing
						$original_entry_fields = cfdb7_form_data_after_applied_field_type($field_data, $cf7_tags);

						$logger = array();
						$logger['date_time'] = $date_time;
						$logger['lead_source'] = $lead_source;
						$logger['form_setting'] = $form_setting;
						$logger['db7_forms_id'] = $db7_forms_id;
						$logger['original_entry'] = $field_data;
						$logger['original_entry_fields'] = $original_entry_fields;
						$logger['form_entry'] = sanitize_textarea_field($indexing_entry);
						
						//Validate entry with form settings
						$field_data = cfdb7_form_data_after_applied_settings($field_data, $form_setting, $cf7_id, $obj, $wpdb);
						$logger['proceed_entry'] = $field_data;

						$cfdb7_data = array(
							'field_data' => $field_data,
							'cf7_tags' => $cf7_tags,
							'cf7_id' => $cf7_id,
							'db7_forms_id' => $db7_forms_id,
							'form_date' => $entry_date_time,
							'lead_source' => $lead_source,
							'user_id' => "",
							'display_name' => "",
							'ip_address' => "",
							'original_field_data' => $original_field_data,
						);
						$entry_result = cfdb7_proceed_save_entry($wpdb, $obj, $cfdb7_data);

						$logger['proceed_entry_fields'] = $entry_result['proceed_entry_fields'];
						$logger['entry_id'] = $entry_result['entry_id'];
						$logger['entry_details'] = $entry_result['entry_details'];
						
						//Save logs for indexing
						$obj->save_entry_log($wpdb, $cf7_id, $logger);
					}

					//Save report field information 
					$available_fields = array_map('sanitize_text_field', $available_field_names);
					cfdb7_save_report_field_for_field_name_options($available_fields, $cf7_id, $obj, $wpdb);
				}else{
					$result['message'] = esc_html__( 'No entries found for indexing.', CFDB7_PRO_TEXT_DOMAIN );
					$result['is_next_page'] = "no";
				}
			}else{
				$result['message'] = esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN );
				$result['is_next_page'] = "no";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Retrieve information from the entry logger.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_get_entry_logger_information(){
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_entry_logger_information.php';
		wp_die();
	}

	/**
	 * Save the user display settings for the plugin.
	 *
	 * @since    1.0.0
	 * @param    array     $posted_data    The data submitted by the user.
	 * @param    object    $wpdb           The WordPress database object.
	 * @param    object    $obj            Additional object containing context or methods.
	*/
	public function cfdb7_save_display_user_setting($posted_data, $wpdb, $obj){
		$nonce = isset($_POST['cfdb7_display_setting_nonce']) && !empty($_POST['cfdb7_display_setting_nonce']) ? sanitize_text_field($_POST['cfdb7_display_setting_nonce']) : "";
		if(!empty($nonce)){
			if(wp_verify_nonce($nonce, 'cfdb7_display_setting')){
				$cf7_id = isset($posted_data['cf7-id']) && !empty($posted_data['cf7-id']) ? intval($posted_data['cf7-id']) : "";
				if(empty($cf7_id)){
					return;
				}

				// Get current user information
				$user_info = cfdb7_get_logged_in_user_info();
				$user_id = $user_info['user_id'];
				// Determine context based on current page
				$context = isset($posted_data['page']) && !empty($posted_data['page']) ? sanitize_text_field($posted_data['page']) : "";
				// Prepare display settings array
				$display_settings = array();
				// Process field rename settings
				if(isset($posted_data['rename_field']) && is_array($posted_data['rename_field'])){
					foreach($posted_data['rename_field'] as $field_name => $rename_value){
						$field_name = sanitize_text_field($field_name);
						$rename_value = sanitize_text_field(trim($rename_value));
						
						if(!empty($rename_value)){
							$display_settings['rename_field'][$field_name] = $rename_value;
						}
					}

					$field_order = array_keys($posted_data['rename_field']);
					$field_order = array_map("sanitize_text_field", $field_order);
					$display_settings['field_order'] = $field_order;
				}

				// Process field visibility settings
				if(isset($posted_data['enable_field']) && is_array($posted_data['enable_field'])){
					foreach($posted_data['enable_field'] as $field_name => $enabled){
						$field_name = sanitize_text_field($field_name);
						$display_settings['enable_field'][$field_name] = true;
					}
				}

				// Serialize settings for storage
				$settings_serialized = maybe_serialize($display_settings);

				// Check if settings already exist for this user, form, and context
				$existing_settings = $obj->get_cfdb7_form_display_settings($wpdb, $cf7_id, $user_id, $context);
				
				if(!empty($existing_settings)){
					// Update existing settings
					$obj->update_cfdb7_form_display_settings($wpdb, $cf7_id, $user_id, $context, $settings_serialized);
				} else {
					// Save new settings
					$obj->save_cfdb7_form_display_settings($wpdb, $cf7_id, $user_id, $context, $settings_serialized);
				}
				
				// Add success notice
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Display settings saved successfully.', CFDB7_PRO_TEXT_DOMAIN) . '</p></div>';
			}else{
				echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Security check failed. Please try again..', CFDB7_PRO_TEXT_DOMAIN) . '</p></div>';
			}
		}
	}

	/**
	 * Display a single form entry in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_entries_information(){
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_entries_information.php';
		wp_die();
	}

	/**
	 * Delete multiple form entries based on provided entry IDs.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_entries_delete_entry_ids(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		$current_index = isset($_POST['current_index']) && !empty($_POST['current_index']) ? intval($_POST['current_index']) : "";
		$entry_ids = isset($_POST['entry_ids']) && !empty($_POST['entry_ids']) ? sanitize_text_field($_POST['entry_ids']) : "";
		if(!empty($cf7_id) && !empty($nonce) && !empty($current_index) && !empty($entry_ids)){
			$result = array();
			$index_message = esc_html__( 'index ', CFDB7_PRO_TEXT_DOMAIN )." - {$current_index} - {$entry_ids}";
			if(wp_verify_nonce($nonce, 'cfdb7_entries_'.$cf7_id)){
				$user_info = cfdb7_get_logged_in_user_info();
				// Check if user has delete permission
				$has_permission = false;
				if (!empty($user_info['capabilities']) && is_array($user_info['capabilities'])){
					$capabilities = $user_info['capabilities'];
					if(in_array("cfdb7_form_delete_entry_".$cf7_id, $capabilities) || in_array("manage_options", $capabilities)){
						$has_permission = true;
					}
				}
				
				if ($has_permission == true){
					global $wpdb;
					$obj = new Cfdb7_Queries();
					$obj->init_cfdb7_tables();

					$entry_ids = explode(",", $entry_ids);
					$entry_ids = !empty($entry_ids) ? array_map('intval', $entry_ids) : array();

					if(!empty($entry_ids)){
						$entry_details = $obj->get_cfdb7_entry_ids_details($wpdb, $cf7_id, $entry_ids);
						$submission_details = $obj->get_cfdb7_entry_ids_submissions($wpdb, $cf7_id, $entry_ids);
						
						if(!empty($entry_details) && !empty($submission_details)){
							$delete_date_time = current_time("Y-m-d H:i:s");
							$delete_ip_address = cfdb7_get_ip_address();

							//Save deleted entry details
							foreach($entry_details as $entry_detail){
								$deleted_details = array(
									'form_id' => $cf7_id,

									'entry_id' => isset($entry_detail['entry_id']) && !empty($entry_detail['entry_id']) ? intval($entry_detail['entry_id']) : "",

									'db7_forms_id' => isset($entry_detail['db7_forms_id']) && !empty($entry_detail['db7_forms_id']) ? intval($entry_detail['db7_forms_id']) : "",

									'lead_source' => isset($entry_detail['lead_source']) && !empty($entry_detail['lead_source']) ? sanitize_text_field($entry_detail['lead_source']) : "",
									
									'form_submissions' => isset($entry_detail['form_submissions']) && !empty($entry_detail['form_submissions']) ? $entry_detail['form_submissions'] : "",

									'form_submission_fields' => isset($entry_detail['form_submission_fields']) && !empty($entry_detail['form_submission_fields']) ? $entry_detail['form_submission_fields'] : "",

									'submit_by' => isset($entry_detail['submit_by']) && !empty($entry_detail['submit_by']) ? intval($entry_detail['submit_by']) : "",

									'submit_display_name' => isset($entry_detail['submit_display_name']) && !empty($entry_detail['submit_display_name']) ? sanitize_text_field($entry_detail['submit_display_name']) : "",

									'submit_date_time' => isset($entry_detail['submit_date_time']) && !empty($entry_detail['submit_date_time']) ? sanitize_text_field($entry_detail['submit_date_time']) : "",

									'submit_ip_address' => isset($entry_detail['submit_ip_address']) && !empty($entry_detail['submit_ip_address']) ? sanitize_text_field($entry_detail['submit_ip_address']) : "",

									'delete_by' => isset($user_info['user_id']) && !empty($user_info['user_id']) ? intval($user_info['user_id']) : '',

									'delete_display_name' => isset($user_info['display_name']) && !empty($user_info['display_name']) ? sanitize_text_field($user_info['display_name']) : '',

									'delete_date_time' => $delete_date_time,

									'delete_ip_address' => $delete_ip_address,
								);

								$deleted_details_format = array_fill(0, count($deleted_details), '%s');
								
								$obj->save_cfdb7_delete_entries_log($wpdb, $cf7_id, $deleted_details, $deleted_details_format);
							}

							//Save deleted submission details
							$field_names = array();
							foreach($submission_details as $submission_detail){
								$field_name = isset($submission_detail['field_name']) && !empty($submission_detail['field_name']) ? sanitize_text_field($submission_detail['field_name']) : "";
								if(!empty($field_name)){
									$field_names[] = $field_name;
								}

								$deleted_submissions = array(
									'entry_id' => isset($submission_detail['entry_id']) && !empty($submission_detail['entry_id']) ? intval($submission_detail['entry_id']) : "",

									'db7_forms_id' => isset($submission_detail['db7_forms_id']) && !empty($submission_detail['db7_forms_id']) ? intval($submission_detail['db7_forms_id']) : "",

									'lead_source' => isset($submission_detail['lead_source']) && !empty($submission_detail['lead_source']) ? sanitize_text_field($submission_detail['lead_source']) : "",

									'field_name' => isset($submission_detail['field_name']) && !empty($submission_detail['field_name']) ? sanitize_text_field($submission_detail['field_name']) : "",

									'field_type' => isset($submission_detail['field_type']) && !empty($submission_detail['field_type']) ? sanitize_text_field($submission_detail['field_type']) : "",

									'field_value' => isset($submission_detail['field_value']) && !empty($submission_detail['field_value']) ? sanitize_textarea_field($submission_detail['field_value']) : "",
								);

								$deleted_submissions_format = array_fill(0, count($deleted_submissions), '%s');
								
								$obj->save_cfdb7_delete_entries_submission($wpdb, $cf7_id, $deleted_submissions, $deleted_submissions_format);
							}

							$field_names_count = array_count_values($field_names);

							//Save report field information for deleted entried
							$field_names = array_map('sanitize_text_field', array_keys($field_names_count));
							foreach($field_names as $field_name){
								$deleted_field_info = $obj->get_cfdb7_delete_report_field_name_options_count($wpdb, $cf7_id, $field_name);
								if(!empty($deleted_field_info)){
									$field_option_info = $obj->get_cfdb7_delete_report_field_name_options($wpdb, $cf7_id, $field_name);
									
									$safe_field_name = sanitize_text_field($deleted_field_info[0]['field_name']);
									$count = intval($deleted_field_info[0]['count']);

									if(!empty($field_option_info)){
										$obj->update_cfdb7_delete_report_field_name_options($wpdb, $cf7_id, $safe_field_name, $count);
									}else{
										$obj->save_cfdb7_delete_report_field_name_options($wpdb, $cf7_id, $safe_field_name, $count);
									}
								}
							}

							//Save report field information for entried
							foreach($field_names as $field_name){
								$field_info = $obj->get_cfdb7_report_field_name_options_count($wpdb, $cf7_id, $field_name);
								if(!empty($field_info)){
									$field_option_info = $obj->get_cfdb7_report_field_name_options($wpdb, $cf7_id, $field_name);

									$safe_field_name = sanitize_text_field($field_info[0]['field_name']);
									$count = intval($field_info[0]['count']) - intval($field_names_count[$field_name]);

									if(!empty($field_option_info)){
										$obj->update_cfdb7_report_field_name_options($wpdb, $cf7_id, $safe_field_name, $count);
									}else{
										$obj->save_cfdb7_report_field_name_options($wpdb, $cf7_id, $safe_field_name, $count);
									}
								}
							}

							//Delete entries and submissions from entries table
							foreach($entry_ids as $entry_id){
								//Delete entry details
								$obj->delete_cfdb7_form_entry($wpdb, $cf7_id, $entry_id);
								//Delete entry submissions
								$obj->delete_cfdb7_form_submissions($wpdb, $cf7_id, $entry_id);
							}

							$result['status'] = "success";
							$result['message'] = esc_html__( 'Entries deleted successfully for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
						}else{
							$result['status'] = "fail";
							$result['message'] = esc_html__( 'No Entries found to delete for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
						}
					}else{
						$result['status'] = "fail";
						$result['message'] = esc_html__( 'No Entries found to delete for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
					}
				}else{
					$result['status'] = "fail";
					$result['message'] = esc_html__( 'You do not have permission to delete entries for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
				}
			}else{
				$result['status'] = "fail";
				$result['message'] = esc_html__( 'Security check failed. Please try again for batch.', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
			}
			echo json_encode($result);
		}
		wp_die();
	}
	
	/**
	 * Export multiple form entries based on provided entry IDs.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_entries_export_entry_ids(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		$current_index = isset($_POST['current_index']) && !empty($_POST['current_index']) ? intval($_POST['current_index']) : "";
		$entry_ids = isset($_POST['entry_ids']) && !empty($_POST['entry_ids']) ? sanitize_text_field($_POST['entry_ids']) : "";
		$context = isset($_POST['context']) && !empty($_POST['context']) ? sanitize_text_field($_POST['context']) : "";
		if(!empty($cf7_id) && !empty($nonce) && !empty($current_index) && !empty($entry_ids) && !empty($context)){
			$result = array();
			$index_message = esc_html__( 'index ', CFDB7_PRO_TEXT_DOMAIN )." - {$current_index}";
			if(wp_verify_nonce($nonce, 'cfdb7_entries_'.$cf7_id)){
				$entry_ids = explode(",", $entry_ids);
				$entry_ids = !empty($entry_ids) ? array_map('intval', $entry_ids) : array();
				if(!empty($entry_ids)){
					global $wpdb;
					$obj = new Cfdb7_Queries();
					$obj->init_cfdb7_tables();
					$user_info = cfdb7_get_logged_in_user_info();
					$user_id = $user_info['user_id'];
					//Generate folder if not exists
					//Get upload dir URL
					$path_info = $this->cfdb7_get_upload_path($cf7_id,$user_id, $current_index);
					$upload_path = $path_info['path'];
    				$upload_url  = $path_info['url'];

					$entry_details = $obj->get_cfdb7_entry_ids_details($wpdb, $cf7_id, $entry_ids);
					if(!empty($entry_details)){	
						$export_data = $this->cfdb7_get_export_data($wpdb, $obj, $cf7_id, $user_id, $context, $entry_details);
						if(!empty($export_data)){
							//Generate CSV file
							$csv_generated = $this->cfdb7_generate_csv_file($export_data['header'], $export_data['values'], $upload_path);
							if($csv_generated['status'] == "success"){
								$download_message = "<a href='{$upload_url}' target='_blank' download>".esc_html__( 'Download CSV', CFDB7_PRO_TEXT_DOMAIN )."</a>";

								$result['status'] = "success";
								$result['message'] = $csv_generated['message']." {$index_message} - ".$download_message;
								$result['file_url'] = $upload_url;
								//Save export log
								$this->cfdb7_save_export_log($wpdb, $obj, $cf7_id, $user_info, $upload_path, $upload_url);
							}else{
								$result['status'] = "fail";
								$result['message'] = $csv_generated['message']." {$index_message}";
							}
						}else{
							$result['status'] = "fail";
							$result['message'] = esc_html__( 'No Entries found to export for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
						}
					}else{
						$result['status'] = "fail";
						$result['message'] = esc_html__( 'No Entries found to export for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
					}
				}else{
					$result['status'] = "fail";
					$result['message'] = esc_html__( 'No Entries found to delete for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
				}
			}else{
				$result['status'] = "fail";
				$result['message'] = esc_html__( 'Security check failed. Please try again for batch.', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Export all form entries in chunks.
	 *
	 * @since    1.0.0
	 * 
	*/
	public function cfdb7_entries_export_all_entry_ids(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		$current_index = isset($_POST['current_index']) && !empty($_POST['current_index']) ? intval($_POST['current_index']) : "";
		$context = isset($_POST['context']) && !empty($_POST['context']) ? sanitize_text_field($_POST['context']) : "";
		$chunk_size = isset($_POST['chunk_size']) && !empty($_POST['chunk_size']) ? intval($_POST['chunk_size']) : "";
		if(!empty($cf7_id) && !empty($nonce) && !empty($current_index) && !empty($context) && !empty($chunk_size)){
			$result = array();
			$index_message = esc_html__( 'index ', CFDB7_PRO_TEXT_DOMAIN )." - {$current_index}";
			if(wp_verify_nonce($nonce, 'cfdb7_entries_'.$cf7_id)){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();
				$user_info = cfdb7_get_logged_in_user_info();
				$user_id = $user_info['user_id'];
				//Generate folder if not exists
				//Get upload dir URL
				$path_info = $this->cfdb7_get_upload_path($cf7_id,$user_id, $current_index);
				$upload_path = $path_info['path'];
				$upload_url  = $path_info['url'];

				$search_input = array(
					'limit' => $chunk_size,
					'offset' => ($current_index - 1) * $chunk_size,
				);
				$entry_details = $obj->get_cfdb7_form_entries($wpdb, $cf7_id, $search_input);
				if(!empty($entry_details)){	
					$export_data = $this->cfdb7_get_export_data($wpdb, $obj, $cf7_id, $user_id, $context, $entry_details);
					if(!empty($export_data)){
						//Generate CSV file
						$csv_generated = $this->cfdb7_generate_csv_file($export_data['header'], $export_data['values'], $upload_path);
						if($csv_generated['status'] == "success"){
							$download_message = "<a href='{$upload_url}' target='_blank' download>".esc_html__( 'Download CSV', CFDB7_PRO_TEXT_DOMAIN )."</a>";

							$result['status'] = "success";
							$result['message'] = $csv_generated['message']." {$index_message} - ".$download_message;
							$result['file_url'] = $upload_url;
							//Save export log
							$this->cfdb7_save_export_log($wpdb, $obj, $cf7_id, $user_info, $upload_path, $upload_url);
						}else{
							$result['status'] = "fail";
							$result['message'] = $csv_generated['message']." {$index_message}";
						}
					}else{
						$result['status'] = "fail";
						$result['message'] = esc_html__( 'No Entries found to export for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
					}
				}else{
					$result['status'] = "fail";
					$result['message'] = esc_html__( 'No Entries found to export for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
				}
			}else{
				$result['status'] = "fail";
				$result['message'] = esc_html__( 'Security check failed. Please try again for batch.', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Get upload path and URL for exporting CSV files.
	 *
	 * @since    1.0.0
	 * @param int    $cf7_id        Contact Form 7 form ID used for naming the export file.
	 * @param int    $user_id       ID of the user initiating the export; used in filename hashing.
	 * @param int    $current_index Batch index for multi-part export processes.:
	 * @return array {
	 *     @type string $path Absolute server path where the CSV file will be saved.
	 *     @type string $url  Publicly accessible URL for downloading the generated CSV file.
	 * }
	*/
	private function cfdb7_get_upload_path($cf7_id,$user_id, $current_index){
		$upload_dir = wp_upload_dir();
		//Create custom upload folder
		$cfdb7_upload_folder = CFDB7_UPLOAD_FOLDER;
		$upload_path = $upload_dir['basedir'] . '/' . $cfdb7_upload_folder;
		$upload_url = $upload_dir['baseurl'] . '/' . $cfdb7_upload_folder;
		if (!file_exists($upload_path)) {
			wp_mkdir_p($upload_path); // recursive creation
		}
		//Generate file path
		$md5_file_name = md5($cf7_id.''.time().''.$user_id);
		$upload_path = $upload_path . '/cfdb7-entries-' . $current_index . '-' . $md5_file_name.'.csv';
		$upload_url  = $upload_url . '/cfdb7-entries-' . $current_index . '-' . $md5_file_name.'.csv';

		return array(
			'path' => $upload_path,
			'url' => $upload_url
		);
	}

	/**
	 * Prepare export data based on user display settings and entry details.
	 *
	 * @since    1.0.0
	 * @param wpdb      $wpdb          Global WPDB instance used for database queries.
	 * @param object    $obj           Instance of Cfdb7_Queries containing query helpers.
	 * @param int       $cf7_id        Contact Form 7 form ID whose entries are being exported.
	 * @param int       $user_id       User ID of the person generating the export; used for retrieving display settings.
	 * @param string    $context       Context key for retrieving user display preferences (e.g., 'export', 'reports').
	 * @param array     $entry_details Array of entry records with submission metadata and field values.
	 * @return array {
	 *     @type array $header List of CSV column headers in the correct order.
	 *     @type array $values 2D array of sanitized CSV rows matching the header structure.
	 * }
	 * 
	*/
	private function cfdb7_get_export_data($wpdb, $obj, $cf7_id, $user_id, $context, $entry_details){
		$export_header = array();
		$export_values = array();
		if(!empty($entry_details)){
			//Get user display settings
			$rename_fields = array();
			$enable_fields = array();
			$field_order = array();
			$display_settings = $obj->get_cfdb7_form_display_settings($wpdb, $cf7_id, $user_id, $context);
			if(!empty($display_settings)){
				$saved_settings = isset($display_settings['settings']) && !empty($display_settings['settings']) ? maybe_unserialize($display_settings['settings']) : array();

				if(!empty($saved_settings)){
					$rename_fields = isset($saved_settings['rename_field']) && !empty($saved_settings['rename_field']) ? array_map('sanitize_text_field', $saved_settings['rename_field']) : array();

					$enable_fields = isset($saved_settings['enable_field']) && !empty($saved_settings['enable_field']) ? $saved_settings['enable_field'] : array();

					$field_order = isset($saved_settings['field_order']) && !empty($saved_settings['field_order']) ? array_map('sanitize_text_field', $saved_settings['field_order']) : array();
				}
			}

			//Get available field names
			$field_names = $obj->get_cfdb7_report_field_name_options($wpdb, $cf7_id);
			if(!empty($field_names)){
				//Prepare export data
				$columns = array();
				$exclude_fields = array();
				if(!empty($field_order)){
					foreach ($field_order as $field_name) {
						if(!empty($enable_fields)){
							if(isset($enable_fields[$field_name])){
								$columns[$field_name] = isset($rename_fields[$field_name]) && !empty($rename_fields[$field_name]) ? sanitize_text_field($rename_fields[$field_name]) : sanitize_text_field($field_name);
							}
						}else{
							$columns[$field_name] = isset($rename_fields[$field_name]) && !empty($rename_fields[$field_name]) ? sanitize_text_field($rename_fields[$field_name]) : sanitize_text_field($field_name);
						}
						$exclude_fields[] = sanitize_text_field($field_name);
					}
				}

				$current_fields = wp_list_pluck($field_names, 'field_name');
				if(!empty($current_fields)){
					$current_fields = array_map('sanitize_text_field', $current_fields);
					foreach($current_fields as $proceed_field_name){
						if(!in_array($proceed_field_name, $exclude_fields)){
							if(!empty($enable_fields)){
								if(isset($enable_fields[$proceed_field_name])){
									$columns[$proceed_field_name] = isset($rename_fields[$proceed_field_name]) && !empty($rename_fields[$proceed_field_name]) ? sanitize_text_field($rename_fields[$proceed_field_name]) : sanitize_text_field($proceed_field_name);
								}
							}else{
								$columns[$proceed_field_name] = isset($rename_fields[$proceed_field_name]) && !empty($rename_fields[$proceed_field_name]) ? sanitize_text_field($rename_fields[$proceed_field_name]) : sanitize_text_field($proceed_field_name);
							}   
						}
					}
				}

				if(!empty($columns)){
					$export_field_names = array_keys($columns);

					$export_header = array();
					$export_values = array();

					$export_header[] = esc_html__('Lead Source', CFDB7_PRO_TEXT_DOMAIN);
					foreach($columns as $column_key => $column_value){
						$export_header[] = esc_html($column_value);
					}
					$export_header[] = esc_html__('Submission Date', CFDB7_PRO_TEXT_DOMAIN);
					$export_header[] = esc_html__('IP Address', CFDB7_PRO_TEXT_DOMAIN);
					foreach($entry_details as $entry_detail){
						$entry_data = isset($entry_detail['form_submissions']) && !empty($entry_detail['form_submissions']) ? maybe_unserialize($entry_detail['form_submissions']) : array();
						$entry_data = array_map('sanitize_text_field', $entry_data);

						$form_submission_fields = isset($entry_detail['form_submission_fields']) && !empty($entry_detail['form_submission_fields']) ? maybe_unserialize($entry_detail['form_submission_fields']) : array();
                		$form_submission_fields = array_map('sanitize_text_field', $form_submission_fields);

						$export_data = array();
						$export_data[] = isset($entry_detail['lead_source']) && !empty($entry_detail['lead_source']) ? esc_html($entry_detail['lead_source']) : "";
						foreach($export_field_names as $export_field_name){
							$field_type = isset($form_submission_fields[$export_field_name]) && !empty($form_submission_fields[$export_field_name]) ? $form_submission_fields[$export_field_name] : '';
							if(!empty($field_type)){
								if($field_type == "file"){
									$value = isset($entry_data[$export_field_name]) && !empty($entry_data[$export_field_name]) ? esc_url($entry_data[$export_field_name]) : "";
								}else{
									// Decode HTML entities and cast to string
									$value = isset($entry_data[$export_field_name]) && !empty($entry_data[$export_field_name]) ? esc_html(html_entity_decode($entry_data[$export_field_name])) : "";
									// Escape double quotes for CSV
									$value = !empty($value) ? str_replace('"', '""', $value) : "";
									$export_data[] = $value;
								}
							}
						}
						$export_data[] = isset($entry_detail['submit_date_time']) && !empty($entry_detail['submit_date_time']) ? date("d-m-Y H:i:s", strtotime(esc_html($entry_detail['submit_date_time']))) : "";
						$export_data[] = isset($entry_detail['submit_ip_address']) && !empty($entry_detail['submit_ip_address']) ? esc_html($entry_detail['submit_ip_address']) : "";
						$export_values[] = $export_data;
					}
				}
			}
		}

		return array(
			'header' => $export_header,
			'values' => $export_values
		);
	}

	/**
	 * Generate a CSV file from the provided header and values.
	 *
	 * @since    1.0.0
	 * @param array  $header      Array of CSV column headers.
	 * @param array  $values      2D array of CSV rows, matching the header structure.
	 * @param string $upload_path Absolute filesystem path where the CSV file should be written.
	 * @return array {
	 *     @type string $status  "success" or "fail"
	 *     @type string $message Message describing the result of the file generation.
	 * }
	 *
	*/
	private function cfdb7_generate_csv_file($header, $values, $upload_path){
		$fp = fopen($upload_path, 'w');
		if($fp === false){
			return array(
				'status' => 'fail',
				'message' => esc_html__('Failed to open file for writing.', CFDB7_PRO_TEXT_DOMAIN)
			);
		}

		// Write the header row
		fputcsv($fp, $header);

		// Write each data row
		foreach ($values as $row) {
			fputcsv($fp, $row);
		}

		fclose($fp);

		return array(
			'status' => 'success',
			'message' => esc_html__('Entries exported successfully for batch.', CFDB7_PRO_TEXT_DOMAIN)
		);
	}

	/**
	 * Save export log details to the database.
	 *
	 * @since    1.0.0
	 * @param wpdb   $wpdb        WordPress database instance.
	 * @param object $obj         Instance of Cfdb7_Queries used to perform database operations.
	 * @param int    $cf7_id      Contact Form 7 form ID for which the export was generated.
	 * @param array  $user_info   Array containing user information:
	 *                            - 'user_id'        (int)
	 *                            - 'display_name'   (string)
	 * @param string $upload_path Absolute path of the generated CSV file on the server.
	 * @param string $upload_url  Public URL where the generated CSV file can be accessed.
	 * @return void
	 * 
	*/
	private function cfdb7_save_export_log($wpdb, $obj, $cf7_id, $user_info, $upload_path, $upload_url){
		$export_details = array(
			'form_id' => $cf7_id,
			'export_type' => 'csv',
			'export_file_path' => $upload_path,
			'export_file_url' => $upload_url,
			'export_by' => $user_info['user_id'],
			'export_display_name' => $user_info['display_name'],
			'export_date_time' => current_time("Y-m-d H:i:s"),
			'export_ip_address' => cfdb7_get_ip_address(),
		);
		$export_details_format = array_fill(0, count($export_details), '%s');
		$obj->save_cfdb7_export_log($wpdb, $cf7_id, $export_details, $export_details_format);
	}

	/**
	 * Handles AJAX request to delete CFDB7 entry IDs in batches.
	 * @since    1.0.0
	 * This function:
	 *  - Validates required POST parameters (cf7_id, nonce, current_index, entry_ids)
	 *  - Verifies the nonce for security
	 *  - Retrieves submission and entry details for the given IDs
	 *  - Updates report field counts based on deleted entries
	 *  - Deletes log entries and submissions from the database
	 *  - Returns a JSON response indicating success or failure
	 * POST Parameters:
	 * @param int    $_POST['cf7_id']        The Contact Form 7 ID whose entries are being deleted.
	 * @param string $_POST['nonce']         Nonce for verifying the deletion request.
	 * @param int    $_POST['current_index'] The current batch index during bulk deletion.
	 * @param string $_POST['entry_ids']     Comma-separated list of entry IDs to delete.
	 *
	 * JSON Response:
	 *  - status  string "success" or "fail"
	 *  - message string Human-readable description of the result
	 *
	 * Security:
	 *  - Uses wp_verify_nonce() to validate the request.
	 *  - Sanitizes all user-provided values.
	 * @return void Outputs JSON and terminates execution via wp_die()
	 * 
	*/
	public function cfdb7_delete_entries_delete_ids(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		$current_index = isset($_POST['current_index']) && !empty($_POST['current_index']) ? intval($_POST['current_index']) : "";
		$entry_ids = isset($_POST['entry_ids']) && !empty($_POST['entry_ids']) ? sanitize_text_field($_POST['entry_ids']) : "";
		if(!empty($cf7_id) && !empty($nonce) && !empty($current_index) && !empty($entry_ids)){
			$result = array();
			$index_message = esc_html__( 'index ', CFDB7_PRO_TEXT_DOMAIN )." - {$current_index} - {$entry_ids}";
			if(wp_verify_nonce($nonce, 'cfdb7_deleted_entries_'.$cf7_id)){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();

				$entry_ids = explode(",", $entry_ids);
				$entry_ids = !empty($entry_ids) ? array_map('intval', $entry_ids) : array();
				if(!empty($entry_ids)){
					$entry_details = $obj->get_cfdb7_delete_entry_ids_details($wpdb, $cf7_id, $entry_ids);
					$submission_details = $obj->get_cfdb7_delete_entry_ids_submissions($wpdb, $cf7_id, $entry_ids);
					if(!empty($entry_details) && !empty($submission_details)){
						$field_names = array();
						foreach($submission_details as $submission_detail){
							$field_name = isset($submission_detail['field_name']) && !empty($submission_detail['field_name']) ? sanitize_text_field($submission_detail['field_name']) : "";
							if(!empty($field_name)){
								$field_names[] = $field_name;
							}
						}

						$field_names_count = array_count_values($field_names);

						//Save report field information 
						$field_names = array_map('sanitize_text_field', array_keys($field_names_count));
						foreach($field_names as $field_name){
							$deleted_field_info = $obj->get_cfdb7_delete_report_field_name_options_count($wpdb, $cf7_id, $field_name);
							if(!empty($deleted_field_info)){
								$field_option_info = $obj->get_cfdb7_delete_report_field_name_options($wpdb, $cf7_id, $field_name);
								
								$safe_field_name = sanitize_text_field($deleted_field_info[0]['field_name']);
								$count = intval($deleted_field_info[0]['count']) - intval($field_names_count[$field_name]);

								if(!empty($field_option_info)){
									$obj->update_cfdb7_delete_report_field_name_options($wpdb, $cf7_id, $safe_field_name, $count);
								}else{
									$obj->save_cfdb7_delete_report_field_name_options($wpdb, $cf7_id, $safe_field_name, $count);
								}
							}
						}

						//Delete entries and submissions from deleted entries table
						foreach($entry_ids as $entry_id){
							//Delete entry details
							$obj->delete_cfdb7_entry_delete_log($wpdb, $cf7_id, $entry_id);
							//Delete entry submissions
							$obj->delete_cfdb7_entry_submission_log($wpdb, $cf7_id, $entry_id);
						}

						$result['status'] = "success";
						$result['message'] = esc_html__( 'Entries deleted successfully for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
					}else{
						$result['status'] = "fail";
						$result['message'] = esc_html__( 'No Entries found to delete for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
					}
				}else{
					$result['status'] = "fail";
					$result['message'] = esc_html__( 'No Entries found to delete for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
				}
			}else{
				$result['status'] = "fail";
				$result['message'] = esc_html__( 'Security check failed. Please try again for batch.', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Restores deleted CFDB7 entries and their submission data.
	 *
	 * This AJAX handler performs the following steps:
	 *  - Validates and sanitizes incoming POST parameters.
	 *  - Verifies nonce for security.
	 *  - Retrieves previously deleted entry and submission details.
	 *  - Reinserts restored entries and submission records into main tables.
	 *  - Updates report field counts based on restored field names.
	 *  - Removes restored IDs from deleted-entries tables by calling
	 *    cfdb7_delete_entries_delete_ids() to complete restoration cleanup.
	 *  - Returns a JSON response with status and batch message.
	 *
	 * @since 1.0.0
	 *
	 * @return void Outputs JSON and terminates execution using wp_die().
	 *
	 * POST Parameters:
	 * @param int    $_POST['cf7_id']         The Contact Form 7 form ID whose deleted entries are being restored.
	 * @param string $_POST['nonce']          Nonce used to verify the authenticity of the restore request.
	 * @param int    $_POST['current_index']  Index number used during batch restore operations.
	 * @param string $_POST['entry_ids']      Comma-separated list of entry IDs to restore.
	 *
	 * JSON Response Structure:
	 *  - status  string  "success" | "fail"
	 *  - message string  User-friendly message for the requested batch.
	 *
	 * Security Notes:
	 *  - All user input is sanitized via sanitize_text_field(), intval(), etc.
	 *  - The wp_verify_nonce() check protects against CSRF attacks.
	 *
	 * Behavior:
	 *  - If entries or submissions cannot be found, a failure response is returned.
	 *  - If restoration succeeds, data is inserted back into main tables and
	 *    corresponding deleted logs are removed.
	 * 
	*/
	public function cfdb7_delete_entries_restore_ids(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		$current_index = isset($_POST['current_index']) && !empty($_POST['current_index']) ? intval($_POST['current_index']) : "";
		$entry_ids = isset($_POST['entry_ids']) && !empty($_POST['entry_ids']) ? sanitize_text_field($_POST['entry_ids']) : "";
		if(!empty($cf7_id) && !empty($nonce) && !empty($current_index) && !empty($entry_ids)){
			$result = array();
			$index_message = esc_html__( 'index ', CFDB7_PRO_TEXT_DOMAIN )." - {$current_index} - {$entry_ids}";
			if(wp_verify_nonce($nonce, 'cfdb7_deleted_entries_'.$cf7_id)){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();

				$entry_ids = explode(",", $entry_ids);
				$entry_ids = !empty($entry_ids) ? array_map('intval', $entry_ids) : array();
				if(!empty($entry_ids)){
					$entry_details = $obj->get_cfdb7_delete_entry_ids_details($wpdb, $cf7_id, $entry_ids);
					$submission_details = $obj->get_cfdb7_delete_entry_ids_submissions($wpdb, $cf7_id, $entry_ids);
					if(!empty($entry_details) && !empty($submission_details)){
						foreach($entry_details as $entry_detail){
							$entry_details = array(
								'db7_forms_id' => intval($entry_detail['db7_forms_id']),
								'lead_source' => sanitize_text_field($entry_detail['lead_source']),
								'form_submissions' => $entry_detail['form_submissions'],
								'form_submission_fields' => $entry_detail['form_submission_fields'],
								'submit_by' => intval($entry_detail['submit_by']),
								'submit_display_name' => sanitize_text_field($entry_detail['submit_display_name']),
								'submit_date_time' => sanitize_text_field($entry_detail['submit_date_time']),
								'submit_ip_address' => sanitize_text_field($entry_detail['submit_ip_address']),
							);

							$entry_details_format = array_fill(0, count($entry_details), '%s');

							$entry_id = $obj->save_cfdb7_entry($wpdb, $cf7_id, $entry_details, $entry_details_format);

							$field_data = isset($entry_detail['form_submissions']) && !empty($entry_detail['form_submissions']) ? maybe_unserialize($entry_detail['form_submissions']) : array();

							$cf7_tags = isset($entry_detail['form_submission_fields']) && !empty($entry_detail['form_submission_fields']) ? maybe_unserialize($entry_detail['form_submission_fields']) : array();

							if(!empty($field_data) && !empty($cf7_tags) && !empty($entry_id)){
								foreach($field_data as $field_name => $field_value){
									$field_name = sanitize_text_field($field_name);
									//It is prevent JS injection
									$field_value = sanitize_textarea_field(trim($field_value));

									$entry_submission = array(
										'entry_id' => $entry_id,
										'db7_forms_id' => intval($entry_detail['db7_forms_id']),
										'lead_source' => sanitize_text_field($entry_detail['lead_source']),
										'field_name' => $field_name,
										'field_type' => isset($cf7_tags[$field_name]) && !empty($cf7_tags[$field_name]) ? sanitize_text_field($cf7_tags[$field_name]) : "text",
										'field_value' => $field_value,
									);
									$entry_submission_format = array_fill(0, count($entry_submission), '%s');
									$obj->save_cfdb7_entry_submissions($wpdb, $cf7_id, $entry_submission, $entry_submission_format);
								}
							}
						}

						$field_names = array();
						foreach($submission_details as $submission_detail){
							$field_name = isset($submission_detail['field_name']) && !empty($submission_detail['field_name']) ? sanitize_text_field($submission_detail['field_name']) : "";
							if(!empty($field_name)){
								$field_names[] = $field_name;
							}
						}

						$field_names_count = array_count_values($field_names);

						//Save report field information 
						$field_names = array_map('sanitize_text_field', array_keys($field_names_count));
						foreach($field_names as $field_name){
							$field_info = $obj->get_cfdb7_report_field_name_options_count($wpdb, $cf7_id, $field_name);
							if(!empty($field_info)){
								$field_option_info = $obj->get_cfdb7_report_field_name_options($wpdb, $cf7_id, $field_name);

								$safe_field_name = sanitize_text_field($field_info[0]['field_name']);
								$count = intval($field_info[0]['count']);

								if(!empty($field_option_info)){
									$obj->update_cfdb7_report_field_name_options($wpdb, $cf7_id, $safe_field_name, $count);
								}else{
									$obj->save_cfdb7_report_field_name_options($wpdb, $cf7_id, $safe_field_name, $count);
								}
							}
						}
						
						//Delete proceed ids
						$this->cfdb7_delete_entries_delete_ids();
						
						$result['status'] = "success";
						$result['message'] = esc_html__( 'Entries restored successfully for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
					}else{
						$result['status'] = "fail";
						$result['message'] = esc_html__( 'No Entries found to restore for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
					}
				}else{
					$result['status'] = "fail";
					$result['message'] = esc_html__( 'No Entries found to restore for batch', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
				}
			}else{
				$result['status'] = "fail";
				$result['message'] = esc_html__( 'Security check failed. Please try again for batch.', CFDB7_PRO_TEXT_DOMAIN )." {$index_message}";
			}
			echo json_encode($result);
		}
		wp_die();
	}
}
