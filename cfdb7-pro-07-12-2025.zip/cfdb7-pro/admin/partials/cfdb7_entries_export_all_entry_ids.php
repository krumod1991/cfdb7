<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

$cf7_id = isset($_POST['cf7-id']) && !empty($_POST['cf7-id']) ? intval($_POST['cf7-id']) : "";
$entries_count = isset($_POST['cfdb7_entries_count']) && !empty($_POST['cfdb7_entries_count']) ? intval($_POST['cfdb7_entries_count']) : "";
$nonce = isset($_POST['cfdb7_entries_nonce']) && !empty($_POST['cfdb7_entries_nonce']) ? sanitize_text_field($_POST['cfdb7_entries_nonce']) : "";
$context = isset($_POST['page']) && !empty($_POST['page']) ? sanitize_text_field($_POST['page']) : "";
if(!empty($cf7_id) && !empty($nonce) && !empty($context) && !empty($entries_count)){
    $chunk_size = 100;
    $chunk_size = apply_filters( 'cfdb7_export_entries_chunk_size', $chunk_size );

    $referer = isset($_POST['_wp_http_referer']) ? sanitize_text_field( wp_unslash($_POST['_wp_http_referer']) ) : '';
    $referer_url = home_url( $referer );

    $max_paged = ceil( $entries_count / $chunk_size );
    ?>
    <div class="wrap cfdb7-export-entries">
        <div id="notice"></div>
        <input type="hidden" id="cf7-id" value="<?php echo esc_attr($cf7_id); ?>" />
        <input type="hidden" id="cfdb7_entries_nonce" value="<?php echo esc_attr($nonce); ?>" />
        <input type="hidden" id="context" value="<?php echo esc_attr($context); ?>" />
        <input type="hidden" id="chunk-size" value="<?php echo esc_attr($chunk_size); ?>" />
        <input type="hidden" id="referer_url" value="<?php echo esc_url($referer_url); ?>" />
        <?php 
        for($i=1; $i<=$max_paged; $i++){
            ?>
            <input type="hidden" class="entries-export-all-ids" data-index="<?php echo esc_attr($i); ?>" />
            <?php 
        } 
        ?>
    </div>
    <div id="popup-content" class="mfp-hide">
        <div class="progress-bar-container">
            <div class="progress-bar"></div>
        </div>
    </div>
    <?php
}else{
    $referer = isset($_POST['_wp_http_referer']) ? sanitize_text_field( wp_unslash($_POST['_wp_http_referer']) ) : '';
    $referer_url = home_url( $referer );
    ?>
    <div class="wrap cfdb7-export-entries">
        <div id="notice" class="error notice"><?php echo esc_html__( 'Something went wrong. Please try again.', CFDB7_PRO_TEXT_DOMAIN ); ?>&nbsp;<a href='<?php echo esc_url($referer_url); ?>'><?php echo esc_html__( 'Return to the entries.', CFDB7_PRO_TEXT_DOMAIN ); ?></a></div>
    </div>
    <?php
}
?>