<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

wp_enqueue_style( 'cfdb7_contact_us_style' );
?>
<div class="wrap cfdb7-contact-us">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Contact Us', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
    <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSelANdhHz5Uj8KMjBt3z9iGqrzZABX9X9oRCu3XW5xFJ1uNIQ/viewform"
        width="640" height="800" frameborder="0" marginheight="0" marginwidth="0">
    Loading…
</iframe>
</div>
