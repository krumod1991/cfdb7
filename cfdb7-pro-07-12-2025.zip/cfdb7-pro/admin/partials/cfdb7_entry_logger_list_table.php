<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

wp_enqueue_style('cfdb7_magnific_popup_style');
wp_enqueue_style('jquery-ui-css');
wp_enqueue_style('cfdb7_chosen_style');
wp_enqueue_script('cfdb7_magnific_popup_script');
wp_enqueue_script('jquery-ui-datepicker');
wp_enqueue_script('jquery-ui-sortable');
wp_enqueue_script('cfdb7_chosen_script');

/**
 * Class Custom_WP_List_Table
 *
 * Handles the display and management of deleted entries in the admin area for the Cfdb7 Pro plugin.
 * Extends the WP_List_Table class to provide custom table functionality for Contact Form 7 entries.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
*/
class Custom_WP_List_Table extends WP_List_Table {
    private $wpdb;
    private $obj;
    private $cf7_id;
    private $context;
    private $user_info;
    private $user_id;
    private $admin_page_url;
    private $nonce;
    private $form_settings = array();
    private $field_names = array();
    private $rename_fields = array();
    private $enable_fields = array();
    private $field_order = array();

	/**
     * Constructor for Custom_WP_List_Table.
     * Initializes table properties, settings, and user context.
     */
    public function __construct($obj_data) {
        parent::__construct([
            'singular' => 'item',
            'plural'   => 'items',
            'ajax'     => false
        ]);

        $user_info = $obj_data['user_info'];
        $this->wpdb = $obj_data['wpdb'];
        $this->obj = $obj_data['obj'];
        $this->cf7_id = $obj_data['cf7_id'];
        $this->context = $obj_data['context'];
        $this->user_info = $user_info;
		$this->user_id = $user_info['user_id'];
        $this->admin_page_url = $obj_data['admin_page_url'];
        $this->nonce = $obj_data['nonce'];

        $this->form_settings = $this->obj->get_cfdb7_form_setting($this->wpdb, $this->cf7_id);
        $this->field_names = $this->obj->get_cfdb7_log_report_field_name_options($this->wpdb, $this->cf7_id);

        $display_settings = $this->obj->get_cfdb7_form_display_settings($this->wpdb, $this->cf7_id, $this->user_id, $this->context);

        $this->rename_fields = array();
        $this->enable_fields = array();
        $this->field_order = array();
        if(!empty($display_settings)){
            $saved_settings = isset($display_settings['settings']) && !empty($display_settings['settings']) ? maybe_unserialize($display_settings['settings']) : array();
            
            if(!empty($saved_settings)){
                $this->rename_fields = isset($saved_settings['rename_field']) && !empty($saved_settings['rename_field']) ? array_map('sanitize_text_field', $saved_settings['rename_field']) : array();

                $this->enable_fields = isset($saved_settings['enable_field']) && !empty($saved_settings['enable_field']) ? $saved_settings['enable_field'] : array();

                $this->field_order = isset($saved_settings['field_order']) && !empty($saved_settings['field_order']) ? array_map('sanitize_text_field', $saved_settings['field_order']) : array();
            }
        }
    }

	/**
     * Get the columns for the list table.
     *
     * @return array Columns to display in the table.
     */
    public function get_columns() {
        $columns = array(
            'view_cta' => esc_html__('View', CFDB7_PRO_TEXT_DOMAIN),
            'lead_source' => esc_html__('Lead Source', CFDB7_PRO_TEXT_DOMAIN),
            'db7_forms_id' => esc_html__('CFDB7 Id', CFDB7_PRO_TEXT_DOMAIN),
            'entry_id' => esc_html__('Entry Id', CFDB7_PRO_TEXT_DOMAIN),
            'date_time' => esc_html__('Date Time', CFDB7_PRO_TEXT_DOMAIN),
        );
        
        if(!empty($this->field_names)){
            $rename_fields = !empty($this->rename_fields) ? $this->rename_fields : array();
            $enable_fields = !empty($this->enable_fields) ? $this->enable_fields : array();
            $field_order = !empty($this->field_order) ? $this->field_order : array();

            $exclude_fields = array();
            if(!empty($field_order)){
                foreach ($field_order as $field_name) {
                    if(!empty($enable_fields)){
                        if(isset($enable_fields[$field_name])){
                            $columns[$field_name] = isset($rename_fields[$field_name]) && !empty($rename_fields[$field_name]) ? esc_html($rename_fields[$field_name]) : esc_html($field_name);
                        }
                    }else{
                        $columns[$field_name] = isset($rename_fields[$field_name]) && !empty($rename_fields[$field_name]) ? esc_html($rename_fields[$field_name]) : esc_html($field_name);
                    }
                    $exclude_fields[] = esc_html($field_name);
                }
            }

            $current_fields = wp_list_pluck($this->field_names, 'field_name');
            if(!empty($current_fields)){
                $current_fields = array_map('sanitize_text_field', $current_fields);
                foreach($current_fields as $proceed_field_name){
                    if(!in_array($proceed_field_name, $exclude_fields)){
                        if(!empty($enable_fields)){
                            if(isset($enable_fields[$proceed_field_name])){
                                $columns[$proceed_field_name] = isset($rename_fields[$proceed_field_name]) && !empty($rename_fields[$proceed_field_name]) ? esc_html($rename_fields[$proceed_field_name]) : esc_html($proceed_field_name);
                            }
                        }else{
                            $columns[$proceed_field_name] = isset($rename_fields[$proceed_field_name]) && !empty($rename_fields[$proceed_field_name]) ? esc_html($rename_fields[$proceed_field_name]) : esc_html($proceed_field_name);
                        }   
                    }
                }
            }
        }

        
        return $columns;
    }

	/**
     * Default column rendering for the list table.
     *
     * @param array $item The current item.
     * @param string $column_name The name of the column.
     * @return string Column output.
     */
    public function column_default($item, $column_name) {
        if(isset($item[$column_name])){
            switch ($column_name) {
                case 'lead_source':
                case 'db7_forms_id':
                case 'entry_id':
                    return esc_html($item[$column_name]);
                case 'date_time':
                    return date("d-m-Y H:i:s", strtotime(esc_html($item[$column_name])));
                default:
                    return esc_html($item[$column_name]);
            }
        }else{
            switch ($column_name){
                case 'view_cta':
                    return $this->get_view_cta($item['id']);
                default:
                    return "no value";
            }
        }
    }

	/**
     * Display message when no items are found.
     *
     * @return void
     */
    public function no_items() {
        echo esc_html__( 'No enquiries found.', CFDB7_PRO_TEXT_DOMAIN );
    }

	/**
     * Output the View button for a row.
     *
     * @param int $id Entry ID.
     * @return void
     */
    private function get_view_cta($id) {
        echo '<input type="button" class="button view-logger-cta" data-index="' . esc_attr($id) . '" data-cf7_id="' . esc_attr($this->cf7_id) . '" value="' . esc_html__('View', CFDB7_PRO_TEXT_DOMAIN) . '">';
    }

	/**
     * Prepare the items for the list table (pagination, filtering, etc).
     *
     * @return void
     */
    public function prepare_items() {
        $enquiries_per_page = 10;
        $character_limit = 30;
        if(!empty( $this->form_settings)){
            $form_settings = isset($this->form_settings['settings']) && !empty($this->form_settings['settings']) ? maybe_unserialize($this->form_settings['settings']) : array();
            $form_settings = !empty($form_settings) ? array_map('sanitize_text_field', $form_settings) : array();

            $enquiries_per_page = isset($form_settings['enquiries_per_page']) && !empty($form_settings['enquiries_per_page']) ? intval($form_settings['enquiries_per_page']) : 10;

            $character_limit = isset($form_settings['character_limit']) && !empty($form_settings['character_limit']) ? intval($form_settings['character_limit']) : 30;
        }

        $per_page = $enquiries_per_page;
        $current_page = $this->get_pagenum();

        $from_date = !empty($_GET['from_date']) && !empty($_GET['from_date']) ? sanitize_text_field($_GET['from_date']) : '';
        $to_date   = !empty($_GET['to_date']) && !empty($_GET['to_date']) ? sanitize_text_field($_GET['to_date'])   : '';
        $field_names = isset($_GET['field_names']) && !empty($_GET['field_names']) ? $_GET['field_names'] : array();
		$field_names = array_map( 'sanitize_text_field', $field_names );
        
		$search_value = isset($_GET['s']) && !empty($_GET['s']) ? sanitize_text_field(trim($_GET['s'])) : "";

        if (!empty($from_date) && !empty($to_date) && strtotime($from_date) > strtotime($to_date)) {
            add_settings_error('date_filter_error', 'invalid_date_range', esc_html__('Invalid date range: From Date is later than To Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        } else if (!empty($from_date) && empty($to_date)) {
            add_settings_error('date_filter_error', 'missing_to_date', esc_html__('Kindly select To Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        } else if (empty($from_date) && !empty($to_date)) {
            add_settings_error('date_filter_error', 'missing_from_date', esc_html__('Kindly select From Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        }

        $search_input = array();
        if(!empty($from_date) || !empty($to_date) || !empty($field_names) || !empty($search_value)){
            $search_input = array(
                'from_date' => $from_date,
                'to_date'   => $to_date,
                'field_names' => $field_names,
                's' => $search_value,
            );
        }
        $all_data = $this->get_data($search_input);
        
        $total_items = count($all_data);

        // Pagination
        $paged_data_before = array_slice($all_data, ($current_page - 1) * $per_page, $per_page);
        
        $paged_data_after = array();
        if(!empty($paged_data_before)){
            foreach($paged_data_before as $data){
                $entry_data = isset($data['original_entry']) && !empty($data['original_entry']) ? maybe_unserialize($data['original_entry']) : array();
                $entry_data = array_map('sanitize_text_field', $entry_data);

                $original_entry_fields = isset($data['original_entry_fields']) && !empty($data['original_entry_fields']) ? maybe_unserialize($data['original_entry_fields']) : array();
                $original_entry_fields = array_map('sanitize_text_field', $original_entry_fields);

                $row = array(
                    'lead_source' => esc_html($data['lead_source']),
                    'db7_forms_id' => intval($data['db7_forms_id']),
                    'entry_id' => intval($data['entry_id']),
                    'date_time' => date('d-m-Y H:i:s', strtotime(esc_html($data['date_time']))),
                );

                if(!empty($this->field_names)){
                    $current_fields = wp_list_pluck($this->field_names, 'field_name');
                    if(!empty($current_fields)){
                        $current_fields = array_map('sanitize_text_field', $current_fields);

                        foreach($current_fields as $field_key){
                            //Get field type of form fields
                            $field_type = isset($original_entry_fields[$field_key]) && !empty($original_entry_fields[$field_key]) ? $original_entry_fields[$field_key] : '';
                            if(!empty($field_type)){
                                if($field_type == "file"){
                                    $field_value = isset($entry_data[$field_key]) && !empty($entry_data[$field_key]) ? esc_url($entry_data[$field_key]) : '';
                                    if(filter_var($field_value, FILTER_VALIDATE_URL) !== false){
                                        $row[$field_key] = '<a href="'.esc_url($field_value).'" target="_blank" title="'.esc_url($field_value).'" download>'.esc_html(basename($field_value)).'</a>';
                                    }
                                }else{
                                    $field_value = isset($entry_data[$field_key]) && !empty($entry_data[$field_key]) ? esc_html(html_entity_decode($entry_data[$field_key])) : '';
                                    if(strlen($field_value) > $character_limit){
                                        $row[$field_key] = esc_html(substr($field_value, 0, $character_limit)).'...';
                                    }else{
                                        $row[$field_key] = esc_html($field_value);
                                    }
                                }
                            }
                        }
                    }
                }
                $row['id'] = esc_html($data['id']);
                $paged_data_after[] = $row;
            }
        }

        $this->items = $paged_data_after;

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ]);

        $this->_column_headers = [$this->get_columns(), [], []];
    }

	/**
     * Retrieve the data for the list table.
     *
     * @param array $search_input Search/filter parameters.
     * @return array Data for the table.
     */
    public function get_data($search_input = array()) {
        $data = $this->obj->get_cfdb7_log_entries($this->wpdb, $this->cf7_id, $search_input);
        return $data;
    }

	/**
     * Display the display settings filter UI.
     *
     * @return void
     */
    public function get_display_setting(){
        $filter_type = 'display_settings';
        include CFDB7_PRO_PLUGIN_DIR . 'admin/partials/cfdb7_list_table_forms.php';
    }

	/**
     * Display the date filters UI.
     *
     * @return void
     */
    public function get_date_filters() {
        $filter_type = "date_filter";
        include CFDB7_PRO_PLUGIN_DIR . 'admin/partials/cfdb7_list_table_forms.php';
    }

	/**
     * Display the search filter UI.
     *
     * @return void
     */
    public function get_search_filter(){
        $filter_type = "search_filter";
        include CFDB7_PRO_PLUGIN_DIR . 'admin/partials/cfdb7_list_table_forms.php';
    }
}

$obj_data = array(
    'wpdb' => $wpdb,
    'obj' => $obj,
    'cf7_id' => $cf7_id,
    'context' => $context,
    'user_info' => $user_info,
    'admin_page_url' => $admin_page_url,
    'nonce' => $nonce,
);
$table = new Custom_WP_List_Table($obj_data);
$table->prepare_items();
?>
<h3><?php echo esc_html__('Log Submissions', CFDB7_PRO_TEXT_DOMAIN); ?></h3>
<div class="loader" style="display:none;"></div>
<div id="cfdb7-entries-ctas-container">
    <button class="display-settings" class="button"><?php echo esc_html__('Display Settings', CFDB7_PRO_TEXT_DOMAIN); ?></button>
    <button class="reset-settings" class="button"><?php echo esc_html__('Reset All', CFDB7_PRO_TEXT_DOMAIN); ?></button>
</div>
<div id="display-settings-container" style="display: none;">
    <?php $table->get_display_setting(); ?>
</div>
<div id="date-filter-container">
    <?php $table->get_date_filters(); ?>
</div>
<div id="search-filter-container">
    <?php $table->get_search_filter(); ?>
</div>
<div id="wp-list-table-container">
    <?php $table->display(); ?>
</div>
<div id="popup-content" class="mfp-hide">
    <div class="logger-information-container">
    </div>
</div>