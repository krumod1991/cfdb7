jQuery(document).ready(function () {
    function cfdb7_open_popup() {
        jQuery.magnificPopup.open({
            items: {
                src: '#popup-content'
            },
            type: 'inline',
            closeOnBgClick: false,
            enableEscapeKey: false,
            callbacks: {
                open: function () {
                    var bar = jQuery('.progress-bar');
                    bar.animate({ width: '0%' }, 5000, 'linear');
                },
                close: function () {
                    jQuery('.progress-bar').stop(true).css('width', '0%');
                }
            }
        });
    }

    if (jQuery(".entries-delete-entry-ids").length > 0) {
        var max_paged = jQuery(".entries-delete-entry-ids").length;
        var proceed_paged = 1;
        setTimeout(function () {
            var cf7_id = jQuery("#cf7-id").val();
            var nonce = jQuery("#cfdb7_entries_nonce").val();
            var current_index = jQuery(".entries-delete-entry-ids").eq(0).data('index');
            var entry_ids = jQuery(".entries-delete-entry-ids").eq(0).val();

            cfdb7_open_popup();
            cfdb7_entries_trigger_delete_ids(cf7_id, nonce, current_index, entry_ids);
        }, 1000);

        function cfdb7_entries_trigger_delete_ids(cf7_id, nonce, current_index, entry_ids) {
            var referer_url = jQuery("#referer_url").val();

            jQuery.ajax({
                url: cfdb7_params.ajax_url,
                data: {
                    'action': 'cfdb7_entries_delete_entry_ids',
                    'cf7_id': cf7_id,
                    'nonce': nonce,
                    'current_index': current_index,
                    'entry_ids': entry_ids,
                },
                type: 'POST',
                success: function (data) {
                    var result = JSON.parse(data);
                    if (result.status == 'success') {
                        jQuery("#notice").append("<div class='notice notice-success'>" + result.message + "</div>");
                    } else {
                        jQuery("#notice").append("<div class='notice notice-error'>" + result.message + "</div>");
                    }
                    proceed_paged = parseInt(proceed_paged);
                    max_paged = parseInt(max_paged);
                    var proceed_ratio = (proceed_paged / max_paged) * 100;
                    console.log(proceed_paged + "::" + max_paged + "::" + proceed_ratio);
                    proceed_paged++;
                    setTimeout(function () {
                        var bar = jQuery('.progress-bar');
                        bar.css('width', proceed_ratio + '%')
                    }, 100);
                    jQuery(".entries-delete-entry-ids").eq(0).remove();

                    if (proceed_paged == max_paged) {
                        setTimeout(function () {
                            jQuery("#notice").append("<div class='notice notice-info'><a href='" + referer_url + "'>" + cfdb7_params.return_to_entries + "</a></div>");
                            jQuery('.notice').css('display', 'block');
                            jQuery.magnificPopup.close();
                        }, 1000);
                    } else if (max_paged == 1) {
                        setTimeout(function () {
                            jQuery("#notice").append("<div class='notice notice-info'><a href='" + referer_url + "'>" + cfdb7_params.return_to_entries + "</a></div>");
                            jQuery('.notice').css('display', 'block');
                            jQuery.magnificPopup.close();
                        }, 1000);
                    }
                },
                complete: function () {
                    setTimeout(function () {
                        if (jQuery(".entries-delete-entry-ids").length > 0) {
                            var current_index = jQuery(".entries-delete-entry-ids").eq(0).data('index');
                            var entry_ids = jQuery(".entries-delete-entry-ids").eq(0).val();
                            cfdb7_entries_trigger_delete_ids(cf7_id, nonce, current_index, entry_ids);
                        } else {
                            jQuery.magnificPopup.close();
                        }
                    }, 500);
                },
                fail: function () {
                    jQuery.magnificPopup.close();
                }
            });
        }
    }

    if (jQuery(".entries-export-entry-ids").length > 0) {
        var max_paged = jQuery(".entries-export-entry-ids").length;
        var proceed_paged = 1;
        setTimeout(function () {
            var cf7_id = jQuery("#cf7-id").val();
            var nonce = jQuery("#cfdb7_entries_nonce").val();
            var current_index = jQuery(".entries-export-entry-ids").eq(0).data('index');
            var entry_ids = jQuery(".entries-export-entry-ids").eq(0).val();
            var context = jQuery("#context").val();

            cfdb7_open_popup();
            cfdb7_entries_trigger_export_ids(cf7_id, nonce, current_index, entry_ids, context);
        }, 1000);

        function cfdb7_entries_trigger_export_ids(cf7_id, nonce, current_index, entry_ids, context) {
            var referer_url = jQuery("#referer_url").val();

            jQuery.ajax({
                url: cfdb7_params.ajax_url,
                data: {
                    'action': 'cfdb7_entries_export_entry_ids',
                    'cf7_id': cf7_id,
                    'nonce': nonce,
                    'current_index': current_index,
                    'entry_ids': entry_ids,
                    'context': context,
                },
                type: 'POST',
                success: function (data) {
                    var result = JSON.parse(data);
                    if (result.status == 'success') {
                        jQuery("#notice").append("<div class='notice notice-success'>" + result.message + "</div>");
                    } else {
                        jQuery("#notice").append("<div class='notice notice-error'>" + result.message + "</div>");
                    }
                    proceed_paged = parseInt(proceed_paged);
                    max_paged = parseInt(max_paged);
                    var proceed_ratio = (proceed_paged / max_paged) * 100;
                    console.log(proceed_paged + "::" + max_paged + "::" + proceed_ratio);
                    proceed_paged++;
                    setTimeout(function () {
                        var bar = jQuery('.progress-bar');
                        bar.css('width', proceed_ratio + '%')
                    }, 100);
                    jQuery(".entries-export-entry-ids").eq(0).remove();

                    if (proceed_paged == max_paged) {
                        setTimeout(function () {
                            jQuery("#notice").append("<div class='notice notice-info'><a href='" + referer_url + "'>" + cfdb7_params.return_to_entries + "</a></div>");
                            jQuery('.notice').css('display', 'block');
                            jQuery.magnificPopup.close();
                        }, 1000);
                    } else if (max_paged == 1) {
                        setTimeout(function () {
                            jQuery("#notice").append("<div class='notice notice-info'><a href='" + referer_url + "'>" + cfdb7_params.return_to_entries + "</a></div>");
                            jQuery('.notice').css('display', 'block');
                            jQuery.magnificPopup.close();
                        }, 1000);
                    }
                },
                complete: function () {
                    setTimeout(function () {
                        if (jQuery(".entries-export-entry-ids").length > 0) {
                            var current_index = jQuery(".entries-export-entry-ids").eq(0).data('index');
                            var entry_ids = jQuery(".entries-export-entry-ids").eq(0).val();
                            cfdb7_entries_trigger_export_ids(cf7_id, nonce, current_index, entry_ids, context);
                        } else {
                            jQuery.magnificPopup.close();
                        }
                    }, 500);
                },
                fail: function () {
                    jQuery.magnificPopup.close();
                }
            });
        }
    }

    if (jQuery(".entries-export-all-ids").length > 0) {
        var max_paged = jQuery(".entries-export-all-ids").length;
        var proceed_paged = 1;
        setTimeout(function () {
            var cf7_id = jQuery("#cf7-id").val();
            var nonce = jQuery("#cfdb7_entries_nonce").val();
            var current_index = jQuery(".entries-export-all-ids").eq(0).data('index');
            var context = jQuery("#context").val();
            var chunk_size = jQuery("#chunk-size").val();

            cfdb7_open_popup();
            cfdb7_entries_trigger_export_all(cf7_id, nonce, current_index, context, chunk_size);
        }, 1000);

        function cfdb7_entries_trigger_export_all(cf7_id, nonce, current_index, context, chunk_size) {
            var referer_url = jQuery("#referer_url").val();

            jQuery.ajax({
                url: cfdb7_params.ajax_url,
                data: {
                    'action': 'cfdb7_entries_export_all_entry_ids',
                    'cf7_id': cf7_id,
                    'nonce': nonce,
                    'current_index': current_index,
                    'context': context,
                    'chunk_size': chunk_size,
                },
                type: 'POST',
                success: function (data) {
                    var result = JSON.parse(data);
                    if (result.status == 'success') {
                        jQuery("#notice").append("<div class='notice notice-success'>" + result.message + "</div>");
                    } else {
                        jQuery("#notice").append("<div class='notice notice-error'>" + result.message + "</div>");
                    }
                    proceed_paged = parseInt(proceed_paged);
                    max_paged = parseInt(max_paged);
                    var proceed_ratio = (proceed_paged / max_paged) * 100;
                    console.log(proceed_paged + "::" + max_paged + "::" + proceed_ratio);
                    proceed_paged++;
                    setTimeout(function () {
                        var bar = jQuery('.progress-bar');
                        bar.css('width', proceed_ratio + '%')
                    }, 100);
                    jQuery(".entries-export-all-ids").eq(0).remove();

                    if (proceed_paged == max_paged) {
                        setTimeout(function () {
                            jQuery("#notice").append("<div class='notice notice-info'><a href='" + referer_url + "'>" + cfdb7_params.return_to_entries + "</a></div>");
                            jQuery('.notice').css('display', 'block');
                            jQuery.magnificPopup.close();
                        }, 1000);
                    } else if (max_paged == 1) {
                        setTimeout(function () {
                            jQuery("#notice").append("<div class='notice notice-info'><a href='" + referer_url + "'>" + cfdb7_params.return_to_entries + "</a></div>");
                            jQuery('.notice').css('display', 'block');
                            jQuery.magnificPopup.close();
                        }, 1000);
                    }
                },
                complete: function () {
                    setTimeout(function () {
                        if (jQuery(".entries-export-all-ids").length > 0) {
                            var current_index = jQuery(".entries-export-all-ids").eq(0).data('index');
                            cfdb7_entries_trigger_export_all(cf7_id, nonce, current_index, context, chunk_size);
                        } else {
                            jQuery.magnificPopup.close();
                        }
                    }, 500);
                },
                fail: function () {
                    jQuery.magnificPopup.close();
                }
            });
        }
    }

    if (jQuery(".entries-deleted-entries-delete-ids").length > 0) {
        var max_paged = jQuery(".entries-deleted-entries-delete-ids").length;
        var proceed_paged = 1;
        setTimeout(function () {
            var cf7_id = jQuery("#cf7-id").val();
            var nonce = jQuery("#cfdb7_deleted_entries_nonce").val();
            var current_index = jQuery(".entries-deleted-entries-delete-ids").eq(0).data('index');
            var entry_ids = jQuery(".entries-deleted-entries-delete-ids").eq(0).val();

            cfdb7_open_popup();
            cfdb7_delete_entries_trigger_delete_ids(cf7_id, nonce, current_index, entry_ids);
        }, 1000);

        function cfdb7_delete_entries_trigger_delete_ids(cf7_id, nonce, current_index, entry_ids) {
            var referer_url = jQuery("#referer_url").val();

            jQuery.ajax({
                url: cfdb7_params.ajax_url,
                data: {
                    'action': 'cfdb7_delete_entries_delete_ids',
                    'cf7_id': cf7_id,
                    'nonce': nonce,
                    'current_index': current_index,
                    'entry_ids': entry_ids,
                },
                type: 'POST',
                success: function (data) {
                    var result = JSON.parse(data);
                    if (result.status == 'success') {
                        jQuery("#notice").append("<div class='notice notice-success'>" + result.message + "</div>");
                    } else {
                        jQuery("#notice").append("<div class='notice notice-error'>" + result.message + "</div>");
                    }
                    proceed_paged = parseInt(proceed_paged);
                    max_paged = parseInt(max_paged);
                    var proceed_ratio = (proceed_paged / max_paged) * 100;
                    console.log(proceed_paged + "::" + max_paged + "::" + proceed_ratio);
                    proceed_paged++;
                    setTimeout(function () {
                        var bar = jQuery('.progress-bar');
                        bar.css('width', proceed_ratio + '%')
                    }, 100);
                    jQuery(".entries-deleted-entries-delete-ids").eq(0).remove();

                    if (proceed_paged == max_paged) {
                        setTimeout(function () {
                            jQuery("#notice").append("<div class='notice notice-info'><a href='" + referer_url + "'>" + cfdb7_params.return_to_entries + "</a></div>");
                            jQuery('.notice').css('display', 'block');
                            jQuery.magnificPopup.close();
                        }, 1000);
                    } else if (max_paged == 1) {
                        setTimeout(function () {
                            jQuery("#notice").append("<div class='notice notice-info'><a href='" + referer_url + "'>" + cfdb7_params.return_to_entries + "</a></div>");
                            jQuery('.notice').css('display', 'block');
                            jQuery.magnificPopup.close();
                        }, 1000);
                    }
                },
                complete: function () {
                    setTimeout(function () {
                        if (jQuery(".entries-deleted-entries-delete-ids").length > 0) {
                            var current_index = jQuery(".entries-deleted-entries-delete-ids").eq(0).data('index');
                            var entry_ids = jQuery(".entries-deleted-entries-delete-ids").eq(0).val();
                            cfdb7_delete_entries_trigger_delete_ids(cf7_id, nonce, current_index, entry_ids);
                        } else {
                            jQuery.magnificPopup.close();
                        }
                    }, 500);
                },
                fail: function () {
                    jQuery.magnificPopup.close();
                }
            });
        }
    }

    if (jQuery(".entries-deleted-entries-restore-ids").length > 0) {
        var max_paged = jQuery(".entries-deleted-entries-restore-ids").length;
        var proceed_paged = 1;
        setTimeout(function () {
            var cf7_id = jQuery("#cf7-id").val();
            var nonce = jQuery("#cfdb7_deleted_entries_nonce").val();
            var current_index = jQuery(".entries-deleted-entries-restore-ids").eq(0).data('index');
            var entry_ids = jQuery(".entries-deleted-entries-restore-ids").eq(0).val();

            cfdb7_open_popup();
            cfdb7_delete_entries_trigger_restore_ids(cf7_id, nonce, current_index, entry_ids);
        }, 1000);

        function cfdb7_delete_entries_trigger_restore_ids(cf7_id, nonce, current_index, entry_ids) {
            var referer_url = jQuery("#referer_url").val();

            jQuery.ajax({
                url: cfdb7_params.ajax_url,
                data: {
                    'action': 'cfdb7_delete_entries_restore_ids',
                    'cf7_id': cf7_id,
                    'nonce': nonce,
                    'current_index': current_index,
                    'entry_ids': entry_ids,
                },
                type: 'POST',
                success: function (data) {
                    var result = JSON.parse(data);
                    if (result.status == 'success') {
                        jQuery("#notice").append("<div class='notice notice-success'>" + result.message + "</div>");
                    } else {
                        jQuery("#notice").append("<div class='notice notice-error'>" + result.message + "</div>");
                    }
                    proceed_paged = parseInt(proceed_paged);
                    max_paged = parseInt(max_paged);
                    var proceed_ratio = (proceed_paged / max_paged) * 100;
                    console.log(proceed_paged + "::" + max_paged + "::" + proceed_ratio);
                    proceed_paged++;
                    setTimeout(function () {
                        var bar = jQuery('.progress-bar');
                        bar.css('width', proceed_ratio + '%')
                    }, 100);
                    jQuery(".entries-deleted-entries-restore-ids").eq(0).remove();

                    if (proceed_paged == max_paged) {
                        setTimeout(function () {
                            jQuery("#notice").append("<div class='notice notice-info'><a href='" + referer_url + "'>" + cfdb7_params.return_to_entries + "</a></div>");
                            jQuery('.notice').css('display', 'block');
                            jQuery.magnificPopup.close();
                        }, 1000);
                    } else if (max_paged == 1) {
                        setTimeout(function () {
                            jQuery("#notice").append("<div class='notice notice-info'><a href='" + referer_url + "'>" + cfdb7_params.return_to_entries + "</a></div>");
                            jQuery('.notice').css('display', 'block');
                            jQuery.magnificPopup.close();
                        }, 1000);
                    }
                },
                complete: function () {
                    setTimeout(function () {
                        if (jQuery(".entries-deleted-entries-restore-ids").length > 0) {
                            var current_index = jQuery(".entries-deleted-entries-restore-ids").eq(0).data('index');
                            var entry_ids = jQuery(".entries-deleted-entries-restore-ids").eq(0).val();
                            cfdb7_delete_entries_trigger_restore_ids(cf7_id, nonce, current_index, entry_ids);
                        } else {
                            jQuery.magnificPopup.close();
                        }
                    }, 500);
                },
                fail: function () {
                    jQuery.magnificPopup.close();
                }
            });
        }
    }
});