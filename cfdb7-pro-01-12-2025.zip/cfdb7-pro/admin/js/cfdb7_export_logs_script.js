jQuery(document).ready(function () {
    jQuery("#cf7-id").change(function () {
        var cf7_id = jQuery(this).val();
        var nonce = jQuery("#entries_logger_page_nonce").val();
        var current_url = new URL(window.location.href);
        current_url.searchParams.delete('cf7-id');
        if (cf7_id != "") {
            window.location = current_url + '&cf7-id=' + cf7_id + '&nonce=' + nonce;
        } else {
            window.location = current_url;
        }
    });

    if (jQuery('#from_date').length > 0 && jQuery('#to_date').length > 0) {
        jQuery('#from_date, #to_date').datepicker({
            dateFormat: 'dd-mm-yy'
        });
    }
});