<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

$context = isset($_POST['page']) && !empty($_POST['page']) ? sanitize_text_field($_POST['page']) : "";
$cf7_id = isset($_POST['cf7-id']) && !empty($_POST['cf7-id']) ? intval($_POST['cf7-id']) : "";
$nonce = isset($_POST['cfdb7_entries_nonce']) && !empty($_POST['cfdb7_entries_nonce']) ? sanitize_text_field($_POST['cfdb7_entries_nonce']) : "";
$entry_ids = isset($_POST['ids']) && !empty($_POST['ids']) ? array_map('intval', $_POST['ids']) : array();
if(!empty($context) && !empty($cf7_id) && !empty($nonce) && !empty($entry_ids)){
    $chunk_size = 10;
    $chunk_size = apply_filters( 'cfdb7_export_entries_chunk_size', $chunk_size );
    //Split entry ids into chunks
    $chunk_ids = array_chunk($entry_ids, $chunk_size);
    ?>
    <div class="wrap cfdb7-export-entries">
        <div id="notice"></div>
        <input type="hidden" id="cf7-id" value="<?php echo esc_attr($cf7_id); ?>" />
        <input type="hidden" id="cfdb7_entries_nonce" value="<?php echo esc_attr($nonce); ?>" />
        <input type="hidden" id="context" value="<?php echo esc_attr($context); ?>" />
        <?php 
        foreach($chunk_ids as $key => $ids){ 
            ?>
            <input type="hidden" class="entries-export-entry-ids" data-index="<?php echo esc_attr($key + 1); ?>" value="<?php echo esc_attr(implode(",", $ids)); ?>" />
            <?php 
        } 
        ?>
    </div>
    <div id="popup-content" class="mfp-hide">
        <div class="progress-bar-container">
            <div class="progress-bar"></div>
        </div>
    </div>
    <?php
}
?>