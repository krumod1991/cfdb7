<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}



$cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? intval($_GET['cf7-id']) : "";
$nonce = isset($_GET['nonce']) && !empty($_GET['nonce']) ? sanitize_text_field($_GET['nonce']) : "";
$context = isset($_GET['page']) && !empty($_GET['page']) ? sanitize_text_field($_GET['page']) : "";
$url_args = array('page' => $context);
if(!empty($cf7_id) && !empty($nonce)){
    $url_args['cf7-id'] = $cf7_id;
    $url_args['nonce'] = $nonce;
}
// Add search/filter params if present
if (isset($_GET['from_date']) && !empty($_GET['from_date'])) {
    $url_args['from_date'] = sanitize_text_field($_GET['from_date']);
}
if (isset($_GET['to_date']) && !empty($_GET['to_date'])) {
    $url_args['to_date'] = sanitize_text_field($_GET['to_date']);
}
if (isset($_GET['field_names']) && !empty($_GET['field_names'])) {
    $url_args['field_names'] = array_map('sanitize_text_field', (array)$_GET['field_names']);
}
if (isset($_GET['s']) && !empty($_GET['s'])) {
    $url_args['s'] = sanitize_text_field($_GET['s']);
}

$admin_page_url = add_query_arg( $url_args, admin_url( 'admin.php' ) );

global $wpdb;
$obj = new Cfdb7_Queries();
$obj->init_cfdb7_tables();

//Save display settings
if(isset($_POST['display-settings'])){
    do_action('cfdb7_save_display_user_settings', $_POST, $wpdb, $obj);
}

$user_info = cfdb7_get_logged_in_user_info();
$capabilities = $user_info['capabilities'];

$allowed_form_ids = array();
if(!empty($forms_list)){
	foreach($forms_list as $form){
		if(in_array("cfdb7_form_view_entry_".$form->ID, $capabilities) || in_array("cfdb7_form_delete_entry_".$form->ID, $capabilities) || in_array("manage_options", $capabilities)){
			$entries_count = $obj->get_cfdb7_form_entries_count($wpdb, $form->ID);
			if(!empty($entries_count)){
				if($entries_count['count'] > 0){
					$allowed_form_ids[] = $form;
				}
			}			
		}
	}
}
?>
<h1 class="wp-heading-inline"><?php echo esc_html__('Entries', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
<form id="cfdb7-ids" method="post" id="import_data" action="<?php echo esc_url($admin_page_url); ?>" novalidate="novalidate" enctype="multipart/form-data">
	<table class="form-table">
		<tr class="form-field">
			<th><label for="cf7-id"><?php echo esc_html__('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></label></th>
			<td>
				<select name="cf7-id" id="cf7-id">
					<option value=""><?php echo esc_html__('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></option>
					<?php 
					if(!empty($allowed_form_ids)){
						foreach($allowed_form_ids as $form){							
							if(in_array("cfdb7_form_view_entry_".$form->ID, $capabilities) || in_array("cfdb7_form_delete_entry_".$form->ID, $capabilities) || in_array("manage_options", $capabilities)){
								?><option value="<?php echo esc_attr($form->ID); ?>" <?php selected($cf7_id, $form->ID); ?>><?php echo esc_html($form->post_title); ?></option><?php
							}
						}
					}
					?>
				</select>
				<?php wp_nonce_field('entries_page', 'entries_page_nonce'); ?>
			</td>
		</tr>
	</table>
</form>
<?php 
if(!empty($cf7_id) && !empty($nonce)){
	if(wp_verify_nonce($nonce, 'entries_page')){
		$view_capability = "";
		$delete_capability = "";
		if(in_array("cfdb7_form_view_entry_".$cf7_id, $capabilities) || in_array("manage_options", $capabilities) ){
			$view_capability = "exist";
		}

		if(in_array("cfdb7_form_delete_entry_".$cf7_id, $capabilities) || in_array("manage_options", $capabilities)){
			$view_capability = "exist";
			$delete_capability = "exist";
		}
		
		if($view_capability == "exist"){
			include_once plugin_dir_path( __DIR__ ).'partials/cfdb7_entries_list_table.php';
		}
	}else{
		?>
		<div class="notice notice-error is-dismissible"><p><?php echo esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
		<?php
	}
}
?>