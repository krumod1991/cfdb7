<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

$cf7_id = isset($_POST['cf7-id']) && !empty($_POST['cf7-id']) ? intval($_POST['cf7-id']) : "";
$nonce = isset($_POST['cfdb7_entries_nonce']) && !empty($_POST['cfdb7_entries_nonce']) ? sanitize_text_field($_POST['cfdb7_entries_nonce']) : "";
$entry_ids = isset($_POST['ids']) && !empty($_POST['ids']) ? array_map('intval', $_POST['ids']) : array();
if(!empty($cf7_id) && !empty($nonce) && !empty($entry_ids)){
    $is_proceed_delete = false;
    if(wp_verify_nonce( $nonce, 'cfdb7_entries_'.$cf7_id )){
        $user_info = cfdb7_get_logged_in_user_info();
        // Check if user has delete permission
        $has_permission = false;
        if (!empty($user_info['capabilities']) && is_array($user_info['capabilities'])) {
            $capabilities = $user_info['capabilities'];
            if(in_array("cfdb7_form_delete_entry_".$cf7_id, $capabilities) || in_array("manage_options", $capabilities)){
                $has_permission = true;
            }
        }

        if ($has_permission == true) {
            $is_proceed_delete = true;
        }else{
            wp_die(esc_html__('You do not have permission to delete entries.', CFDB7_PRO_TEXT_DOMAIN));
        }
    }else{
        wp_die(esc_html__('Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN));
    }

    if($is_proceed_delete == true){
        $chunk_size = 10;
        $chunk_size = apply_filters( 'cfdb7_delete_entries_chunk_size', $chunk_size );
        //Split entry ids into chunks
        $chunk_ids = array_chunk($entry_ids, $chunk_size);

        $referer = isset($_POST['_wp_http_referer']) ? sanitize_text_field( wp_unslash($_POST['_wp_http_referer']) ) : '';
        $referer_url = home_url( $referer );
        ?>
        <div class="wrap cfdb7-delete-entries">
            <div id="notice"></div>
            <input type="hidden" id="cf7-id" value="<?php echo esc_attr($cf7_id); ?>" />
            <input type="hidden" id="cfdb7_entries_nonce" value="<?php echo esc_attr($nonce); ?>" />
            <input type="hidden" id="referer_url" value="<?php echo esc_url($referer_url); ?>" />
            <?php 
            foreach($chunk_ids as $key => $ids){ 
                ?>
                <input type="hidden" class="entries-delete-entry-ids" data-index="<?php echo esc_attr($key + 1); ?>" value="<?php echo esc_attr(implode(",", $ids)); ?>" />
                <?php 
            } 
            ?>
        </div>
        <div id="popup-content" class="mfp-hide">
            <div class="progress-bar-container">
                <div class="progress-bar"></div>
            </div>
        </div>
        <?php
    }
}
?>