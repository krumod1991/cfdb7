<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

$cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? intval($_GET['cf7-id']) : "";
$page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
$url_args = array('page' => $page);
if(!empty($cf7_id)){
    $url_args['cf7-id'] = $cf7_id;
}
$admin_page_url = add_query_arg( $url_args, admin_url( 'admin.php' ) );

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

wp_enqueue_style('cfdb7_magnific_popup_style');
wp_enqueue_style('jquery-ui-css');
wp_enqueue_style('cfdb7_chosen_style');
wp_enqueue_script('cfdb7_magnific_popup_script');
wp_enqueue_script('jquery-ui-datepicker');
wp_enqueue_script('cfdb7_chosen_script');

/**
 * Class Custom_WP_List_Table
 *
 * Handles the display and management of deleted entries in the admin area for the Cfdb7 Pro plugin.
 * Extends the WP_List_Table class to provide custom table functionality for Contact Form 7 entries.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
*/
class Custom_WP_List_Table extends WP_List_Table {
    private $cf7_id;
    private $wpdb;
    private $obj;
    private $form_settings = array();

    /**
     * Constructor for Custom_WP_List_Table.
     * Initializes the table, sets up dependencies, and loads form settings.
     */
    public function __construct() {
        parent::__construct([
            'singular' => 'item',
            'plural'   => 'items',
            'ajax'     => false
        ]);

        global $wpdb;
        $obj = new Cfdb7_Queries();
        $obj->init_cfdb7_tables();

        $this->cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? intval($_GET['cf7-id']) : "";;
        $this->wpdb = $wpdb;
        $this->obj = $obj;
        $this->form_settings = $obj->get_cfdb7_form_setting($wpdb, $this->cf7_id);
    }

    /**
     * Get the columns for the export logs table.
     *
     * @return array Columns to display in the table.
     */
    public function get_columns() {
        return [
            'lead_source' => esc_html__('Lead Source', CFDB7_PRO_TEXT_DOMAIN),
            'db7_forms_id' => esc_html__('CFDB7 Id', CFDB7_PRO_TEXT_DOMAIN),
            'entry_id' => esc_html__('Entry Id', CFDB7_PRO_TEXT_DOMAIN),
            'date_time' => esc_html__('Date Time', CFDB7_PRO_TEXT_DOMAIN),
            'view_cta' => esc_html__('View', CFDB7_PRO_TEXT_DOMAIN),
        ];
    }

    /**
     * Default column rendering for the table.
     *
     * @param array $item The current item.
     * @param string $column_name The name of the column.
     * @return string Column output.
     */
    public function column_default($item, $column_name) {
        switch ($column_name) {
            case 'lead_source':
            case 'db7_forms_id':
            case 'entry_id':
                return esc_html($item[$column_name]);
            case 'date_time':
                return esc_html($item[$column_name]);
            case 'view_cta':
                return $this->get_view_cta($item['id']);
            default:
                return "no value";
        }
    }

    /**
     * Output the View button for a given entry.
     *
     * @param int $id Entry ID.
     */
    private function get_view_cta($id){
        echo '<input type="button" class="button view-logger-cta" data-index="' . esc_attr( $id ) . '" data-cf7_id="' . esc_attr( $this->cf7_id ) . '" value="' . esc_html__( 'View', CFDB7_PRO_TEXT_DOMAIN ) . '">';
    }

    /**
     * Prepare the items for display (pagination, filtering, etc).
     * Handles date filters and sets up pagination arguments.
     */
    public function prepare_items() {
        $enquiries_per_page = 10;
        if(!empty( $this->form_settings)){
            $form_settings = isset($this->form_settings['settings']) && !empty($this->form_settings['settings']) ? maybe_unserialize($this->form_settings['settings']) : array();
            $form_settings = !empty($form_settings) ? array_map('sanitize_text_field', $form_settings) : array();

            $enquiries_per_page = isset($form_settings['enquiries_per_page']) && !empty($form_settings['enquiries_per_page']) ? intval($form_settings['enquiries_per_page']) : 10;
        }

        $per_page = $enquiries_per_page;
        $current_page = $this->get_pagenum();

        $from_date = !empty($_GET['from_date']) ? sanitize_text_field($_GET['from_date']) : '';
        $from_date = isset($from_date) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $from_date) ? $from_date : '';

        $to_date   = !empty($_GET['to_date'])   ? sanitize_text_field($_GET['to_date'])   : '';
        $to_date = isset($to_date) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $to_date) ? $to_date : '';

        if (!empty($from_date) && !empty($to_date) && strtotime($from_date) > strtotime($to_date)) {
            add_settings_error('date_filter_error', 'invalid_date_range', esc_html__('Invalid date range: From Date is later than To Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        } else if (!empty($from_date) && empty($to_date)) {
            add_settings_error('date_filter_error', 'missing_to_date', esc_html__('Kindly select To Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        } else if (empty($from_date) && !empty($to_date)) {
            add_settings_error('date_filter_error', 'missing_from_date', esc_html__('Kindly select From Date.', CFDB7_PRO_TEXT_DOMAIN), 'error');
            settings_errors('date_filter_error');
        }

        $all_data = $this->get_data($from_date, $to_date);

        $total_items = count($all_data);

        // Pagination
        $paged_data = array_slice($all_data, ($current_page - 1) * $per_page, $per_page);

        $this->items = $paged_data;

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ]);

        $this->_column_headers = [$this->get_columns(), [], []];
    }

    /**
     * Retrieve export log data for the table.
     *
     * @param string $from_date Optional. Filter from date (Y-m-d).
     * @param string $to_date Optional. Filter to date (Y-m-d).
     * @return array Export log data.
     */
    public function get_data($from_date = "", $to_date = "") {
        $cf7_id = $this->cf7_id;
        $wpdb = $this->wpdb;
        $obj = $this->obj;

        $data = $obj->get_cfdb7_export_log($wpdb, $cf7_id, $from_date, $to_date);
        
        return $data;
    }

    /**
     * Display the date filter UI for the export logs table.
     */
    public function get_date_filters() {
        $filter_type = "date_filter";
        include CFDB7_PRO_PLUGIN_DIR . 'admin/partials/cfdb7_list_table_forms.php';
    }
}

$table = new Custom_WP_List_Table();
$table->prepare_items();
?>
<div class="wrap cfdb7-export-log">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Export Logs', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
    <div class="loader" style="display:none;"></div>
    <div id="cfdb7-entries-ctas-container">
        <button class="reset-settings" class="button"><?php echo esc_html__('Reset All', CFDB7_PRO_TEXT_DOMAIN); ?></button>
    </div>
    <div id="date-filter-container">
        <?php $table->get_date_filters(); ?>
    </div>
    <div id="wp-list-table-container">
        <form id="wp-list-table" method="get" action="<?php echo esc_url($admin_page_url); ?>" novalidate="novalidate">
            <input type="hidden" name="page" value="<?php echo esc_attr($page); ?>" />
            <input type="hidden" name="cf7-id" value="<?php echo esc_attr($cf7_id); ?>" />
            <?php $table->display(); ?>
        </form>
    </div>
</div>
<div id="popup-content" class="mfp-hide">
    <div class="logger-information-container">
    </div>
</div>