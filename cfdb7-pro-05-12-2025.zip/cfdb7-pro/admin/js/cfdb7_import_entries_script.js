jQuery(document).ready(function () {
    jQuery("#cf7-id").change(function () {
        var cf7_id = jQuery(this).val();
        var nonce = jQuery("#import_entries_page_nonce").val();
        var current_url = new URL(window.location.href);
        current_url.searchParams.delete('cf7-id');
        if (cf7_id != "") {
            window.location = current_url + '&cf7-id=' + cf7_id + '&nonce=' + nonce;
        } else {
            window.location = current_url;
        }
    });

    jQuery('#upload_csv').on('change', function () {
        jQuery('.notice').css('display', 'none');
        var file = this.files[0];
        var fileName = file.name.toLowerCase();
        var fileType = file.type;
        var isCSV = fileName.endsWith('.csv') && (fileType === 'text/csv' || fileType === 'application/vnd.ms-excel');

        if (isCSV) {
            jQuery("#notice").html('');
            jQuery('.notice').css('display', 'none');
        } else {
            jQuery("#notice").html(cfdb7_params.invalid_file_massage);
            jQuery('.notice').css('display', 'block');
            jQuery(this).val('');
        }
    });

    jQuery('#import_data').on('submit', function (e) {
        let fileInput = jQuery('#upload_csv')[0];
        let file = fileInput.files[0];
        if (file == undefined) {
            jQuery("#notice").html(cfdb7_params.require_massage);
            jQuery('.notice').css('display', 'block');
            e.preventDefault();
        }
    });
});