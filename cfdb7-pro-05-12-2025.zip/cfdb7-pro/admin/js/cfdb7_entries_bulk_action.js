jQuery(document).ready(function () {
    function cfdb7_open_popup() {
        jQuery.magnificPopup.open({
            items: {
                src: '#popup-content'
            },
            type: 'inline',
            callbacks: {
                open: function () {
                    var bar = jQuery('.progress-bar');
                    bar.animate({ width: '0%' }, 5000, 'linear');
                },
                close: function () {
                    jQuery('.progress-bar').stop(true).css('width', '0%');
                }
            }
        });
    }

    if (jQuery(".entries-delete-entry-ids").length > 0) {
        var max_paged = jQuery(".entries-delete-entry-ids").length;
        var proceed_paged = 1;
        setTimeout(function () {
            var cf7_id = jQuery("#cf7-id").val();
            var nonce = jQuery("#cfdb7_entries_nonce").val();
            var current_index = jQuery(".entries-delete-entry-ids").eq(0).data('index');
            var entry_ids = jQuery(".entries-delete-entry-ids").eq(0).val();
            
            cfdb7_open_popup();
            cfdb7_entries_trigger_bulk_delete(cf7_id, nonce, current_index, entry_ids);
        }, 1000);

        function cfdb7_entries_trigger_bulk_delete(cf7_id, nonce, current_index, entry_ids) {
            var referer_url = jQuery("#referer_url").val();

            jQuery.ajax({
                url: cfdb7_params.ajax_url,
                data: {
                    'action': 'cfdb7_entries_delete_entry_ids',
                    'cf7_id': cf7_id,
                    'nonce': nonce,
                    'current_index': current_index,
                    'entry_ids': entry_ids,
                },
                type: 'POST',
                success: function (data) {
                    var result = JSON.parse(data);
                    if (result.status == 'success') {
                        jQuery("#notice").append("<div class='notice notice-success'>" + result.message + "</div>");
                    } else {
                        jQuery("#notice").append("<div class='notice notice-error'>" + result.message + "</div>");
                    }
                    proceed_paged = parseInt(proceed_paged);
                    max_paged = parseInt(max_paged);
                    var proceed_ratio = (proceed_paged / max_paged) * 100;
                    console.log(proceed_paged + "::" + max_paged + "::" + proceed_ratio);
                    proceed_paged++;
                    setTimeout(function () {
                        var bar = jQuery('.progress-bar');
                        bar.css('width', proceed_ratio + '%')
                    }, 100);
                    jQuery(".entries-delete-entry-ids").eq(0).remove();

                    if (proceed_paged == max_paged) {
                        setTimeout(function () {
                            jQuery("#notice").append("<div class='notice notice-info'><a href='" + referer_url + "'>" + cfdb7_params.return_to_entries + "</a></div>");
                            jQuery('.notice').css('display', 'block');
                            jQuery.magnificPopup.close();
                        }, 1000);
                    } else if (max_paged == 1) {
                        setTimeout(function () {
                            jQuery("#notice").append("<div class='notice notice-info'><a href='" + referer_url + "'>" + cfdb7_params.return_to_entries + "</a></div>");
                            jQuery('.notice').css('display', 'block');
                            jQuery.magnificPopup.close();
                        }, 1000);
                    }
                },
                complete: function () {
                    setTimeout(function () {
                        if (jQuery(".entries-delete-entry-ids").length > 0) {
                            var current_index = jQuery(".entries-delete-entry-ids").eq(0).data('index');
                            var entry_ids = jQuery(".entries-delete-entry-ids").eq(0).val();
                            cfdb7_entries_trigger_bulk_delete(cf7_id, nonce, current_index, entry_ids);
                        } else {
                            jQuery(".cfdb7-delete-entries .loader").css("display", 'none');
                            jQuery.magnificPopup.close();
                        }
                    }, 500);
                },
                fail: function () {
                    jQuery(".cfdb7-delete-entries .loader").css("display", 'none');
                }
            });
        }
    }

    if (jQuery(".entries-export-entry-ids").length > 0) {
        var max_paged = jQuery(".entries-export-entry-ids").length;
        var proceed_paged = 1;
        setTimeout(function () {
            var cf7_id = jQuery("#cf7-id").val();
            var nonce = jQuery("#cfdb7_entries_nonce").val();
            var current_index = jQuery(".entries-export-entry-ids").eq(0).data('index');
            var entry_ids = jQuery(".entries-export-entry-ids").eq(0).val();
            var context = jQuery("#context").val();

            cfdb7_open_popup();
            cfdb7_entries_trigger_bulk_export(cf7_id, nonce, current_index, entry_ids, context);
        }, 1000);

        function cfdb7_entries_trigger_bulk_export(cf7_id, nonce, current_index, entry_ids, context) {
            jQuery.ajax({
                url: cfdb7_params.ajax_url,
                data: {
                    'action': 'cfdb7_entries_export_entry_ids',
                    'cf7_id': cf7_id,
                    'nonce': nonce,
                    'current_index': current_index,
                    'entry_ids': entry_ids,
                    'context': context,
                },
                type: 'POST',
                success: function (data) {
                    /*proceed_paged = parseInt(proceed_paged);
                    max_paged = parseInt(max_paged);
                    var proceed_ratio = (proceed_paged / max_paged) * 100;
                    console.log(proceed_paged + "::" + max_paged + "::" + proceed_ratio);
                    proceed_paged++;
                    setTimeout(function () {
                        var bar = jQuery('.progress-bar');
                        bar.css('width', proceed_ratio + '%')
                    }, 1000);
                    jQuery(".entries-export-entry-ids").eq(0).remove();

                    if (proceed_paged == max_paged) {
                        jQuery("#notice").html(cfdb7_params.success_delete_message);
                        jQuery('.notice').css('display', 'block');
                        jQuery.magnificPopup.close();
                    } else if (max_paged == 1) {
                        jQuery("#notice").html(cfdb7_params.success_delete_message);
                        jQuery('.notice').css('display', 'block');
                        jQuery.magnificPopup.close();
                    }*/
                },
                complete: function () {
                    /*setTimeout(function () {
                        if (jQuery(".entries-export-entry-ids").length > 0) {
                            var current_index = jQuery(".entries-export-entry-ids").eq(0).data('index');
                            var entry_ids = jQuery(".entries-export-entry-ids").eq(0).val();
                            cfdb7_entries_trigger_bulk_delete(cf7_id, nonce, current_index, entry_ids);
                        } else {
                            jQuery(".cfdb7-export-entries .loader").css("display", 'none');
                            jQuery.magnificPopup.close();
                        }
                    }, 500);*/
                },
                fail: function () {
                    jQuery(".cfdb7-export-entries .loader").css("display", 'none');
                }
            });
        }
    }
});