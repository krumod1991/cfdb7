<?php

/**
 * Fired during plugin activation
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/includes
*/
class Cfdb7_Queries {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	*/
	private $cfdb7_settings;
	private $cfdb7_settings_log;
	private $cfdb7_db;

	private $cfdb7_entries_details;
	private $cfdb7_entries_submissions;
	private $cfdb7_entries_field_name_options;

	private $cfdb7_delete_entries_log;
	private $cfdb7_delete_entries_submissions;
	private $cfdb7_delete_entries_field_name_options;

	private $cfdb7_entries_log;
	private $cfdb7_entries_submissions_log;
	private $cfdb7_entries_field_name_options_log;

	private $cfdb7_display_settings;
	private $cfdb7_export_log;
	
	/**
	 * Initialize the plugin's database tables.
	 *
	 * @since    1.0.0
	*/
	public function init_cfdb7_tables(){
		$this->cfdb7_settings = 'cfdb7_settings';
		$this->cfdb7_settings_log = 'cfdb7_settings_log';
		$this->cfdb7_db = 'db7_forms';

		$this->cfdb7_entries_details = 'cfdb7_entries_details_form_{form_id}';
		$this->cfdb7_entries_submissions = 'cfdb7_entries_submission_form_{form_id}';
		$this->cfdb7_entries_field_name_options = 'cfdb7_entries_field_name_options_form_{form_id}';

		$this->cfdb7_delete_entries_log = 'cfdb7_delete_entries_logs_form_{form_id}';
		$this->cfdb7_delete_entries_submissions = 'cfdb7_delete_entries_submission_form_{form_id}';
		$this->cfdb7_delete_entries_field_name_options = 'cfdb7_delete_entries_field_name_options_form_{form_id}';

		$this->cfdb7_entries_log = 'cfdb7_entries_logs_form_{form_id}';
		$this->cfdb7_entries_submissions_log = 'cfdb7_entries_logs_submission_form_{form_id}';
		$this->cfdb7_entries_field_name_options_log = 'cfdb7_entries_logs_field_name_options_form_{form_id}';
		
		$this->cfdb7_display_settings = 'cfdb7_display_settings_form_{form_id}';
		$this->cfdb7_export_log = 'cfdb7_export_logs_form_{form_id}';
	}

	/**
	 * Retrieve the settings for a specific CFDB7 form.
	 *
	 * @since    1.0.0
	 * @param    object    $wpdb      The WordPress database object.
	 * @param    int       $form_id   The ID of the CFDB7 form.
	 * @return   array                An array containing the form settings.
	*/
	public function get_cfdb7_form_setting($wpdb, $form_id) {
		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}{$this->cfdb7_settings} where form_id=%d", $form_id), ARRAY_A );
	}

	/**
	 * Save the settings for a CFDB7 form into the database.
	 *
	 * @since    1.0.0
	 * @param    object    $wpdb    The WordPress database object.
	 * @param    array     $data    The form settings data to save.
	 * @param    array     $format  The format for each field in the data array.
	 * @return   int                 The ID of the newly inserted row.
	*/
	public function save_cfdb7_form_setting($wpdb, $data, $format) {
		$table_name = "{$wpdb->prefix}{$this->cfdb7_settings}";
		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Update the settings for a CFDB7 form in the database.
	 *
	 * @since    1.0.0
	 * @param    object    $wpdb          The WordPress database object.
	 * @param    array     $data          The form settings data to update.
	 * @param    array     $format        The format for each field in the data array.
	 * @param    array     $where         The WHERE clause to determine which row(s) to update.
	 * @param    array     $where_format  The format for each field in the WHERE clause.
	*/
	public function update_cfdb7_form_setting($wpdb, $data, $format, $where, $where_format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_settings}";
		return $wpdb->update($table_name, $data, $where, $format, $where_format);
	}

	/**
	 * Save a log entry for CFDB7 settings into the database.
	 * 
	 * @since 1.0.0
	 * @param wpdb  $wpdb   The WordPress database object.
	 * @param array $data   The log data to be inserted (column => value).
	 * @param array $format The format for each field in the $data array (%s, %d, etc.).
	 * @return int|false    The number of rows inserted, or false on failure.
	*/
	public function save_cfdb7_setting_log($wpdb, $data, $format) {
		$table_name = "{$wpdb->prefix}{$this->cfdb7_settings_log}";
		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Save a CFDB7 form entry to the cfdb7_db database.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb   The WordPress database instance.
	 * @param array $data   Associative array of column => value pairs to insert.
	 * @param array $format The format for each field in the $data array (%s, %d, etc.).
	 * @return int|false    The number of rows inserted, or false on failure.
	*/
	public function save_db7_forms_entry($wpdb, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_db}";
		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Save a CFDB7 form entry into the addon database.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb     The WordPress database instance.
	 * @param int   $form_id  The ID of the CFDB7 form for which the entry is being saved.
	 * @param array $data     Associative array of column => value pairs to insert.
	 * @param array $format   The format for each field in the $data array (%s, %d, etc.).
	 * @return int|false      The number of rows inserted, or false on failure.
	*/
	public function save_cfdb7_entry($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}
	
	/**
	 * Save a CFDB7 form submission entry into the submissions table.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb     The WordPress database instance.
	 * @param int   $form_id  The CFDB7 form ID for which the submission is being saved.
	 * @param array $data     Associative array of column => value pairs to insert.
	 * @param array $format   The format for each field in the $data array (%s, %d, etc.).
	 * @return int|false      The number of rows inserted, or false on failure.
	*/
	public function save_cfdb7_entry_submissions($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Retrieve distinct form post IDs from the database.
	 *
	 * This function queries the database table associated with CFDB7 (Contact Form DB 7)
	 * to get a list of unique form post IDs that have entries in the table.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb The WordPress database object.
	 * @return array Returns an array of associative arrays containing the distinct
	 *               form post IDs. Each element has a key 'form_ids' with the ID value.
	*/
	public function get_db7_available_form_post_ids($wpdb){
		$main_table    = "{$wpdb->prefix}{$this->cfdb7_db}";

		return $wpdb->get_results("SELECT DISTINCT(`form_post_id`) as form_ids FROM {$main_table}", ARRAY_A);
	}

	/**
	 * Retrieve the number of orphaned DB7 form entries for a given form.
	 *
	 * This method counts how many records exist in the main DB7 forms table that do
	 * **not** have a corresponding entry in the form-specific details table.
	 * Essentially, it identifies entries whose detailed data is missing.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb     WordPress database abstraction object.
	 * @param int    $form_id  The ID of the form whose orphaned entries should be counted.
	 * @return array           Associative array containing:
	 *                         - 'count' (int): Number of entries in the main table
	 *                           where `form_post_id = $form_id` and no matching
	 *                           record exists in the details table.
	 *
	 * SQL summary:
	 * - Joins the main forms table with the form-specific details table.
	 * - Counts entries where `m.form_post_id = $form_id` and `d.db7_forms_id IS NULL`
	 *   (meaning no detailed record exists).
	*/
	public function get_db7_forms_entries_count($wpdb, $form_id){
		$main_table    = "{$wpdb->prefix}{$this->cfdb7_db}";
		$details_table = str_replace("{form_id}", $form_id, "{$wpdb->prefix}{$this->cfdb7_entries_details}");

		$sql = "SELECT count(m.form_id) as count FROM {$main_table} AS m LEFT JOIN {$details_table} AS d ON m.form_id = d.db7_forms_id WHERE m.form_post_id = %d AND d.db7_forms_id IS NULL";

		return $wpdb->get_row($wpdb->prepare($sql, $form_id),ARRAY_A);
	}

	/**
	 * Retrieve DB7 form entries that have not yet been indexed.
	 *
	 * This method fetches entries from the main DB7 forms table (`cfdb7_db`) that do not have
	 * corresponding records in the details table (`cfdb7_entries_details`) for a specific form ID.
	 * It performs a LEFT JOIN between the main table and the details table and filters out entries
	 * that already exist in the details table. Results are limited by the provided `$limit`.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb     The WordPress database object.
	 * @param int  $form_id  The ID of the form whose entries should be retrieved.
	 * @param int  $limit    The maximum number of entries to return.
	 * @return array An array of associative arrays representing the unindexed form entries.
	 */
	public function get_db7_forms_indexing_entries($wpdb, $form_id, $limit){
		$main_table    = "{$wpdb->prefix}{$this->cfdb7_db}";
		$details_table = str_replace("{form_id}", $form_id, "{$wpdb->prefix}{$this->cfdb7_entries_details}");

		$sql = "SELECT m.form_id,m.form_post_id,m.form_value,m.form_date,m.lead_source FROM {$main_table} AS m LEFT JOIN {$details_table} AS d ON m.form_id = d.db7_forms_id WHERE m.form_post_id = %d AND d.db7_forms_id IS NULL LIMIT $limit";

		return $wpdb->get_results($wpdb->prepare($sql, $form_id),ARRAY_A);
	}

	/**
	 * Retrieve a single CFDB7 form entry by entry ID.
	 *
	 * @since 1.0.0	 * @param wpdb $wpdb       The WordPress database instance.
	 * @param int  $entry_id   The unique ID of the form entry to fetch.
	 * @return array      	   The entry data as an associative array, or empty if not found.
	*/
	public function get_db7_forms_entry($wpdb, $entry_id){
		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}{$this->cfdb7_db} where form_id=%d", $entry_id), ARRAY_A );
	}

	/**
	 * Check whether a CFDB7 submission exists with a specific field and value.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb         The WordPress database instance.
	 * @param int   $form_id      The form ID whose submission table will be checked.
	 * @param string $avoid_field The name of the form field to match.
	 * @param string $field_value The value of the field to validate.
	 * @return array              The matching row as an associative array, or empty if not found.
	*/
	public function check_Cfdb7_submission($wpdb, $form_id, $avoid_field, $field_value){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} where field_name=%s and field_value=%s", $avoid_field, $field_value), ARRAY_A );
	}

	/**
	 * Save a log entry for a CFDB7 form action or submission event.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb     The WordPress database instance.
	 * @param int   $form_id  The ID of the CFDB7 form related to the log entry.
	 * @param array $logger   Associative array containing log data to be saved.
	 * @return int|false      Number of rows inserted, or false on failure.
 	*/
	public function save_entry_log($wpdb, $form_id, $logger){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$logger_data = array(
			'lead_source' => isset($logger['lead_source']) && !empty($logger['lead_source']) ? $logger['lead_source'] : "",

			'form_setting' => isset($logger['form_setting']) && !empty($logger['form_setting']) ? maybe_serialize($logger['form_setting']) : "",

			'db7_forms_id' => isset($logger['db7_forms_id']) && !empty($logger['db7_forms_id']) ? $logger['db7_forms_id'] : "",

			'original_entry' => isset($logger['original_entry']) && !empty($logger['original_entry']) ? maybe_serialize($logger['original_entry']) : "",

			'original_entry_fields' => isset($logger['original_entry_fields']) && !empty($logger['original_entry_fields']) ? maybe_serialize($logger['original_entry_fields']) : "",

			'form_entry' => isset($logger['form_entry']) && !empty($logger['form_entry']) ? maybe_serialize($logger['form_entry']) : "",

			'proceed_entry' => isset($logger['proceed_entry']) && !empty($logger['proceed_entry']) ? maybe_serialize($logger['proceed_entry']) : "",

			'proceed_entry_fields' => isset($logger['proceed_entry_fields']) && !empty($logger['proceed_entry_fields']) ? maybe_serialize($logger['proceed_entry_fields']) : "",

			'entry_id' => isset($logger['entry_id' ]) && !empty($logger['entry_id' ]) ? $logger['entry_id' ] : "",

			'entry_details' => isset($logger['entry_details']) && !empty($logger['entry_details']) ? maybe_serialize($logger['entry_details']) : "",
			
			'date_time' => isset($logger['date_time']) && !empty($logger['date_time']) ? $logger['date_time'] : "",
		);

		$logger_format = array_fill(0, count($logger_data), '%s');

		$wpdb->insert($table_name, $logger_data, $logger_format);
		return $wpdb->insert_id;
	}

	/**
	 * Save a CFDB7 form field log submission to the database.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb   WordPress database abstraction object.
	 * @param int    $form_id  The ID of the Contact Form 7 form.
	 * @param array  $data     The submission data to be stored.
	 * @param string $format   The format for each field in the data array.
	 * @return int   The ID of the inserted database record on success, or false on failure.
	*/
	public function save_cfdb7_log_submissions($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Get the count of occurrences for a specific CFDB7 field name (or all field names) 
	 * within a form's submissions table.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb        WordPress database abstraction object used for queries.
	 * @param int    $form_id     The Contact Form 7 form ID whose submission table should be queried.
	 * @param string $field_name  Optional. Specific field name to count occurrences for. 
	 *                            If empty, counts for all field names are returned. Default "".
	 * @return array Array of associative arrays with keys:
	 *               - 'field_name' (string) The field name.
	 *               - 'count'      (string|int) Number of occurrences of that field name.
	 *               Returns an empty array if no results are found.
 	*/
	public function get_cfdb7_report_field_name_options_count($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);
		
		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} where field_name=%s GROUP BY field_name", $field_name), ARRAY_A );
		}else{
			return $wpdb->get_results("SELECT field_name,count(`field_name`) as count FROM {$table_name} GROUP BY field_name", ARRAY_A );
		}
	}

	/**
	 * Retrieve saved CFDB7 field name values for a given form.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb        WordPress database abstraction object used for queries.
	 * @param int    $form_id     The Contact Form 7 form ID whose field option table is queried.
	 * @param string $field_name  Optional. Specific field name to filter results by. 
	 *                            If empty, all field option records are returned. Default "".
	 * @return array Array of associative arrays representing table rows. Each row typically includes:
	 *               - 'field_name' (string)  
	 *               - 'field_value' (string)  
	 *               - other columns defined by the CFDB7 field name table schema.
	 *               Returns an empty array if no results are found.
	*/
	public function get_cfdb7_report_field_name_options($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where field_name=%s", $field_name), ARRAY_A );
		}else{
			return $wpdb->get_results("SELECT * FROM {$table_name}", ARRAY_A );
		}
	}

	/**
	 * Truncate the CFDB7 field name options table for a specific form.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb     WordPress database abstraction object used to run queries.
	 * @param int  $form_id  The Contact Form 7 form ID whose options table should be truncated.
	*/
	public function truncate_cfdb7_report_field_name_options($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->query("TRUNCATE TABLE {$table_name}");
	}

	/**
	 * Insert a new CFDB7 field name option record for the specified form.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb        WordPress database abstraction object used to run the insert query.
	 * @param int    $form_id     The Contact Form 7 form ID whose option data is being saved.
	 * @param string $field_name  The field name for which the option record is being created.
	 * @param int    $field_count The number of entries counted for the given field.
	 * @return int   The ID of the newly inserted row. Returns 0 if the insert fails.
	*/
	public function save_cfdb7_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'field_name' => $field_name,
			'entry_count' => $field_count,
		);
		$field_format = array("%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	/**
	 * Update the entry count for a specific CFDB7 field name option record.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb        WordPress database abstraction object used to perform the update.
	 * @param int    $form_id     The Contact Form 7 form ID whose option data is being updated.
	 * @param string $field_name  The field name whose option record should be updated.
	 * @param int    $field_count The new entry count value to assign to the field.
	 * @return int|false Number of rows updated on success, or false on failure.
	*/
	public function update_cfdb7_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'entry_count' => $field_count,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'field_name' => $field_name,
		);
		$where_field_format = array("%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	/**
	 * Retrieve the count of occurrences for a specific field name (or all field names)
	 * from the CFDB7 *deleted* submissions table for a given form.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb        WordPress database abstraction object used for queries.
	 * @param int    $form_id     The Contact Form 7 form ID whose deleted submissions table is queried.
	 * @param string $field_name  Optional. Field name to filter by. If empty, counts for all fields
	 *                            are returned. Default "".
	 * @return array Array of associative arrays with keys:
	 *               - 'field_name' (string)  
	 *               - 'count'      (string|int) Number of occurrences  
	 *               Returns an empty array if no results exist.
	*/
	public function get_cfdb7_delete_report_field_name_options_count($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);
		
		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} where field_name=%s GROUP BY field_name", $field_name), ARRAY_A );
		}else{
			return $wpdb->get_results("SELECT field_name,count(`field_name`) as count FROM {$table_name} GROUP BY field_name", ARRAY_A );
		}
	}

	/**
	 * Retrieve CFDB7 deleted field name option records for a specific form.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb        WordPress database abstraction object used for queries.
	 * @param int    $form_id     The Contact Form 7 form ID whose deleted field options table is queried.
	 * @param string $field_name  Optional. Field name to filter results by. If empty, all records
	 *                            from the table are returned. Default "".
	 * @return array Array of associative arrays representing table rows. Fields typically include:
	 *               - 'field_name'    (string)
	 *               - 'entry_count'   (int|string)  
	 *               - any additional columns defined in the CFDB7 deleted options table schema.
	 *               Returns an empty array if no records are found.
	*/
	public function get_cfdb7_delete_report_field_name_options($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where field_name=%s", $field_name), ARRAY_A );
		}else{
			return $wpdb->get_results("SELECT * FROM {$table_name}", ARRAY_A );
		}
	}

	/**
	 * Truncate the CFDB7 deleted field name options table for a specific form.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb     WordPress database abstraction object used to run the query.
	 * @param int  $form_id  The Contact Form 7 form ID whose deleted field options table should be truncated.
	*/
	public function truncate_cfdb7_delete_report_field_name_options($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->query("TRUNCATE TABLE {$table_name}");
	}

	/**
	 * Insert a new record into the CFDB7 deleted field name options table for a form.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb        WordPress database abstraction object used to perform the insert.
	 * @param int    $form_id     The Contact Form 7 form ID whose deleted field option record is being saved.
	 * @param string $field_name  The field name for which the deleted option record is being created.
	 * @param int    $field_count The number of entries counted for the given field.
	 * @return int                The ID of the newly inserted row. Returns 0 if the insert fails.
	*/
	public function save_cfdb7_delete_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'field_name' => $field_name,
			'entry_count' => $field_count,
		);
		$field_format = array("%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	/**
	 * Update the entry count for a specific field in the CFDB7 deleted field name options table.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb        WordPress database abstraction object used to perform the update.
	 * @param int    $form_id     The Contact Form 7 form ID whose deleted field option record should be updated.
	 * @param string $field_name  The field name whose deleted option record is being updated.
	 * @param int    $field_count The new entry count value to assign to the field.
	*/
	public function update_cfdb7_delete_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_field_name_options}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'entry_count' => $field_count,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'field_name' => $field_name,
		);
		$where_field_format = array("%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	/**
	 * Retrieve the count of occurrences for a specific field name (or all field names)
	 * from the CFDB7 submission log table for a given form.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb        WordPress database abstraction object used for queries.
	 * @param int    $form_id     The Contact Form 7 form ID whose submissions log table is queried.
	 * @param string $field_name  Optional. Field name to filter by. If empty, counts for all fields
	 *                            are returned. Default "".
	 * @return array Array of associative arrays with keys:
	 *               - 'field_name' (string)  
	 *               - 'count'      (string|int) Number of occurrences  
	 *               Returns an empty array if no results exist.
	*/
	public function get_cfdb7_log_report_field_name_options_count($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);
		
		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT field_name,count(`field_name`) as count FROM {$table_name} where field_name=%s GROUP BY field_name", $field_name), ARRAY_A );
		}else{
			return $wpdb->get_results("SELECT field_name,count(`field_name`) as count FROM {$table_name} GROUP BY field_name", ARRAY_A );
		}
	}

	/**
	 * Retrieve CFDB7 submission log field name option records for a specific form.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb        WordPress database abstraction object used for queries.
	 * @param int    $form_id     The Contact Form 7 form ID whose field options log table is queried.
	 * @param string $field_name  Optional. Field name to filter results by. If empty, all records
	 *                            from the log table are returned. Default "".
	 * @return array Array of associative arrays representing table rows. Fields typically include:
	 *               - 'field_name'    (string)
	 *               - 'entry_count'   (int|string)
	 *               - any additional columns defined in the CFDB7 field options log table schema.
	 *               Returns an empty array if no records are found.
	*/
	public function get_cfdb7_log_report_field_name_options($wpdb, $form_id, $field_name = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($field_name)){
			return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where field_name=%s", $field_name), ARRAY_A );	
		}else{
			return $wpdb->get_results("SELECT * FROM {$table_name}", ARRAY_A );	
		}
	}

	/**
	 * Truncate the CFDB7 field name options log table for a specific form.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb     WordPress database abstraction object used to run the query.
	 * @param int  $form_id  The Contact Form 7 form ID whose field options log table should be truncated.
	*/
	public function truncate_cfdb7_log_report_field_name_options($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->query("TRUNCATE TABLE {$table_name}");
	}

	/**
	 * Insert a new record into the CFDB7 field name options log table for a form.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb        WordPress database abstraction object used to perform the insert.
	 * @param int    $form_id     The Contact Form 7 form ID whose field option log record is being saved.
	 * @param string $field_name  The field name for which the option record is being created.
	 * @param int    $field_count The number of entries counted for the given field.
	 * @return int                The ID of the newly inserted row. Returns 0 if the insert fails.
	*/
	public function save_cfdb7_log_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'field_name' => $field_name,
			'entry_count' => $field_count,
		);
		$field_format = array("%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	/**
	 * Update the entry count for a specific field in the CFDB7 field name options log table.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb        WordPress database abstraction object used to perform the update.
	 * @param int    $form_id     The Contact Form 7 form ID whose field option log record should be updated.
	 * @param string $field_name  The field name whose option log record is being updated.
	 * @param int    $field_count The new entry count value to assign to the field.
	*/
	public function update_cfdb7_log_report_field_name_options($wpdb, $form_id, $field_name, $field_count){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_field_name_options_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'entry_count' => $field_count,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'field_name' => $field_name,
		);
		$where_field_format = array("%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}
	
	/**
	 * Retrieve the total number of entries in the CFDB7 export log table for a specific form.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb    WordPress database abstraction object used for the query.
	 * @param int  $form_id The Contact Form 7 form ID whose export log table is being counted.
	 * @return array        Associative array with a single key: - 'count' (int|string) Total number of export log entries.                   
	*/
	public function get_cfdb7_export_log_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_export_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row("SELECT count('id') as count FROM {$table_name}", ARRAY_A );	
	}

	/**
	 * Retrieve export log records for a specific CFDB7 form, optionally filtered by date range.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb      WordPress database abstraction object used for queries.
	 * @param int    $form_id   The Contact Form 7 form ID whose export log is being retrieved.
	 * @param string $from_date Optional. Start date to filter logs (inclusive). Format: 'YYYY-MM-DD'. Default "".
	 * @param string $to_date   Optional. End date to filter logs (inclusive). Format: 'YYYY-MM-DD'. Default "".
	 * @return array Array of associative arrays representing the export log rows. 
	*/
	public function get_cfdb7_export_log($wpdb, $form_id, $from_date = "", $to_date = ""){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_export_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$search_array = array();
		if(!empty($from_date) && !empty($to_date)){
			$from_date = date("Y-m-d", strtotime($from_date));
			$to_date = date("Y-m-d", strtotime($to_date));
			$search_array[] = $wpdb->prepare('date_time >= %s',$from_date . ' 00:00:00');
			$search_array[] = $wpdb->prepare('date_time <= %s',$to_date . ' 23:59:59');
		}

		$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";

		return $wpdb->get_results("SELECT * FROM {$table_name} where $search_str order by `id` desc", ARRAY_A );
	}

	/**
	 * Retrieve display settings for a specific CFDB7 form, user, and context.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb     WordPress database abstraction object used for the query.
	 * @param int    $form_id  The Contact Form 7 form ID whose display settings are being retrieved.
	 * @param int    $user_id  The ID of the user for whom the display settings are stored.
	 * @param string $context  The context or scope of the display settings for admin pages.
	 * @return array           Associative array of display settings for the user and context,
	 *                         or empty if no settings are found.
	*/
	public function get_cfdb7_form_display_settings($wpdb, $form_id, $user_id, $context){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_display_settings}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} where user_id=%d AND context=%s", $user_id, $context), ARRAY_A );
	}

	/**
	 * Save display settings for a specific CFDB7 form, user, and context.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb     WordPress database abstraction object used to perform the insert.
	 * @param int    $form_id  The Contact Form 7 form ID for which the display settings are being saved.
	 * @param int    $user_id  The ID of the user for whom the settings are being saved.
	 * @param string $context  The context or scope of the display settings for admin pages.
	 * @param string $settings Serialized display settings to store.
	 * @return int The ID of the newly inserted row. Returns 0 if the insert fails.
	*/
	public function save_cfdb7_form_display_settings($wpdb, $form_id, $user_id, $context, $settings){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_display_settings}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'user_id' => $user_id,
			'context' => $context,
			'settings' => $settings,
		);
		$field_format = array("%s","%s","%s");

		$wpdb->insert($table_name, $field_data, $field_format);
		return $wpdb->insert_id;
	}

	/**
	 * Update display settings for a specific CFDB7 form, user, and context.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb     WordPress database abstraction object used to perform the update.
	 * @param int    $form_id  The Contact Form 7 form ID whose display settings are being updated.
	 * @param int    $user_id  The ID of the user whose settings are being updated.
	 * @param string $context  The context or scope of the display settings for admin pages.
	 * @param string $settings Serialized display settings to update.
	*/
	public function update_cfdb7_form_display_settings($wpdb, $form_id, $user_id, $context, $settings){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_display_settings}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_data = array(
			'settings' => $settings,
		);
		$field_format = array("%s");

		$where_field_data = array(
			'user_id' => $user_id,
			'context' => $context,
		);
		$where_field_format = array("%s","%s");

		return $wpdb->update($table_name, $field_data, $where_field_data, $field_format, $where_field_format);
	}

	/**
	 * Retrieve the total number of entries submitted for a specific CFDB7 form.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb    WordPress database abstraction object used for the query.
	 * @param int  $form_id The Contact Form 7 form ID whose entries are being counted.
	 * @return array        Associative array with a single key: - 'count' (int) Total number of form  
	 *                      entries.                  
	*/
	public function get_cfdb7_form_entries_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row("SELECT count(`entry_id`) as count FROM {$table_name}", ARRAY_A );
	}

	/**
	 * Retrieve CFDB7 form entries with optional search filters.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb         WordPress database abstraction object used for queries.
	 * @param int   $form_id      The Contact Form 7 form ID whose entries are being retrieved.
	 * @param array $search_input Optional. Associative array of search filters:
	 *                            - 'field_names' (array) Fields to search within.
	 *                            - 's'           (string) General search term.
	 *                            - 'from_date'   (string) Start date for filtering (inclusive, 'YYYY-MM-DD').
	 *                            - 'to_date'     (string) End date for filtering (inclusive, 'YYYY-MM-DD').
	 * @return array Array of associative arrays representing form entries. Each entry typically
	 *               includes columns such as:
	 *               - 'entry_id'  (int) Unique ID of the entry
	 *               - 'date_time' (string) Submission timestamp
	 *               - 'field_name' (string) Field name for each submission row
	 *               - 'field_value' (string) Submitted value
	 *               Returns an empty array if no entries match the filters.
	*/
	public function get_cfdb7_form_entries($wpdb, $form_id, $search_input = array()){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($search_input)){
			$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
			$field_names = array_map( 'sanitize_text_field', (array) $field_names );
			$search_value = isset($search_input['s']) && !empty($search_input['s']) ? sanitize_text_field($search_input['s']) : "";
			$from_date = isset($search_input['from_date']) && !empty($search_input['from_date']) ? sanitize_text_field($search_input['from_date']) : "";
			$to_date = isset($search_input['to_date']) && !empty($search_input['to_date']) ? sanitize_text_field($search_input['to_date']) : "";

			$search_array = array();
			if(!empty($from_date) && !empty($to_date)){
				$from_date = date("Y-m-d", strtotime($from_date));
				$to_date = date("Y-m-d", strtotime($to_date));
				$search_array[] = $wpdb->prepare('date_time >= %s',$from_date . ' 00:00:00');
    			$search_array[] = $wpdb->prepare('date_time <= %s',$to_date . ' 23:59:59');
			}

			if(!empty($field_names) || !empty($search_value)){
				$entry_ids = $this->get_cfdb7_form_entries_submissions($wpdb, $form_id, $search_input);
				$entry_ids = !empty($entry_ids) ? wp_list_pluck($entry_ids, 'entry_id') : array();
				if(!empty($entry_ids)){
					$entry_ids_str = implode(', ', array_fill(0, count($entry_ids), '%d'));
					$search_array[] = $wpdb->prepare("entry_id IN ($entry_ids_str)", $entry_ids);
				}
			}

			if(!empty($search_array)){
				$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";
				return $wpdb->get_results("SELECT * FROM {$table_name} where $search_str order by `entry_id` desc", ARRAY_A );
			}else{
				return array();
			}
		}else{
			return $wpdb->get_results("SELECT * FROM {$table_name} order by `entry_id` desc", ARRAY_A );
		}
	}

	/**
	 * Retrieve entry IDs from CFDB7 form submissions based on search filters.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb         WordPress database abstraction object used for queries.
	 * @param int   $form_id      The Contact Form 7 form ID whose submissions are being queried.
	 * @param array $search_input Associative array of search filters:
	 *                            - 'field_names' (array) Optional. Field names to include in the search.
	 *                            - 's'           (string) Optional. General search term to match against `field_value`.
	 *
	 * @return array Array of associative arrays containing:
	 *               - 'entry_id' (int) The ID of each submission that matches the filters.
	 *               Returns an empty array if no submissions match.
	 *
	*/
	private function get_cfdb7_form_entries_submissions( $wpdb, $form_id, $search_input ) {
	    $table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
	    $table_name = str_replace("{form_id}", $form_id, $table_name);

	    $field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? array_map( 'sanitize_text_field', $search_input['field_names'] ) : array();
	    $search_value = isset($search_input['s']) ? sanitize_text_field($search_input['s']) : '';

	    $where_clauses = array();
	    // Field names filter
	    if ( ! empty($field_names) ) {
	        $placeholders = implode(',', array_fill(0, count($field_names), '%s'));
	        $where_clauses[] = $wpdb->prepare("field_name IN ($placeholders)", $field_names);
	    }

	    // Search value filter
	    if ( ! empty($search_value) ) {
	        $where_clauses[] = $wpdb->prepare("field_value LIKE %s", '%' . $wpdb->esc_like($search_value) . '%');
	    }

	    $where_sql = $where_clauses ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
		
	    return $wpdb->get_results("SELECT `entry_id` FROM {$table_name} {$where_sql}", ARRAY_A );
	}

	/**
	 * Retrieve detailed information for a specific CFDB7 form entry.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb     WordPress database abstraction object used for the query.
	 * @param int  $form_id  The Contact Form 7 form ID to which the entry belongs.
	 * @param int  $entry_ids The ID of the specific form entry to retrieve.
	 * @return array         array containing entry details. Returns empty if the entry is not found.                  
	*/
	public function get_cfdb7_form_entry_details($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} where entry_id=%d", $entry_id), ARRAY_A );
	}

	/**
	 * Retrieve CFDB7 entry details for a given form and a list of entry IDs.
	 *
	 * This method constructs the appropriate CFDB7 entry-details table name
	 * based on the provided form ID, converts the list of entry IDs into a
	 * comma-separated string, and queries the database for matching records.
	 *
	 * @since 1.0.0
	 * @param \wpdb   $wpdb      WordPress database abstraction object.
	 * @param int     $form_id   The ID of the form whose entry-details table will be queried.
	 * @param int[]   $entry_ids Array of entry IDs to fetch details for.
	 * @return array[] Array of associative arrays containing entry details.
	*/
	public function get_cfdb7_entry_ids_details($wpdb, $form_id, $entry_ids){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$entry_ids_str = implode(', ', array_fill(0, count($entry_ids), '%d'));
		return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where entry_id IN ($entry_ids_str)", $entry_ids), ARRAY_A );
	}

	/**
	 * Retrieve a single CFDB7 form entry submission for the given entry ID.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb     The WordPress database access abstraction object.
	 * @param int   $form_id  The ID of the CFDB7 form whose submission table should be queried.
	 * @param int   $entry_id The ID of the specific entry to retrieve.
	 * @return array          Associative array of the entry data if found, or empty if not.
	*/
	public function get_cfdb7_entry_ids_submissions($wpdb, $form_id, $entry_ids){	
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$entry_ids_str = implode(', ', array_fill(0, count($entry_ids), '%d'));
		return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} where entry_id IN ($entry_ids_str)", $entry_ids), ARRAY_A );
	}

	/**
	 * Save a deletion log entry for a specific CFDB7 form.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb   WordPress database abstraction object used to perform the insert.
	 * @param int   $form_id The Contact Form 7 form ID for which the deletion log is being saved.
	 * @param array $data    Associative array of column => value pairs to insert into the log table.
	 * @param array $format  Array of formats corresponding to the $data values. E.g., array('%s', '%d').
	 * @return int           The ID of the newly inserted row. Returns 0 if the insert fails.
	*/
	public function save_cfdb7_delete_entries_log($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Save a deleted form submission for a specific CFDB7 form.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb    WordPress database abstraction object used to perform the insert.
	 * @param int   $form_id The Contact Form 7 form ID for which the deleted submission is being saved.
	 * @param array $data    Associative array of column => value pairs to insert into the table.
	 * @param array $format  Array of formats corresponding to the $data values. E.g., array('%s', '%d').
	 * @return int           The ID of the newly inserted row. Returns 0 if the insert fails.
	*/
	public function save_cfdb7_delete_entries_submission($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Delete a CFDB7 form entry detail for a specific form.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb       WordPress database object.
	 * @param int  $form_id    The form ID used to determine the correct entries details table.
	 * @param int  $entry_id   The entry ID of the entry record to delete.
	*/
	public function delete_cfdb7_form_entry($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_details}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	}

	/**
	 * Delete a CFDB7 form submission entry for a specific form.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb       WordPress database object.
	 * @param int  $form_id    The form ID used to determine the correct submissions table.
	 * @param int  $entry_id   The entry ID of the submission record to delete.
	*/
	public function delete_cfdb7_form_submissions($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	}

	/**
	 * Save a CFDB7 export log entry for a specific form.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb     WordPress database object.
	 * @param int   $form_id  The form ID used to determine the correct export log table.
	 * @param array $data     Associative array of column => value pairs to insert.
	 * @param array $format   Optional. Array of formats for each value in $data (e.g., '%s', '%d').
	 * @return int            The ID of the newly inserted export log entry.
	*/
	public function save_cfdb7_export_log($wpdb, $form_id, $data, $format){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_export_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$wpdb->insert($table_name, $data, $format);
		return $wpdb->insert_id;
	}

	/**
	 * Get the total number of deleted CFDB7 log entries for a specific form.
	 *
	 * This method builds the dynamic delete log table name using the provided form ID
	 * and returns the total count of deleted entries stored in that table.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb     WordPress database object.
	 * @param int  $form_id  The form ID used to determine the correct delete log table.
	 *
	 * @return array         Returns an associative array with the key `count`
	 *                       containing the number of deleted entries.
	*/
	public function get_cfdb7_delete_entries_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row("SELECT count(`entry_id`) as count FROM {$table_name}", ARRAY_A );
	}

	/**
	 * Retrieve deleted CFDB7 log entries filtered by date range, field names, and/or search value.
	 *
	 * This method builds the dynamic delete log table name for the specified form and
	 * returns matching deleted log entries based on optional search parameters. It supports filtering by:
	 *
	 * - Date range (`from_date`, `to_date`)
	 * - Field names (`field_names`)
	 * - Search keyword (`s`) matched against field values in the deleted submissions log
	 *
	 * If field-related filters are used, this method internally queries the deleted submissions
	 * table via `get_cfdb7_delete_entries_submissions()` to obtain matching `entry_id`s.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb         WordPress database object.
	 * @param int   $form_id      Form ID used to determine the correct delete log table.
	 * @param array $search_input {
	 *     Optional. Array of filter options.
	 *
	 *     @type array  $field_names Array of field names to filter results.
	 *     @type string $s           Search string for matching submission field values.
	 *     @type string $from_date   Start date (Y-m-d).
	 *     @type string $to_date     End date (Y-m-d).
	 * }
	 * @return array Array of deleted log entries. 
	*/
	public function get_cfdb7_delete_entries($wpdb, $form_id, $search_input = array()){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($search_input)){
			$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
			$field_names = array_map( 'sanitize_text_field', (array) $field_names );
			$search_value = isset($search_input['s']) && !empty($search_input['s']) ? sanitize_text_field($search_input['s']) : "";
			$from_date = isset($search_input['from_date']) && !empty($search_input['from_date']) ? sanitize_text_field($search_input['from_date']) : "";
			$to_date = isset($search_input['to_date']) && !empty($search_input['to_date']) ? sanitize_text_field($search_input['to_date']) : "";

			$search_array = array();
			if(!empty($from_date) && !empty($to_date)){
				$from_date = date("Y-m-d", strtotime($from_date));
				$to_date = date("Y-m-d", strtotime($to_date));
				$search_array[] = $wpdb->prepare('date_time >= %s',$from_date . ' 00:00:00');
    			$search_array[] = $wpdb->prepare('date_time <= %s',$to_date . ' 23:59:59');
			}

			if(!empty($field_names) || !empty($search_value)){
				$entry_ids = $this->get_cfdb7_delete_entries_submissions($wpdb, $form_id, $search_input);
				$entry_ids = !empty($entry_ids) ? wp_list_pluck($entry_ids, 'entry_id') : array();
				if(!empty($entry_ids)){
					$entry_ids_str = implode(', ', array_fill(0, count($entry_ids), '%d'));
					$search_array[] = $wpdb->prepare("entry_id IN ($entry_ids_str)", $entry_ids);
				}
			}

			if(!empty($search_array)){
				$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";
				return $wpdb->get_results("SELECT * FROM {$table_name} where $search_str order by `id` desc", ARRAY_A );
			}else{
				return array();
			}
		}else{
			return $wpdb->get_results("SELECT * FROM {$table_name} order by `id` desc", ARRAY_A );
		}
	}

	/**
	 * Retrieve deleted CFDB7 submission log entries filtered by field names and/or search value.
	 *
	 * This method dynamically builds the delete submissions log table name using the provided
	 * form ID, applies optional filters based on field names and a search string, and
	 * returns matching deleted entry IDs from the submissions delete log table.
	 *
	 * Filters supported:
	 * - field_names: Limit results to specific meta fields.
	 * - s: A search term matched against the `field_value` column using LIKE.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb         WordPress database object.
	 * @param int   $form_id      The form ID used to determine the correct delete log table.
	 * @param array $search_input {
	 *     Optional search parameters.
	 *
	 *     @type array  $field_names Array of field names to filter by.
	 *     @type string $s           Search keyword for matching field values.
	 * }
	 *
	 * @return array Array of matching deleted entries, each containing `entry_id`.
	*/
	private function get_cfdb7_delete_entries_submissions($wpdb, $form_id, $search_input){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? array_map( 'sanitize_text_field', $search_input['field_names'] ) : array();
		$search_value = isset($search_input['s']) && !empty($search_input['s']) ? $search_input['s'] : "";

		$where_clauses = array();
	    // Field names filter
	    if ( ! empty($field_names) ) {
	        $placeholders = implode(',', array_fill(0, count($field_names), '%s'));
	        $where_clauses[] = $wpdb->prepare("field_name IN ($placeholders)", $field_names);
	    }

	    // Search value filter
	    if ( ! empty($search_value) ) {
	        $where_clauses[] = $wpdb->prepare("field_value LIKE %s", '%' . $wpdb->esc_like($search_value) . '%');
	    }

	    $where_sql = $where_clauses ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
		
	    return $wpdb->get_results("SELECT `entry_id` FROM {$table_name} {$where_sql}", ARRAY_A );
	}

	/**
	 * Delete a CFDB7 deleted entry log record for a specific form.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb       WordPress database object.
	 * @param int  $form_id    The form ID used to determine the correct delete log table.
	 * @param int  $entry_id   The entry ID of the deleted log record to remove.
	*/
	public function delete_cfdb7_entry_delete_log($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	}

	/**
	 * Delete a CFDB7 submission log entry for a specific form.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb       WordPress database object.
	 * @param int  $form_id    The form ID used to determine the correct log table.
	 * @param int  $entry_id   The entry ID of the submission log record to delete.
	*/
	public function delete_cfdb7_entry_submission_log($wpdb, $form_id, $entry_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_delete_entries_submissions}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$where_field_data = array(
			'entry_id' => $entry_id,
		);
		$where_field_format = array("%s");

		$wpdb->delete($table_name, $where_field_data, $where_field_format);
	} 

	/**
	 * Get the total number of CFDB7 log entries for a specific form.
	 *
	 * @since 1.0.0
	 * @param wpdb $wpdb     WordPress database object.
	 * @param int  $form_id  The form ID used to determine the correct log table.
	 * @return array         Returns an associative array with the key `count`
	 *                       containing the number of entries.
	*/
	public function get_cfdb7_log_entries_count($wpdb, $form_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row("SELECT count(`entry_id`) as count FROM {$table_name}", ARRAY_A );
	}

	/**
	 * Retrieve CFDB7 log entries filtered by date range, field names, and/or search value.
	 *
	 * This method builds the dynamic log table name for the specified form and returns
	 * matching log entries based on optional search parameters. It supports filtering by:
	 *
	 * - Date range (`from_date`, `to_date`)
	 * - Field names (`field_names`)
	 * - Search keyword (`s`) matched against field values in the submissions log
	 *
	 * If field-related filters are used, this method internally queries the submissions
	 * log table via `get_cfdb7_log_entries_submissions()` to obtain matching `entry_id`s.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb         WordPress database object.
	 * @param int   $form_id      Form ID used to determine the correct log table.
	 * @param array $search_input {
	 *     Optional. Array of filter options.
	 *
	 *     @type array  $field_names Array of field names to filter results.
	 *     @type string $s           A search string for matching submission field values.
	 *     @type string $from_date   Start date (Y-m-d).
	 *     @type string $to_date     End date (Y-m-d).
	 * }
	 *
	 * @return array Array of log entries. Each entry contains:
	 *               `id`, `lead_source`, `db7_forms_id`, `entry_id`,
	 *               `original_entry`, `original_entry_fields`, `date_time`.
	 *               Returns an empty array if no entries match the filters.
	*/
	public function get_cfdb7_log_entries($wpdb, $form_id, $search_input = array()){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		if(!empty($search_input)){
			$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? $search_input['field_names'] : array();
			$field_names = array_map( 'sanitize_text_field', (array) $field_names );
			$search_value = isset($search_input['s']) && !empty($search_input['s']) ? sanitize_text_field($search_input['s']) : "";
			$from_date = isset($search_input['from_date']) && !empty($search_input['from_date']) ? sanitize_text_field($search_input['from_date']) : "";
			$to_date = isset($search_input['to_date']) && !empty($search_input['to_date']) ? sanitize_text_field($search_input['to_date']) : "";

			$search_array = array();
			if(!empty($from_date) && !empty($to_date)){
				$from_date = date("Y-m-d", strtotime($from_date));
				$to_date = date("Y-m-d", strtotime($to_date));
				$search_array[] = $wpdb->prepare('date_time >= %s',$from_date . ' 00:00:00');
    			$search_array[] = $wpdb->prepare('date_time <= %s',$to_date . ' 23:59:59');
			}

			if(!empty($field_names) || !empty($search_value)){
				$entry_ids = $this->get_cfdb7_log_entries_submissions($wpdb, $form_id, $search_input);
				$entry_ids = !empty($entry_ids) ? wp_list_pluck($entry_ids, 'entry_id') : array();
				if(!empty($entry_ids)){
					$entry_ids_str = implode(', ', array_fill(0, count($entry_ids), '%d'));
					$search_array[] = $wpdb->prepare("entry_id IN ($entry_ids_str)", $entry_ids);
				}
			}

			if(!empty($search_array)){
				$search_str = !empty($search_array) ? implode(" AND ",$search_array) : "";
				return $wpdb->get_results("SELECT `id`,`lead_source`,`db7_forms_id`,`entry_id`,`original_entry`,`original_entry_fields`,`date_time` FROM {$table_name} where $search_str order by `id` desc", ARRAY_A );
			}else{
				return array();
			}
		}else{
			return $wpdb->get_results("SELECT `id`,`lead_source`,`db7_forms_id`,`entry_id`,`original_entry`,`original_entry_fields`,`date_time` FROM {$table_name} order by `id` desc", ARRAY_A );
		}
	}

	/**
	 * Retrieve CFDB7 submission log entries filtered by field names and/or search value.
	 * Filters supported:
	 * - field_names: Limit results to specific meta fields.
	 * - s: A search term matched against the `field_value` column using LIKE.
	 *
	 * @since 1.0.0
	 * @param wpdb  $wpdb         WordPress database object.
	 * @param int   $form_id      The form ID used to determine the correct log table.
	 * @param array $search_input {
	 *     Optional search parameters.
	 *
	 *     @type array  $field_names Array of field names to filter by.
	 *     @type string $s           Search keyword for matching field values.
	 * }
	 * @return array Array of matching entries, each containing `entry_id`.
	*/
	private function get_cfdb7_log_entries_submissions($wpdb, $form_id, $search_input){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_submissions_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		$field_names = isset($search_input['field_names']) && !empty($search_input['field_names']) ? array_map( 'sanitize_text_field', $search_input['field_names'] ) : array();
		$search_value = isset($search_input['s']) && !empty($search_input['s']) ? sanitize_text_field($search_input['s']) : "";

		$where_clauses = array();
	    // Field names filter
	    if ( ! empty($field_names) ) {
	        $placeholders = implode(',', array_fill(0, count($field_names), '%s'));
	        $where_clauses[] = $wpdb->prepare("field_name IN ($placeholders)", $field_names);
	    }

	    // Search value filter
	    if ( ! empty($search_value) ) {
	        $where_clauses[] = $wpdb->prepare("field_value LIKE %s", '%' . $wpdb->esc_like($search_value) . '%');
	    }

	    $where_sql = $where_clauses ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
		
	    return $wpdb->get_results("SELECT `entry_id` FROM {$table_name} {$where_sql}", ARRAY_A );
	}

	/**
	 * Retrieve a single CFDB7 log entry by form ID and entry index.
	 *
	 * @since 1.0.0
	 * @param wpdb   $wpdb     Global WordPress database access abstraction object.
	 * @param int    $form_id  The ID of the form whose log table should be queried.
	 * @param int    $index_id The primary key (ID) of the specific log entry to retrieve.
	 * @return array|          Returns the log entry as an associative array if found,
	 *                         otherwise empty.
	*/
	public function get_cfdb7_log_entry($wpdb, $form_id, $index_id){
		$table_name = "{$wpdb->prefix}{$this->cfdb7_entries_log}";
		$table_name = str_replace("{form_id}",$form_id,$table_name);

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} where id=%d", $index_id), ARRAY_A );
	}
}