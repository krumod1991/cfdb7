<?php

/**
 * Fired during plugin activation
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/includes
 * @author     Pinky dev
 */
class Cfdb7_Pro_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		global $wpdb;
		if (function_exists('is_multisite') && is_multisite()) {
			$current_blog = $wpdb->blogid;
			// Get all blog ids
			$blog_ids = $wpdb->get_col("SELECT blog_id FROM $wpdb->blogs");
			foreach ($blog_ids as $blog_id){
				switch_to_blog($blog_id);
				add_lead_source_column();
				cfdb7_generate_basic_tables();
                cfdb7_generate_entries_table();
			}
			switch_to_blog($current_blog);
		}else{
			add_lead_source_column();
			cfdb7_generate_basic_tables();
            cfdb7_generate_entries_table();
		}
	}
}
