<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Prepare available forms for entry indexing and render the indexing entries UI.
 *
 * This logic filters forms to only those available for indexing, sets up the UI for selecting a form,
 * verifies nonce for security, and displays the indexing button for valid forms. Handles admin notices
 * and error states for security checks. Also includes popup progress bar for indexing feedback.
 *
 * Coding Guide:
 * - Only include forms with available entries for indexing.
 * - Sanitize all input and output data.
 * - Use wp_nonce_field and wp_verify_nonce for security against CSRF.
 * - Use esc_html, esc_attr, and selected() for safe output.
 * - Provide clear admin notices for success and error states.
 * - Enqueue required styles and scripts for UI and popup functionality.
 *
 * @since 1.0.0
 * @param array $forms_list List of all available forms.
 * @param array $db7_form_ids List of form IDs available for indexing.
 * @param int $_GET['cf7-id'] Selected form ID for indexing.
 * @param string $_GET['nonce'] Nonce for security verification.
*/

global $wpdb;
$obj = new Cfdb7_Queries();
$obj->init_cfdb7_tables();

$db7_form_ids = $obj->get_db7_available_form_post_ids($wpdb);
$db7_form_ids = !empty($db7_form_ids) ? wp_list_pluck($db7_form_ids, 'form_ids') : array();

wp_enqueue_style('cfdb7_indexing_entries_style');
wp_enqueue_script('cfdb7_indexing_entries_script');
wp_enqueue_style('cfdb7_magnific_popup_style');
wp_enqueue_script('cfdb7_magnific_popup_script');

$cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? intval($_GET['cf7-id']) : "";
$nonce = isset($_GET['nonce']) && !empty($_GET['nonce']) ? sanitize_text_field($_GET['nonce']) : "";
?>
<div class="wrap cfdb7-indexing-entries">
	<div class="loader" style="display:none;">
		<div class="loader-icon"></div>
	</div>
	<div class="notice" style="display:none;"><p id="notice"></p></div>
    <h1 class="wp-heading-inline"><?php echo esc_html__('Indexing Entries', 'cfdb7-pro'); ?></h1>
	<table class="form-table">
		<tr class="form-field">
			<th><label for="cf7-id"><?php echo esc_html__('Select Form', 'cfdb7-pro'); ?></label></th>
			<td>
				<select name="cf7-id" id="cf7-id">
					<option value=""><?php echo esc_html__('Select Form', 'cfdb7-pro'); ?></option>
					<?php 
					if(!empty($forms_list) && !empty($db7_form_ids)){
						foreach($forms_list as $form){		
							if(in_array($form->ID, $db7_form_ids)){
								?><option value="<?php echo $form->ID; ?>" <?php selected($cf7_id, $form->ID); ?>><?php echo $form->post_title; ?></option><?php
							}
						}
					}
					?>
				</select>
				<?php wp_nonce_field('indexing_entries_page', 'indexing_entries_page_nonce'); ?>
			</td>
		</tr>
		<?php 
		if(!empty($cf7_id) && !empty($nonce)){
			if(wp_verify_nonce($nonce, 'indexing_entries_page')){
				?>
				<tr class="form-field">
					<th></th>
					<td><button type="button" id="cfdb7-indexing" class="button button-primary"><?php echo esc_html__('Indexing', 'cfdb7-pro'); ?></button><?php wp_nonce_field('indexing_entries', 'indexing_entries_nonce'); ?></td>
				</tr>
				<?php
			}else{
				?>
				<tr class="form-field">
					<th></th>
					<td><div class="notice notice-error"><p><?php echo esc_html__( 'Security check failed. Please try again.', 'cfdb7-pro' ); ?></p></div></td>
				</tr>
				<?php
			}
		}
		?>
	</table>
</div>
<div id="popup-content" class="mfp-hide">
    <div class="modal-box">
        <div class="modal-header">
            <h2><?php echo esc_html__('Processing Request', 'cfdb7-pro'); ?></h2>
        </div>
        <div class="modal-body">
            <div class="processing-text">
                <?php echo esc_html__('Your request is being processed. Please wait...', 'cfdb7-pro'); ?>
            </div>
            <div class="progress-bar-container">
                <div class="progress-bar"></div>
            </div>
        </div>
    </div>
</div>
