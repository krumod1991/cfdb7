<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}
/**
 * Main logic block for displaying the plugin activation notice in the admin area.
 *
 * - Renders a warning notice prompting the user to activate the required Contact Form 7 Database Addon (CFDB7).
 * - Provides a secure, translatable link to the WordPress plugin download page.
 * - Uses WordPress translation functions for all user-facing text.
 *
 * Coding Guide:
 * - Use semantic HTML and appropriate class names for admin notices.
 * - Always use esc_html__ for translatable strings and esc_html for output.
 * - Use target="_blank" for external links and ensure the URL is trusted.
 *
 * @since 1.0.0
 */
?>
<div class="notice notice-warning">
	<p><?php echo esc_html__('Please activate the Contact Form 7 Database Addon – CFDB7 to ensure full functionality.', 'cfdb7-pro'); ?> <a href="https://wordpress.org/plugins/contact-form-cfdb7/" target="_blank"><?php echo esc_html__('Click here to download it.', 'cfdb7-pro'); ?></a></p>
</div>