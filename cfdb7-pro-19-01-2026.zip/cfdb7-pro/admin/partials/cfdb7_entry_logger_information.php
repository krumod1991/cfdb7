<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Render detailed logger information for a specific Contact Form 7 entry.
 *
 * This logic verifies nonce for security, retrieves logger entry data, and displays form settings,
 * original entry, and proceed entry details in a structured table format. Handles file fields with download links
 * and provides admin notices for error states. All input and output is sanitized for security.
 *
 * Coding Guide:
 * - Sanitize all input and output data.
 * - Use wp_verify_nonce for security against CSRF.
 * - Use esc_html, esc_attr, and esc_url for safe output.
 * - Provide clear admin notices for error states.
 * - Display original and proceed entry data in tables.
 * - Handle file fields with download links.
 *
 * @since 1.0.0
 * @param int $_POST['cf7_id'] Selected form ID for logger entry.
 * @param string $_POST['nonce'] Nonce for security verification.
 * @param int $_POST['index'] Entry index to display.
*/

$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? sanitize_text_field($_POST['cf7_id']) : "";
$cf7_id = !empty($cf7_id) ? intval($cf7_id) : "";

$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";

$index = isset($_POST['index']) && !empty($_POST['index']) ? sanitize_text_field($_POST['index']) : "";
$index = !empty($index) ? intval($index) : "";

if(!empty($cf7_id) && !empty($nonce) && !empty($index)){
	if(wp_verify_nonce($nonce, 'entries_logger_page')){
		global $wpdb;
		$obj = new Cfdb7_Queries();
		$obj->init_cfdb7_tables();

		$logger_entry = $get_setting = $obj->get_cfdb7_log_entry($wpdb, $cf7_id, $index);
		if(!empty($logger_entry)){
			$form_settings = isset($logger_entry['form_setting']) && !empty($logger_entry['form_setting']) ? maybe_unserialize($logger_entry['form_setting']) : array();
			$form_settingss = !empty($form_settingss) ? array_map('sanitize_text_field', $form_settingss) : array();
			
			$avoid_duplicate_submission = "";
			$avoid_field = "";
			$excludes_fields = "";
			if(!empty($form_settings)){
				$avoid_duplicate_submission = isset($form_settings['avoid_duplicate_submission']) && !empty($form_settings['avoid_duplicate_submission']) ? sanitize_text_field($form_settings['avoid_duplicate_submission']) : "off";
				
				$avoid_field = isset($form_settings['avoid_field']) && !empty($form_settings['avoid_field']) ? sanitize_text_field($form_settings['avoid_field']) : "";
				
				$excludes_fields = isset($form_settings['excludes_fields']) && !empty($form_settings['excludes_fields']) ? array_map('sanitize_text_field', $form_settings['excludes_fields']) : array();
				$excludes_fields = !empty($excludes_fields) ? implode(",", $excludes_fields) : "";
			}

			$lead_source = isset($logger_entry['lead_source']) && !empty($logger_entry['lead_source']) ? esc_html($logger_entry['lead_source']) : "";

			$submit_by = isset($logger_entry['display_name']) && !empty($logger_entry['display_name']) ? esc_html($logger_entry['display_name']) : "";

			$date_time = isset($logger_entry['date_time']) && !empty($logger_entry['date_time']) ? esc_html(date("d-m-Y H:i:s", strtotime($logger_entry['date_time']))) : "";

			$ip_address = isset($logger_entry['ip_address']) && !empty($logger_entry['ip_address']) ? esc_html($logger_entry['ip_address']) : "";
			?>
			<table border="1" class="logger-setting-information">
				<tr>
					<td><?php echo esc_html__('Ignore duplicate entry', 'cfdb7-pro'); ?></td>
					<td><?php echo $avoid_duplicate_submission; ?></td>
				</tr>
				<tr>
					<td><?php echo esc_html__('Ignore duplicate entry field', 'cfdb7-pro'); ?></td>
					<td><?php echo $avoid_field; ?></td>
				</tr>
				<tr>
					<td><?php echo esc_html__('Exclude fields', 'cfdb7-pro'); ?></td>
					<td><?php echo $excludes_fields; ?></td>
				</tr>
				<tr>
					<td><?php echo esc_html__('Lead source', 'cfdb7-pro'); ?></td>
					<td><?php echo $lead_source; ?></td>
				</tr>
				<tr>
					<td><?php echo esc_html__('Submit by', 'cfdb7-pro'); ?></td>
					<td><?php echo $submit_by; ?></td>
				</tr>
				<tr>
					<td><?php echo esc_html__('Date time', 'cfdb7-pro'); ?></td>
					<td><?php echo $date_time; ?></td>
				</tr>
				<tr>
					<td><?php echo esc_html__('Ip address', 'cfdb7-pro'); ?></td>
					<td><?php echo $ip_address; ?></td>
				</tr>
			</table>
			<?php

			$original_entry = isset($logger_entry['original_entry']) && !empty($logger_entry['original_entry']) ? maybe_unserialize($logger_entry['original_entry']) : array();
			$original_entry = !empty($original_entry) ? array_map('sanitize_text_field', $original_entry) : array();

			$original_entry_fields = isset($logger_entry['original_entry_fields']) && !empty($logger_entry['original_entry_fields']) ? maybe_unserialize($logger_entry['original_entry_fields']) : array();
			$original_entry_fields = !empty($original_entry_fields) ? array_map('sanitize_text_field', $original_entry_fields) : array();

			if(!empty($original_entry)){
				?>
				<h3><?php echo esc_html__('Original Entry', 'cfdb7-pro'); ?></h3>
				<table border="1" class="logger-original-information">
					<thead>
						<tr>
							<th><?php echo esc_html__('Field Name', 'cfdb7-pro'); ?></th>
							<th><?php echo esc_html__('Field Value', 'cfdb7-pro'); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php 
						foreach($original_entry as $entry_name => $entry_value){
							$field_type = isset($original_entry_fields[$entry_name]) && !empty($original_entry_fields[$entry_name]) ? esc_html($original_entry_fields[$entry_name]) : '';
							if($field_type == 'file'){
								$entry_value = '<a href="'.esc_url($entry_value).'" target="_blank">'.esc_html(basename($entry_value)).'</a>';
							}else{
								$entry_value = esc_html($entry_value);
							}
							?>
							<tr>
								<td><?php echo $entry_name; ?></td>
								<td><?php echo $entry_value; ?></td>
							</tr>
							<?php
						}
						?>
					</tbody>
				</table>
				<?php
			}

			$proceed_entry = isset($logger_entry['proceed_entry']) && !empty($logger_entry['proceed_entry']) ? maybe_unserialize($logger_entry['proceed_entry']) : array();
			$proceed_entry = !empty($proceed_entry) ? array_map('sanitize_text_field', $proceed_entry) : array();

			$proceed_entry_fields = isset($logger_entry['proceed_entry_fields']) && !empty($logger_entry['proceed_entry_fields']) ? maybe_unserialize($logger_entry['proceed_entry_fields']) : array();
			$proceed_entry_fields = !empty($proceed_entry_fields) ? array_map('sanitize_text_field', $proceed_entry_fields) : array();

			if(!empty($proceed_entry)){
				?>
				<h3><?php echo esc_html__('Proceed Entry', 'cfdb7-pro'); ?></h3>
				<table border="1" class="logger-proceed-information">
					<thead>
						<tr>
							<th><?php echo esc_html__('Field Name', 'cfdb7-pro'); ?></th>
							<th><?php echo esc_html__('Field Value', 'cfdb7-pro'); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php 
						foreach($proceed_entry as $entry_name => $entry_value){
							$field_type = isset($proceed_entry_fields[$entry_name]) && !empty($proceed_entry_fields[$entry_name]) ? esc_html($proceed_entry_fields[$entry_name]) : '';
							if($field_type == 'file'){
								$entry_value = '<a href="'.esc_url($entry_value).'" target="_blank">'.esc_html(basename($entry_value)).'</a>';
							}else{
								$entry_value = esc_html($entry_value);
							}
							?>
							<tr>
								<td><?php echo $entry_name; ?></td>
								<td><?php echo $entry_value; ?></td>
							</tr>
							<?php
						}
						?>
					</tbody>
				</table>
				<?php
			}
		}
	}else{
		?>
		<div class="notice notice-error"><p><?php echo esc_html__( 'Security check failed. Please try again.', 'cfdb7-pro' ); ?></p></div>
		<?php
	}
}