<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Prepare export of selected entry IDs for Contact Form 7 submissions.
 *
 * This logic verifies nonce for security, chunks entry IDs for export, and outputs hidden fields for each chunk.
 * Handles referer URL for navigation and provides a progress bar for export feedback. All input and output is sanitized for security.
 *
 * Coding Guide:
 * - Sanitize all input and output data.
 * - Use wp_verify_nonce for security against CSRF.
 * - Use esc_html, esc_attr, and esc_url for safe output.
 * - Chunk entry IDs for efficient export processing.
 * - Provide progress bar UI for export feedback.
 *
 * @since 1.0.0
 * @param int $_POST['cf7-id'] Selected form ID for export.
 * @param string $_POST['cfdb7_entries_nonce'] Nonce for security verification.
 * @param array $_POST['ids'] Entry IDs to export.
 * @param string $_POST['page'] Export context.
*/

$cf7_id = isset($_POST['cf7-id']) && !empty($_POST['cf7-id']) ? sanitize_text_field($_POST['cf7-id']) : "";
$cf7_id = !empty($cf7_id) ? intval($cf7_id) : "";

$nonce = isset($_POST['cfdb7_entries_nonce']) && !empty($_POST['cfdb7_entries_nonce']) ? sanitize_text_field($_POST['cfdb7_entries_nonce']) : "";

$entry_ids = isset($_POST['ids']) && !empty($_POST['ids']) ? array_map('sanitize_text_field', $_POST['ids']) : array();
$entry_ids = !empty($entry_ids) ? array_map('intval', $entry_ids) : array();

$context = isset($_POST['page']) && !empty($_POST['page']) ? sanitize_text_field($_POST['page']) : "";
if(!empty($cf7_id) && !empty($nonce) && !empty($entry_ids) && !empty($context)){
    if(wp_verify_nonce( $nonce, 'cfdb7_entries_'.$cf7_id )){
        $chunk_size = 100;
        $chunk_size = apply_filters( 'cfdb7_export_entries_chunk_size', $chunk_size );
        //Split entry ids into chunks
        $chunk_ids = array_chunk($entry_ids, $chunk_size);

        $referer_url = isset($_POST['_wp_http_referer']) ? wp_unslash($_POST['_wp_http_referer']) : '';
        ?>
        <div class="wrap cfdb7-export-entries">
            <div id="notice"></div>
            <input type="hidden" id="cf7-id" value="<?php echo esc_attr($cf7_id); ?>" />
            <input type="hidden" id="cfdb7_entries_nonce" value="<?php echo esc_attr($nonce); ?>" />
            <input type="hidden" id="context" value="<?php echo esc_attr($context); ?>" />
            <input type="hidden" id="referer_url" value="<?php echo esc_url($referer_url); ?>" />
            <?php 
            foreach($chunk_ids as $key => $ids){ 
                ?>
                <input type="hidden" class="entries-export-entry-ids" data-index="<?php echo esc_attr($key + 1); ?>" value="<?php echo esc_attr(implode(",", $ids)); ?>" />
                <?php 
            } 
            ?>
        </div>
        <div id="popup-content" class="mfp-hide">
            <div class="modal-box">
                <div class="modal-header">
                    <h2><?php echo esc_html__('Processing Request', 'cfdb7-pro'); ?></h2>
                </div>
                <div class="modal-body">
                    <div class="processing-text">
                        <?php echo esc_html__('Your request is being processed. Please wait...', 'cfdb7-pro'); ?>
                    </div>
                    <div class="progress-bar-container">
                        <div class="progress-bar"></div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }else{
        ?>
        <div class="notice notice-error"><p><?php echo esc_html__( 'Security check failed. Please try again.', 'cfdb7-pro' ); ?></p></div>
        <?php
    }
    
}
?>