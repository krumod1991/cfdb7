<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Prepare allowed forms for indexing and render the indexing field names UI.
 *
 * This logic filters forms to only those with entries, sets up the UI for selecting a form,
 * verifies nonce for security, and displays the indexing button for valid forms.
 * Handles admin notices and error states for security checks.
 *
 * Coding Guide:
 * - Only include forms with entries for indexing.
 * - Sanitize all input and output data.
 * - Use wp_nonce_field and wp_verify_nonce for security against CSRF.
 * - Use esc_html, esc_attr, and selected() for safe output.
 * - Provide clear admin notices for success and error states.
 * - Enqueue required styles and scripts for UI functionality.
 *
 * @since 1.0.0
 * @param array $forms_list List of all available forms.
 * @param int $_GET['cf7-id'] Selected form ID for indexing.
 * @param string $_GET['nonce'] Nonce for security verification.
*/

global $wpdb;
$obj = new Cfdb7_Queries();
$obj->init_cfdb7_tables();

$allowed_form_ids = array();

if(!empty($forms_list)){
	foreach($forms_list as $form){
		$entries_count = $obj->get_cfdb7_form_entries_count($wpdb, $form->ID);
		if(!empty($entries_count)){
			if($entries_count['count'] > 0){
				$allowed_form_ids[] = $form;
			}
		}			
	}
}

wp_enqueue_style('cfdb7_indexing_field_names_style');
wp_enqueue_script('cfdb7_indexing_field_names_script');

$cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? intval($_GET['cf7-id']) : "";
$nonce = isset($_GET['nonce']) && !empty($_GET['nonce']) ? sanitize_text_field($_GET['nonce']) : "";
?>
<div class="wrap cfdb7-indexing-field-names">
	<div class="loader" style="display:none;">
		<div class="loader-icon"></div>
	</div>
	<div class="notice notice-1" style="display:none;"><p id="notice-1"></p></div>
	<div class="notice notice-2" style="display:none;"><p id="notice-2"></p></div>
	<div class="notice notice-3" style="display:none;"><p id="notice-3"></p></div>
    <h1 class="wp-heading-inline"><?php echo esc_html__('Indexing Field Names', 'cfdb7-pro'); ?></h1>
	<table class="form-table">
		<tr class="form-field">
			<th><label for="cf7-id"><?php echo esc_html__('Select Form', 'cfdb7-pro'); ?></label></th>
			<td>
				<select name="cf7-id" id="cf7-id">
					<option value=""><?php echo esc_html__('Select Form', 'cfdb7-pro'); ?></option>
					<?php 
					if(!empty($allowed_form_ids)){
						foreach($allowed_form_ids as $form){							
							?><option value="<?php echo $form->ID; ?>" <?php selected($cf7_id, $form->ID); ?>><?php echo $form->post_title; ?></option><?php
						}
					}
					?>
				</select>
				<?php wp_nonce_field('indexing_field_name_page', 'indexing_field_name_page_nonce'); ?>
			</td>
		</tr>
		<?php 
		if(!empty($cf7_id) && !empty($nonce)){
			if(wp_verify_nonce($nonce, 'indexing_field_name_page')){
				?>
				<tr class="form-field">
					<th></th>
					<td><button type="button" id="cfdb7-indexing" class="button button-primary"><?php echo esc_html__('Indexing Entries', 'cfdb7-pro'); ?></button><?php wp_nonce_field('indexing_field_names', 'indexing_field_names_nonce'); ?></td>
				</tr>
				<?php
			}else{
				?>
				<tr class="form-field">
					<th></th>
					<td><div class="notice notice-error"><p><?php echo esc_html__( 'Security check failed. Please try again.', 'cfdb7-pro' ); ?></p></div></td>
				</tr>
				<?php
			}
		}
		?>
	</table>
</div>
