<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

$singular = $this->_args['singular'];
$this->display_tablenav('top');
?>
<table id="<?php echo $this->list_table_id; ?>" class="wp-list-table <?php echo implode(' ', $this->get_table_classes()); ?>">
    <thead>
        <?php $this->print_column_headers(); ?>
    </thead>

    <tbody id="the-list"
        <?php
        if ( $singular ) {
            echo " data-wp-lists='list:$singular'";
        }
        ?>>
        <?php $this->display_rows_or_placeholder(); ?>
    </tbody>

    <tfoot>
        <?php $this->print_column_headers(false); ?>
    </tfoot>
</table>
<?php
$this->display_tablenav('bottom');