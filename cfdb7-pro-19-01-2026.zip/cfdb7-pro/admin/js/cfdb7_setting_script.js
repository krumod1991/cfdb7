jQuery(document).ready(function () {
    jQuery("#cf7-id").change(function () {
        var cf7_id = jQuery(this).val();
        var nonce = jQuery("#cfdb7_setting_page_nonce").val();
        var current_url = new URL(window.location.href);
        current_url.searchParams.delete('cf7-id');
        if (cf7_id != "") {
            window.location = current_url + '&cf7-id=' + cf7_id + '&nonce=' + nonce;
        } else {
            window.location = current_url;
        }
    });

    jQuery('#excludes-fields').select2({
        width: '100%',                       // full width
        placeholder: cfdb7_params.chosen_placeholder, // placeholder text
        language: {
            noResults: function () {
                return cfdb7_params.chosen_no_results; // no results text
            }
        },
        matcher: function (params, data) {
            // search_contains = true equivalent
            if (jQuery.trim(params.term) === '') {
                return data;
            }

            if (data.text.toLowerCase().indexOf(params.term.toLowerCase()) > -1) {
                return data;
            }

            return null;
        }
    })
});