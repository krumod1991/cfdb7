jQuery(document).ready(function () {
    //Add logic for handling no items row error when DataTable will initialize
    jQuery('#cfdb7-export-entries tr.no-items').remove();

    setTimeout(function () {
        new DataTable('#cfdb7-export-entries', {
            responsive: true,
            pageLength: -1,      // show all records
            lengthChange: false, // remove entries-per-page dropdown
            paging: false,       // remove pagination controls
            searching: false,     // remove search box
            info: false          // remove "Showing X to Y of Z entries"
        });
    }, 300);

    jQuery("#cf7-id").change(function () {
        var cf7_id = jQuery(this).val();
        var nonce = jQuery("#cfdb7_export_logs_page_nonce").val();
        var current_url = new URL(window.location.href);
        current_url.searchParams.delete('cf7-id');
        if (cf7_id != "" && nonce != "") {
            window.location = current_url + '&cf7-id=' + cf7_id + '&nonce=' + nonce;
        } else {
            window.location = current_url;
        }
    });

    if (jQuery('#from_date').length > 0 && jQuery('#to_date').length > 0) {
        jQuery('#from_date, #to_date').datepicker({
            dateFormat: 'dd-mm-yy'
        });
    }

    // Reset settings - reload page with only page and cf7-id params
    jQuery(document).on('click', '.reset-settings', function () {
        var currentUrl = new URL(window.location.href);
        var page = currentUrl.searchParams.get('page');
        var cf7Id = currentUrl.searchParams.get('cf7-id');
        var nonce = currentUrl.searchParams.get('nonce');

        var resetUrl = currentUrl.origin + currentUrl.pathname + '?page=' + page;
        if (cf7Id != "" && nonce != "") {
            resetUrl += '&cf7-id=' + cf7Id + '&nonce=' + nonce;
        }

        window.location.href = resetUrl;
    });
});