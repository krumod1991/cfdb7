<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/public
*/

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/public
 * @author     Krunal Modi
*/
class Cfdb7_Pro_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	*/
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	*/
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	*/
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	*/
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Cfdb7_Pro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Cfdb7_Pro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/cfdb7-pro-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	*/
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Cfdb7_Pro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Cfdb7_Pro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/cfdb7-pro-public.js', array( 'jquery' ), $this->version, false );

	}

	/**
     * Save form entry data to the database.
     *
     * This function processes and saves a form submission entry, applying field settings,
     * sanitizing and validating data, logging the entry, and updating available field information.
     * It also triggers hooks for extensibility and ensures all data is securely handled.
     *
     * @param int   $db7_forms_id   The ID of the form submission.
     * @param array $form_data      The data submitted through the form.
     *
     * Coding Guide:
     * - Always cast IDs to integers and validate input data.
     * - Sanitize all field data before processing or saving.
     * - Apply form settings and field types before saving.
     * - Use hooks (do_action) for extensibility before saving.
     * - Log all entry actions and update report field information.
     * - Use WordPress database and escaping functions for all operations.
     *
     * @since    1.0.0
    */
	public function cfdb7_save_entry($db7_forms_id, $form_data){
		global $wpdb;
		$obj = new Cfdb7_Queries();
		$obj->init_cfdb7_tables();

		$db7_forms_id = intval($db7_forms_id);
		if(!empty($db7_forms_id)){
			$entry_info = $obj->get_db7_forms_entry($wpdb, $db7_forms_id);
			if(!empty($entry_info)){
				$cf7_id = isset($entry_info['form_post_id']) && !empty($entry_info['form_post_id']) ? intval($entry_info['form_post_id']) : "";//It is called cf7_id

				$field_data = isset($entry_info['form_value']) && !empty($entry_info['form_value']) ? maybe_unserialize($entry_info['form_value']) : array();
				
				$form_date = isset($entry_info['form_date']) && !empty($entry_info['form_date']) ? sanitize_text_field($entry_info['form_date']) : "";
				
				if(!empty($cf7_id) && !empty($field_data) && !empty($form_date)){
					$lead_source = "cf7";
					//Get CF7 form tags
					$tags = cfdb7_get_form_tags($cf7_id);
					//Set fields list
					$cf7_tags = array();
					if(!empty($tags)){
						foreach ( $tags as $tag ){
							if(!empty($tag->name)){
								$safe_name = "";
								$safe_type = "";
								if($tag->basetype == "file"){
									$safe_name = sanitize_text_field($tag->name.'cfdb7_file');
									$safe_type = sanitize_text_field($tag->basetype);
								}else{
									$safe_name = sanitize_text_field($tag->name);
									$safe_type = sanitize_text_field($tag->basetype);
								}
								$cf7_tags[$safe_name] = $safe_type;
							}
						}
					}

					//$form_setting use to applied setting to form data
					$form_setting = cfdb7_get_form_setting($wpdb, $obj, $cf7_id);

					$original_field_data = $field_data;
					//Sanitize existing field data
					$original_field_data = cfdb7_sanitize_field_data($original_field_data);
					$field_data = cfdb7_sanitize_field_data($field_data);

					//Update upload file path
					$upload_dir    = wp_upload_dir();
        			$cfdb7_dir_url = $upload_dir['baseurl'].'/cfdb7_uploads';
					
					$original_field_data = cfdb7_update_upload_file_path($original_field_data, $cfdb7_dir_url);
					$field_data = cfdb7_update_upload_file_path($field_data, $cfdb7_dir_url);
					
					if(!empty($original_field_data)){
						if(isset($original_field_data['cfdb7_status'])){
							unset($original_field_data['cfdb7_status']);
						}
					}

					//Apply field type processing
					$original_entry_fields = cfdb7_form_data_after_applied_field_type($field_data, $cf7_tags);			

					$logger = array();
					$logger['date_time'] = $form_date;
					$logger['lead_source'] = $lead_source;
					$logger['form_setting'] = $form_setting;
					$logger['db7_forms_id'] = $db7_forms_id;
					$logger['original_entry'] = $field_data;
					$logger['original_entry_fields'] = $original_entry_fields;
					$logger['form_entry'] = sanitize_textarea_field($entry_info);
					$logger['display_name'] = "";
					$logger['ip_address'] = $ip_address;
					
					//Validate entry with form settings
					$field_data = cfdb7_form_data_after_applied_settings($field_data, $form_setting, $cf7_id, $obj, $wpdb);
					$logger['proceed_entry'] = $field_data;

					$before_entry = array(
						'entry_info' => $entry_info,
						'field_data' => $field_data,
						'cf7_tags' => $cf7_tags,
						'cf7_id' => $cf7_id,
						'db7_forms_id' => $db7_forms_id,
						'form_setting' => $form_setting,
						'obj' => $obj,
						'wpdb' => $wpdb,
					);
					do_action( 'cfdb7_before_save_entry', $before_entry);

					$ip_address = cfdb7_get_ip_address();

					$cfdb7_data = array(
						'field_data' => $field_data,
						'cf7_tags' => $cf7_tags,
						'cf7_id' => $cf7_id,
						'db7_forms_id' => $db7_forms_id,
						'form_date' => $form_date,
						'lead_source' => $lead_source,
						'user_id' => "",
						'display_name' => "",
						'ip_address' => $ip_address,
						'original_field_data' => $original_field_data,
					);
					$entry_result = cfdb7_proceed_save_entry($wpdb, $obj, $cfdb7_data);

					$logger['proceed_entry_fields'] = $entry_result['proceed_entry_fields'];
					$logger['entry_id'] = $entry_result['entry_id'];
					$logger['entry_details'] = $entry_result['entry_details'];
					

					//Save report field information 
					$available_fields = array_keys($original_field_data);
					$available_fields = array_map('sanitize_text_field', $available_fields);
					cfdb7_save_report_field_for_field_name_options($available_fields, $cf7_id, $obj, $wpdb);

					//Save logs for submissions
					$obj->save_entry_log($wpdb, $cf7_id, $logger);
				}
			}
		}
	}
}
