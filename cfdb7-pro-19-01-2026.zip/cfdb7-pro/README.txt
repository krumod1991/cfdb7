=== Plugin Name ===
Contributors: krumod
Tags: contact form 7, Contact Form 7 Database, contact form 7 db, cfdb7 pro, contact form 7 addon
Requires at least: 5.0
Tested up to: 6.9
Requires PHP: 7.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
 
CFDB7 Pro Addon extends the Contact Form 7 Database Addon – CFDB7 with powerful tools to manage, search, export, restore, import, and optimize form entries with multisite and multilingual support.
 
== Description ==
 
**CFDB7 Pro Addon** works alongside the **Contact Form 7 Database Addon – CFDB7** plugin.  
It does **not modify the original CFDB7 plugin**. Instead, it adds advanced features to make managing Contact Form 7 entries easier, faster, and more powerful.
 
This addon is ideal for websites that need:
* Advanced entry management
* Multisite support
* Multilingual compatibility
* Import, export, and restore functionality
 
== Features ==
 
### 1. CFDB7 Entries
View and manage all Contact Form 7 submissions, including imported and indexed entries.
 
**Features:**
* Filter entries by submission date
* Keyword search (name, email, text, etc.)
* Search by specific field name (email, phone, name, etc.)
* Clear field name display in reports
* Bulk delete entries
* Bulk export entries
* View individual entries in popup
* Deleted entries are moved to *Delete & Restore* (not permanently removed)
 
**Display Settings:**
* Rename field labels
* Hide specific fields from reports and exports
 
**Optimized Performance:**
* Bulk delete and export actions run in small batches to reduce server load
 
---
 
### 2. Delete & Restore
Manage deleted entries safely.
 
**Features:**
* Date filter
* Keyword search
* Search by field name
* View full field names in reports
* Bulk permanent delete
* Bulk restore entries
 
Restored entries automatically move back to **CFDB7 Entries**.
 
**Display Settings:**
* Rename field labels
* Hide fields from reports
 
**Optimized Performance:**
* Bulk restore and delete actions run in parts to prevent server overload
 
---
 
### 3. Export Logs
Track all exported files.
 
**Includes:**
* Export date & time
* User who exported the file
* Download exported files anytime
 
---
 
### 4. Entry Logger
Compare original submitted entries with final saved entries after form settings are applied.
 
**Features:**
* Date filter
* Keyword search
* Search by field name
* Clear field name display
* View entry details in popup
 
**Display Settings:**
* Rename field labels
* Hide selected fields
 
---
 
### 5. Indexing Entries
Scan and repair old or missing entries.
 
**Useful when:**
* Entries were not saved due to server issues
* You want to include old CFDB7 entries into the Pro Addon
 
---
 
### 6. Indexing Field Names
Fix issues related to missing or broken field names.
 
**Useful when:**
* Field names were not saved properly due to server issues
 
---
 
### 7. Import Entries
Import Contact Form 7 entries from a CSV file.
 
**How it works:**
1. Select the Contact Form 7 form
2. Prepare a CSV file with matching field names
3. Upload and import entries
 
---
 
### 8. Settings
Control how entries are saved, displayed, imported, and indexed.
 
**Features:**
* Duplicate entry protection
* Exclude selected fields from saving (e.g. reCAPTCHA fields)
* Entries per page setting
* Character limit for entry logs
 
**Applies to:**
* New submissions
* Imported entries
* Indexed entries
 
---
 
### 9. Tools
Generate required database tables for the CFDB7 Pro Addon.
 
---
 
== Installation ==
 
1. Upload the plugin folder to `/wp-content/plugins/`
2. Activate the plugin through the WordPress Plugins menu
3. Make sure **Contact Form 7** and **CFDB7** plugins are installed and active
 
---
 
== Frequently Asked Questions ==
 
= Does this plugin work without CFDB7? =
No. This plugin requires **Contact Form 7 Database Addon – CFDB7**.
 
= Does it delete entries permanently? =
No. Deleted entries are moved to *Delete & Restore*. Permanent deletion is manual.
 
= Is it multisite compatible? =
Yes, it supports WordPress Multisite.
 
---
 
== Screenshots ==
1. CFDB7 Entries management
2. Delete & Restore screen
3. Export logs
4. Entry logger
5. Import entries
6. Settings panel
 
---
 
== Changelog ==
 
= 1.0.0 =
* Initial release
* Advanced entry management
* Import, export, restore, and indexing features