<?php

/**
 * Fired during plugin activation
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/includes
 * @author     Pinky dev
 */
class Cfdb7_Pro_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		global $wpdb;
		if (function_exists('is_multisite') && is_multisite()) {
			$current_blog = $wpdb->blogid;
			// Get all blog ids
			$blog_ids = $wpdb->get_col("SELECT blog_id FROM $wpdb->blogs");
			foreach ($blog_ids as $blog_id){
				switch_to_blog($blog_id);
				cfdb7_generate_basic_tables();
                cfdb7_generate_entries_table();
				self::add_lead_source_column();
			}
			switch_to_blog($current_blog);
		}else{
			cfdb7_generate_basic_tables();
            cfdb7_generate_entries_table();
			self::add_lead_source_column();
		}
	}

	public static function add_lead_source_column(){
		global $wpdb;
		$table_name = $wpdb->prefix . 'db7_forms';
		$column_name = 'lead_source';

		// Check if the column already exists
		$column_exists = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM `$table_name` LIKE %s",$column_name));

		if (empty($column_exists)){
			$wpdb->query("ALTER TABLE `$table_name` ADD `$column_name` VARCHAR(100) DEFAULT ''");
		}
	}
}
