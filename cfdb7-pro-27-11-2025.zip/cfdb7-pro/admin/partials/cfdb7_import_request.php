<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

$cf7_id = isset($_POST['cf7-id']) && !empty($_POST['cf7-id']) ? intval($_POST['cf7-id']) : "";
if(!empty($cf7_id)){
	$user_info = cfdb7_get_logged_in_user_info();
	$capabilities = $user_info['capabilities'];

	$has_import_capability = false;
	if(in_array("manage_options", $capabilities)){
		$has_import_capability = true;
	}
	if(in_array("cfdb7_form_import_entry_".$cf7_id, $capabilities)){
		$has_import_capability = true;
	}
	//Check import capability for current user
	if($has_import_capability == true){
		$csv_fields = array();
		$csv_data = array();
		if(isset($_FILES['uploaded_csv']) && !empty($_FILES['uploaded_csv'])){
			$allowed_extention = array('text/plain', 'text/csv', 'application/vnd.ms-excel', 'application/csv');
			$file_type = mime_content_type($_FILES["uploaded_csv"]['tmp_name']);
			if(in_array($file_type,$allowed_extention)){
				// Read and parse CSV
				if(($handle = fopen($_FILES["uploaded_csv"]['tmp_name'], 'r')) !== false){
					//Get Header details from CSV sheet
					$csv_fields = fgetcsv($handle);
					$temp = array();
					if(!empty($csv_fields)){
						foreach ($csv_fields as $key => $value) {
							$value = sanitize_text_field($value);
							if($key == 0){
								$result = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $value);
								$temp[] = $result;
								//For remove u+fffd like � character from first field
							}else{
								$temp[] = $value;
							}
						}
					}
					$csv_fields = $temp;

					while (($rows = fgetcsv($handle)) !== false){
						$row_data = array(); 
						foreach($rows as $rkey => $rvalue){
							$row_data[sanitize_text_field($csv_fields[$rkey])] = sanitize_text_field($rvalue);
						}
						$csv_data[] = $row_data;
					}
					fclose($handle);
				}
			}
		}

		if(!empty($csv_data) && !empty($csv_fields)){
			global $wpdb;
			$obj = new Cfdb7_Queries();
			$obj->init_cfdb7_tables();

			$tags = cfdb7_get_form_tags($cf7_id);
			//Set fields list
			$cf7_tags = array();
			if(!empty($tags)){
				foreach ( $tags as $tag ){
					if(!empty($tag->name)){
						$safe_name = sanitize_text_field($tag->name);
						$safe_type = sanitize_text_field($tag->basetype);
						$cf7_tags[$safe_name] = $safe_type;
					}
				}
			}
			$cf7_fields = array_keys($cf7_tags);

			//Check csv field exist in contact form 7 fields
			$field_fail_count = 0;
			foreach($csv_fields as $csv_field){
				if(!in_array($csv_field, $cf7_fields)){
					$field_fail_count++;
				}
			}
			
			// Check if all values of $array1 exist in $array2
			if($field_fail_count == 0 && !empty($cf7_tags)){
				//$form_setting use to applied setting to form data
				$form_setting = cfdb7_get_form_setting($wpdb, $obj, $cf7_id);

				$user_info = cfdb7_get_logged_in_user_info();
				$user_id = $user_info['user_id'];
				$display_name = $user_info['display_name'];

				$entry_date_time = current_time("Y-m-d H:i:s");
				$ip_address = cfdb7_get_ip_address();
				$lead_source = "import";

				foreach($csv_data as $field_data){
					if(!empty($field_data)){
						$original_field_data = $field_data;
						//Sanitize existing field data
						$original_field_data = cfdb7_sanitize_field_data($original_field_data);
						$field_data = cfdb7_sanitize_field_data($field_data);

						if(!empty($original_field_data)){
							if(isset($original_field_data['cfdb7_status'])){
								unset($original_field_data['cfdb7_status']);
							}
						}

						//Apply field type processing
						$original_entry_fields = cfdb7_form_data_after_applied_field_type($field_data, $cf7_tags);	
						
						//Save entry to contact form7 db
						$form_entry = array(
							'form_post_id' => $cf7_id,
							'form_value' => maybe_serialize($field_data),
							'form_date' => current_time("Y-m-d H:i:s"),
							'lead_source' => $lead_source,
						);
						$form_entry_format = array("%s","%s","%s","%s");
						
						$db7_forms_id = $obj->save_db7_forms_entry($wpdb, $form_entry, $form_entry_format);

						$logger = array();
						$logger['date_time'] = $entry_date_time;
						$logger['lead_source'] = $lead_source;
						$logger['form_setting'] = $form_setting;
						$logger['db7_forms_id'] = $db7_forms_id;
						$logger['original_entry'] = $field_data;
						$logger['original_entry_fields'] = $original_entry_fields;
						$logger['form_entry'] = $form_entry;

						if (!empty($db7_forms_id)){
							//Validate entry with form settings
							$field_data = cfdb7_form_data_after_applied_settings($field_data, $form_setting, $cf7_id, $obj, $wpdb);
							$logger['proceed_entry'] = $field_data;

							$cfdb7_data = array(
								'field_data' => $field_data,
								'cf7_tags' => $cf7_tags,
								'cf7_id' => $cf7_id,
								'obj' => $obj,
								'wpdb' => $wpdb,
								'db7_forms_id' => $db7_forms_id,
								'form_date' => $entry_date_time,
								'lead_source' => $lead_source,
								'user_id' => $user_id,
								'display_name' => $display_name,
								'ip_address' => $ip_address,
								'original_field_data' => $original_field_data,
							);
							$result = cfdb7_proceed_save_entry($cfdb7_data);

							$logger['proceed_entry_fields'] = $result['proceed_entry_fields'];
							$logger['entry_id'] = $result['entry_id'];
							$logger['entry_details'] = $result['entry_details'];
						}
						//Save logs for import entries
						$obj->save_entry_log($wpdb, $cf7_id, $logger);
					}
				}

				//Save report field information 
				$available_fields = $csv_fields;
				cfdb7_save_report_field_for_field_name_options($available_fields, $cf7_id, $obj, $wpdb);
				
				?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html__( 'Data import successfully.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
				<?php
			}else{
				?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html__( 'Invalid CSV file.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div>
				<?php
			}
		}
	}
}

?>