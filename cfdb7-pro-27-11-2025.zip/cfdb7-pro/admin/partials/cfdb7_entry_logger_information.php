<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

global $wpdb;
$obj = new Cfdb7_Queries();
$obj->init_cfdb7_tables();

$logger_entry = $get_setting = $obj->get_cfdb7_log_entry($wpdb, $cf7_id, $index);
if(!empty($logger_entry)){
	$form_settings = isset($logger_entry['form_setting']) && !empty($logger_entry['form_setting']) ? maybe_unserialize($logger_entry['form_setting']) : array();
	$form_settingss = !empty($form_settingss) ? array_map('sanitize_text_field', $form_settingss) : array();
	
	$avoid_duplicate_submission = "";
	$avoid_field = "";
	$excludes_fields = "";
	if(!empty($form_settings)){
		$avoid_duplicate_submission = isset($form_settings['avoid_duplicate_submission']) && !empty($form_settings['avoid_duplicate_submission']) ? sanitize_text_field($form_settings['avoid_duplicate_submission']) : "";
        
		$avoid_field = isset($form_settings['avoid_field']) && !empty($form_settings['avoid_field']) ? sanitize_text_field($form_settings['avoid_field']) : "";
    	
		$excludes_fields = isset($form_settings['excludes_fields']) && !empty($form_settings['excludes_fields']) ? array_map('sanitize_text_field', $form_settings['excludes_fields']) : array();
		$excludes_fields = !empty($excludes_fields) ? implode(",", $excludes_fields) : "";
	}
	?>
	<table border="1" class="logger-setting-information">
		<tr>
			<td><?php echo esc_html__('Avoid duplicate submission', CFDB7_PRO_TEXT_DOMAIN); ?></td>
			<td><?php echo $avoid_duplicate_submission; ?></td>
		</tr>
		<tr>
			<td><?php echo esc_html__('Avoid field', CFDB7_PRO_TEXT_DOMAIN); ?></td>
			<td><?php echo $avoid_field; ?></td>
		</tr>
		<tr>
			<td><?php echo esc_html__('Exclude fields', CFDB7_PRO_TEXT_DOMAIN); ?></td>
			<td><?php echo $excludes_fields; ?></td>
		</tr>
	</table>
	<?php

	$original_entry = isset($logger_entry['original_entry']) && !empty($logger_entry['original_entry']) ? maybe_unserialize($logger_entry['original_entry']) : array();
	$original_entry = !empty($original_entry) ? array_map('sanitize_text_field', $original_entry) : array();

	$original_entry_fields = isset($logger_entry['original_entry_fields']) && !empty($logger_entry['original_entry_fields']) ? maybe_unserialize($logger_entry['original_entry_fields']) : array();
	$original_entry_fields = !empty($original_entry_fields) ? array_map('sanitize_text_field', $original_entry_fields) : array();

	if(!empty($original_entry)){
		?>
		<table border="1" class="logger-original-information">
			<thead>
				<tr>
					<th><?php echo esc_html__('Field Name', CFDB7_PRO_TEXT_DOMAIN); ?></th>
					<th><?php echo esc_html__('Field Value', CFDB7_PRO_TEXT_DOMAIN); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php 
				foreach($original_entry as $entry_name => $entry_value){
					$field_type = isset($original_entry_fields[$entry_name]) && !empty($original_entry_fields[$entry_name]) ? esc_html($original_entry_fields[$entry_name]) : '';
					if($field_type == 'file'){
						$entry_value = '<a href="'.esc_url($entry_value).'" target="_blank">'.esc_html(basename($entry_value)).'</a>';
					}else{
						$entry_value = esc_html($entry_value);
					}
					?>
					<tr>
						<td><?php echo $entry_name; ?></td>
						<td><?php echo $entry_value; ?></td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
		<?php
	}

	$proceed_entry = isset($logger_entry['proceed_entry']) && !empty($logger_entry['proceed_entry']) ? maybe_unserialize($logger_entry['proceed_entry']) : array();
	$proceed_entry = !empty($proceed_entry) ? array_map('sanitize_text_field', $proceed_entry) : array();

	$proceed_entry_fields = isset($logger_entry['proceed_entry_fields']) && !empty($logger_entry['proceed_entry_fields']) ? maybe_unserialize($logger_entry['proceed_entry_fields']) : array();
	$proceed_entry_fields = !empty($proceed_entry_fields) ? array_map('sanitize_text_field', $proceed_entry_fields) : array();

	if(!empty($proceed_entry)){
		?>
		<table border="1" class="logger-proceed-information">
			<thead>
				<tr>
					<th><?php echo esc_html__('Field Name', CFDB7_PRO_TEXT_DOMAIN); ?></th>
					<th><?php echo esc_html__('Field Value', CFDB7_PRO_TEXT_DOMAIN); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php 
				foreach($proceed_entry as $entry_name => $entry_value){
					$field_type = isset($proceed_entry_fields[$entry_name]) && !empty($proceed_entry_fields[$entry_name]) ? esc_html($proceed_entry_fields[$entry_name]) : '';
					if($field_type == 'file'){
						$entry_value = '<a href="'.esc_url($entry_value).'" target="_blank">'.esc_html(basename($entry_value)).'</a>';
					}else{
						$entry_value = esc_html($entry_value);
					}
					?>
					<tr>
						<td><?php echo $entry_name; ?></td>
						<td><?php echo $entry_value; ?></td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
		<?php
	}
}