<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

switch ( $filter_type ) {
    case 'date_filter':
        $from_date = isset($_GET['from_date']) && !empty($_GET['from_date']) ? sanitize_text_field($_GET['from_date']) : '';
        $to_date = isset($_GET['to_date']) && !empty($_GET['to_date']) ? sanitize_text_field($_GET['to_date']) : '';
        ?>
        <div class="form-group">
            <div class="form-label">
                <label for="from_date"><?php echo esc_html__('From Date', CFDB7_PRO_TEXT_DOMAIN); ?></label>
            </div>
            <div class="form-input">
                <input type="text" id="from_date" name="from_date" value="<?php echo $from_date; ?>" form="wp-list-table"/>
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label for="to_date"><?php echo esc_html__('To Date', CFDB7_PRO_TEXT_DOMAIN); ?></label>
            </div>
            <div class="form-input">
                <input type="text" id="to_date" name="to_date" value="<?php echo $to_date; ?>" form="wp-list-table"/>
            </div>
        </div>
        <div class="form-group">
            <div class="form-input">
                <input type="submit" name="search_entries" id="search_entries" class="button" value="<?php echo esc_html__('Search', CFDB7_PRO_TEXT_DOMAIN); ?>" form="wp-list-table">
            </div>
        </div>
        <?php
        break;
    case 'display_settings':
        if(!empty($this->field_names)){
            $current_fields = !empty($this->field_names) ? wp_list_pluck($this->field_names, 'field_name') : array();
            $current_fields = !empty($current_fields) ? array_map('sanitize_text_field', $current_fields) : array();

            $renamed_fields = $this->rename_fields;
            if(!empty($renamed_fields)){
                $clean_rename = array();
                foreach ($renamed_fields as $key => $val) {
                    $clean_rename[sanitize_text_field($key)] = sanitize_text_field($val);
                }
                $renamed_fields = $clean_rename;
            }

            $enabled_fields = $this->enable_fields;
            if(!empty($enabled_fields)){
                $clean_rename = array();
                foreach ($enabled_fields as $key => $val) {
                    $clean_rename[sanitize_text_field($key)] = sanitize_text_field($val);
                }
                $enabled_fields = $clean_rename;
            }

            $field_order = $this->field_order;
            $field_order = !empty($field_order) ? array_map('sanitize_text_field', $field_order) : array();
 
            $final_order = array();
            if (!empty($field_order)) {
                // First: fields that appear in $field_order (in that order)
                $exclude_fields = array();
                foreach ($field_order as $field_name) {
                    if(in_array($field_name, $current_fields)){
                        $final_order[] = $field_name;
                        $exclude_fields[] = $field_name;
                    }
                }
                // Second: remaining fields (not listed in $field_order)
                foreach ($current_fields as $field_name) {
                    if(!in_array($field_name, $exclude_fields)){
                        $final_order[] = $field_name;
                    }
                }
            } else {
                // Use default field order
                $final_order = $current_fields;
            }
            ?>
            <table border="1">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Field Name', CFDB7_PRO_TEXT_DOMAIN); ?></th>
                        <th><?php echo esc_html__('Rename Field', CFDB7_PRO_TEXT_DOMAIN); ?></th>
                        <th><?php echo esc_html__('Show/Hide Field', CFDB7_PRO_TEXT_DOMAIN); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    foreach($final_order as $field_name){
                        ?>
                        <tr class="ui-sortable-handle">
                            <td><?php echo esc_attr($field_name); ?></td>
                            <td><input type="text" name="rename_field[<?php echo esc_attr($field_name); ?>]" placeholder="<?php echo esc_html__('Rename field', CFDB7_PRO_TEXT_DOMAIN); ?>" value="<?php echo isset($renamed_fields[$field_name]) ? esc_attr($renamed_fields[$field_name]) : ''; ?>"></td>
                            <td>
                                <label class="cfdb7-toggle-switch">
                                    <?php 
                                    $is_checked = "checked";
                                    if(!empty($enabled_fields)){
                                        $is_checked = isset($enabled_fields[$field_name]) ? 'checked' : '';
                                    }
                                    ?>
                                    <input type="checkbox" name="enable_field[<?php echo esc_attr($field_name); ?>]" <?php echo $is_checked; ?>>
                                    <span class="cfdb7-slider"></span>
                                </label>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3">
                            <?php submit_button(esc_html__('Save Settings', CFDB7_PRO_TEXT_DOMAIN), 'secondary', 'display-settings', false); ?>
                        </td>
                    </tr>
                </tfoot>
            </table>
            <?php
        }
        break;
    case 'search_filter':
        $field_names = isset($_GET['field_names']) && !empty($_GET['field_names']) ? array_map('sanitize_text_field',$_GET['field_names']) : array();
        $search = isset($_GET['s']) && !empty($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        ?>
        <div class="form-group">
            <div class="form-label">
                <label for="field_name"><?php echo esc_html__('Field Names', CFDB7_PRO_TEXT_DOMAIN); ?></label>
            </div>
            <div class="form-input chosen-field" style="width:100%;">
                <select name="field_names[]" id="field_name" multiple placeholder="<?php echo esc_html__('Choose fields', CFDB7_PRO_TEXT_DOMAIN); ?>" data-allow-clear="1" form="wp-list-table">
                    <?php 
                    if(!empty($this->field_names)){
                        foreach($this->field_names as $field_name){
                            if($field_name['entry_count'] > 0){
                                $is_selected = "";
                                if(in_array($field_name['field_name'], $field_names)){
                                    $is_selected = "selected";
                                }
                                ?><option value="<?php echo esc_attr($field_name['field_name']); ?>" <?php echo $is_selected; ?>><?php echo esc_attr($field_name['field_name']); ?></option><?php
                            }
                        }
                    }
                    ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label for="search"><?php echo esc_html__('Search', CFDB7_PRO_TEXT_DOMAIN); ?></label>
            </div>
            <div class="form-input">
                <input type="text" id="search" name="s" value="<?php echo $search; ?>" form="wp-list-table"/>
            </div>
        </div>
        <div class="form-group">
            <div class="form-input">
                <input type="submit" name="search_entries" id="search_entries" class="button" value="<?php echo esc_html__('Search', CFDB7_PRO_TEXT_DOMAIN); ?>" form="wp-list-table">
            </div>
        </div>
        <?php
        break;
    default:
        break;
}