<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

wp_enqueue_style( 'cfdb7_entries_style' );
wp_enqueue_script( 'cfdb7_entries_script' );
?>
<div class="wrap cfdb7-entries">
    <?php 
	if(CFDB7_ACTIVATED == true){
		include_once plugin_dir_path( __DIR__ ).'partials/cfdb7_entries_submissions.php';
	}else{
		include_once plugin_dir_path( __DIR__ ).'partials/cfdb7_activation_notice.php';
	} 
	?>
</div>