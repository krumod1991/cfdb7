jQuery(document).ready(function () {
    jQuery("#generate-tables").click(function () {
        jQuery.ajax({
            url: cfdb7_params.ajax_url,
            data: {
                'action': 'cfdb7_generate_tables',
                'nonce': jQuery("#generate_tables_nonce").val(),
            },
            type: 'POST',
            beforeSend: function (xhr) {
                jQuery(".cfdb7-tools .loader").css("display", 'flex');
            },
            success: function (data) {
                var result = JSON.parse(data);
                if(result.status == "fail"){
                    jQuery("#notice").html(result.message);
                    setTimeout(function(){
                        jQuery('.notice').addClass('notice-error');
                        jQuery('.notice').css('display', 'block');
                        window.location.reload();
                    }, 1000);
                }
            },
            complete: function () {
                jQuery(".cfdb7-tools .loader").css("display", 'none');
            },
            fail: function () {
                jQuery(".cfdb7-tools .loader").css("display", 'none');
            }
        });
    });
});