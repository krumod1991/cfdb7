<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

echo "<pre>";
print_r($post_data);
echo "</pre>";

// Check if user has delete permission
// $has_permission = false;
// if (!empty($user_info['capabilities']) && is_array($user_info['capabilities'])) {
//     $capabilities = $user_info['capabilities'];
//     if(in_array("cfdb7_form_delete_entry_".$cf7_id, $capabilities) || in_array("manage_options", $capabilities)){
//         $has_permission = true;
//     }
// }

// if ($has_permission) {
//     include_once plugin_dir_path(__FILE__).'partials/cfdb7_entries_delete_entry_ids.php';
//     wp_die();
// }else{
//     wp_die(esc_html__('You do not have permission to delete entries.', CFDB7_PRO_TEXT_DOMAIN));
// }
// ?>
<div class="wrap cfdb7-contact-us">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Delete Entries', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
</div>
