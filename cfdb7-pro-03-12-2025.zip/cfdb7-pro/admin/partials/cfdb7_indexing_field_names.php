<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin/partials
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

global $wpdb;
$obj = new Cfdb7_Queries();
$obj->init_cfdb7_tables();

$allowed_form_ids = array();
if(!empty($forms_list)){
	foreach($forms_list as $form){
		$entries_count = $obj->get_cfdb7_form_entries_count($wpdb, $form->ID);
		if(!empty($entries_count)){
			if($entries_count['count'] > 0){
				$allowed_form_ids[] = $form;
			}
		}			
	}
}

wp_enqueue_style('cfdb7_indexing_field_names_style');
wp_enqueue_script('cfdb7_indexing_field_names_script');

$cf7_id = isset($_GET['cf7-id']) && !empty($_GET['cf7-id']) ? intval($_GET['cf7-id']) : "";
$nonce = isset($_GET['nonce']) && !empty($_GET['nonce']) ? sanitize_text_field($_GET['nonce']) : "";
?>
<div class="wrap cfdb7-indexing-field-names">
	<div class="loader" style="display:none;"></div>
	<div class="notice notice-1" style="display:none;"><p id="notice-1"></p></div>
	<div class="notice notice-2" style="display:none;"><p id="notice-2"></p></div>
	<div class="notice notice-3" style="display:none;"><p id="notice-3"></p></div>
    <h1 class="wp-heading-inline"><?php echo esc_html__('Indexing Field Names', CFDB7_PRO_TEXT_DOMAIN); ?></h1>
	<table class="form-table">
		<tr class="form-field">
			<th><label for="cf7-id"><?php echo esc_html__('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></label></th>
			<td>
				<select name="cf7-id" id="cf7-id">
					<option value=""><?php echo esc_html__('Select Form', CFDB7_PRO_TEXT_DOMAIN); ?></option>
					<?php 
					if(!empty($allowed_form_ids)){
						foreach($allowed_form_ids as $form){							
							?><option value="<?php echo $form->ID; ?>" <?php selected($cf7_id, $form->ID); ?>><?php echo $form->post_title; ?></option><?php
						}
					}
					?>
				</select>
				<?php wp_nonce_field('indexing_field_name_page', 'indexing_field_name_page_nonce'); ?>
			</td>
		</tr>
		<?php 
		if(!empty($cf7_id) && !empty($nonce)){
			if(wp_verify_nonce($nonce, 'indexing_field_name_page')){
				?>
				<tr class="form-field">
					<th></th>
					<td><button type="button" id="cfdb7-indexing" class="button button-primary"><?php echo esc_html__('Indexing Entries', CFDB7_PRO_TEXT_DOMAIN); ?></button><?php wp_nonce_field('indexing_field_names', 'indexing_field_names_nonce'); ?></td>
				</tr>
				<?php
			}else{
				?>
				<tr class="form-field">
					<th></th>
					<td><div class="notice notice-error is-dismissible"><p><?php echo esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN ); ?></p></div></td>
				</tr>
				<?php
			}
		}
		?>
	</table>
</div>
