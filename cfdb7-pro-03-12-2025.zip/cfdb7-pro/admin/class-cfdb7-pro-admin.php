<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @since      1.0.0
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin
*/

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Cfdb7_Pro
 * @subpackage Cfdb7_Pro/admin
 * @author     Pinky dev
*/
class Cfdb7_Pro_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	*/
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	*/
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	*/
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	*/
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Cfdb7_Pro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Cfdb7_Pro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/cfdb7-pro-admin.css', array(), $this->version.'_'.time(), 'all' );
		//Other functionality styles
		wp_register_style( 'cfdb7_chosen_style', plugin_dir_url( __FILE__ ) . 'css/chosen.min.css', array(), $this->version, 'all' );
		wp_register_style( 'cfdb7_magnific_popup_style', plugin_dir_url( __FILE__ ) . 'css/magnific-popup.css', array(), $this->version, 'all' );
		wp_register_style('jquery-ui-css', plugin_dir_url( __FILE__ ).'css/jquery-ui.css', array(), $this->version, 'all' );
		//Pages styles
		wp_register_style( 'cfdb7_entries_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_entries_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_delete_entries_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_delete_entries_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_export_log_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_export_logs_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_entry_logger_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_entry_logger_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_indexing_entries_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_indexing_entries.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_indexing_field_names_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_indexing_field_names_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_import_entries_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_import_entries_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_setting_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_setting_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_tools_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_tools_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_contact_us_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_contact_us_style.css', array(), $this->version.'_'.time(), 'all' );
		wp_register_style( 'cfdb7_document_style', plugin_dir_url( __FILE__ ) . 'css/cfdb7_documentation_style.css', array(), $this->version.'_'.time(), 'all' );
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	*/
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Cfdb7_Pro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Cfdb7_Pro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_register_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/cfdb7-pro-admin.js', array( 'jquery' ), $this->version.'_'.time(), false );

		$cfdb7_params = array(
			'ajax_url' => admin_url('admin-ajax.php'),
			'require_massage' => esc_html__( 'Please select a file.', CFDB7_PRO_TEXT_DOMAIN ),
			'invalid_file_massage' => esc_html__( 'Invalid file. Please select a CSV file.', CFDB7_PRO_TEXT_DOMAIN ),
			'fail_index_message' => esc_html__( 'Something went wrong.', CFDB7_PRO_TEXT_DOMAIN ),
			'success_index_message' => esc_html__( 'Indexing successfully completed.', CFDB7_PRO_TEXT_DOMAIN ),
			'chosen_placeholder' => esc_html__( 'Select fields', CFDB7_PRO_TEXT_DOMAIN ),
			'chosen_no_results' => esc_html__( 'No matches found.', CFDB7_PRO_TEXT_DOMAIN ),
		);
		wp_localize_script( $this->plugin_name, 'cfdb7_params', $cfdb7_params );

		// Enqueued script with localized data.
		wp_enqueue_script( $this->plugin_name );
		//Pages scripts
		wp_register_script( 'cfdb7_entries_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_entries_script.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_delete_entries_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_delete_entries_script.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_export_logs_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_export_logs_script.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_entry_logger_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_entry_logger_script.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_indexing_entries_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_indexing_entries.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_indexing_field_names_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_indexing_field_names_script.js', array( 'jquery' ), $this->version.'_'.time(), false );			
		wp_register_script( 'cfdb7_import_entries_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_import_entries_script.js', array( 'jquery' ), $this->version.'_'.time(), false );			
		wp_register_script( 'cfdb7_setting_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_setting_script.js', array( 'jquery' ), $this->version.'_'.time(), false );
		wp_register_script( 'cfdb7_tools_script', plugin_dir_url( __FILE__ ) . 'js/cfdb7_tools_script.js', array( 'jquery' ), $this->version.'_'.time(), false );
		//Other functionality scripts
		wp_register_script( 'cfdb7_chosen_script', plugin_dir_url( __FILE__ ) . 'js/chosen.jquery.min.js', array( 'jquery' ), $this->version, false );
		wp_register_script( 'cfdb7_magnific_popup_script', plugin_dir_url( __FILE__ ) . 'js/magnific-popup.min.js', array( 'jquery' ), $this->version, false );
		wp_register_script( 'cfdb7_display_setting_sortable', plugin_dir_url( __FILE__ ) . 'js/cfdb7-display-setting-sortable.js', array( 'jquery' ), $this->version, false );
	}

	/**
	 * Check if the required plugin is installed and activated.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_check_required_plugin(){
		// The plugin you depend on — path relative to plugins directory
		$required_plugin = 'contact-form-7/wp-contact-form-7.php';

		// Check if the required plugin is active
		if (!is_plugin_active($required_plugin)){
			$this->cfdb7_display_deactivation_notice($required_plugin, 'Contact Form 7');
		}else{
			$required_plugin = 'contact-form-cfdb7/contact-form-cfdb-7.php';
			if (!is_plugin_active($required_plugin)){
				$this->cfdb7_display_deactivation_notice($required_plugin, 'Contact Form CFDB7');
			}
		}
	}

	/**
	 * Display an admin notice when a required plugin is missing or inactive.
	 *
	 * @since    1.0.0
	 * @param    string    $required_plugin       The name of the required plugin.
	 * @param    string    $parent_plugin_name    The name of the parent plugin depending on it.
	*/
	private function cfdb7_display_deactivation_notice($required_plugin, $parent_plugin_name){
		// Deactivate *this* plugin
		deactivate_plugins(plugin_basename(__FILE__));

		// Optional: show an admin notice
		add_action('admin_notices', function() use ($required_plugin, $parent_plugin_name) {
			$plugin_data = get_plugin_data(__FILE__);

			echo '<div class="notice notice-error"><p>';
			printf(
				/* translators: 1: Plugin name, 2: Required parent plugin name */
				esc_html__(
					'%1$s requires %2$s to be active. The plugin has been deactivated.',
					CFDB7_PRO_TEXT_DOMAIN
				),
				esc_html($plugin_data['Name']),
				'<strong>' . esc_html($parent_plugin_name) . '</strong>'
			);
			echo '</p></div>';
		});
	}

	/**
	 * Add a settings link to the plugin action links.
	 *
	 * @since    1.0.0
	 * @param    array    $links    The existing plugin action links.
	 * @return   array              The modified plugin action links.
	*/
	public function cfdb7_add_setting_link_plugin($links){
		$settings_link = '<a href="admin.php?page=cfdb7-settings">'.esc_html__('Settings', CFDB7_PRO_TEXT_DOMAIN).'</a>';
		array_unshift($links, $settings_link);
		return $links;
	}

	/**
	 * Register the custom admin menu for the plugin.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_custom_admin_menu(){
		$user_info = cfdb7_get_logged_in_user_info();
		$capabilities = !empty($user_info['capabilities']) && is_array($user_info['capabilities']) ? array_map('sanitize_text_field', $user_info['capabilities']) : array();

		$view_capability = "";
		$import_capability = "";
		$has_access = false;
		if(!empty($capabilities)){
			if(in_array("manage_options", $capabilities)){
				$view_capability = "manage_options";
				$import_capability = "manage_options";
			}

			$view_cfdb7_form = !empty(preg_grep('/^cfdb7_form_view_entry/', array_keys($capabilities)));
			if($view_cfdb7_form == true){
				$view_capability = "exist";
			}

			$import_cfdb7_entry = !empty(preg_grep('/^cfdb7_form_import_entry/', array_keys($capabilities)));
			if($import_cfdb7_entry == true){
				$import_capability = "exist";
			}
		}

		if(!empty($view_capability)){
			add_menu_page(esc_html__('CFDB7 Entries', CFDB7_PRO_TEXT_DOMAIN), esc_html__('CFDB7 Entries', CFDB7_PRO_TEXT_DOMAIN), $view_capability, 'cfdb7-entries', array($this, 'cfdb7_entries_page'), 'dashicons-email-alt2', 25);
			if (CFDB7_ACTIVATED == true){
				add_submenu_page('cfdb7-entries', esc_html__('Delete & Restore', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Delete & Restore', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-delete-and-restore', array($this, 'cfdb7_delete_and_restore_page'));
				add_submenu_page('cfdb7-entries', esc_html__('Export Logs', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Export Logs', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-export-logs', array($this, 'cfdb7_export_logs_page'));
				add_submenu_page('cfdb7-entries', esc_html__('Entry Logger', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Entry Logger', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-entry-logger', array($this, 'cfdb7_entry_logger_page'));
				add_submenu_page('cfdb7-entries', esc_html__('Indexing Entries', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Indexing Entries', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-indexing-entries', array($this, 'cfdb7_indexing_entries_page'));
				add_submenu_page('cfdb7-entries', esc_html__('Indexing Field Names', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Indexing Field Names', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-indexing-field-name', array($this, 'cfdb7_indexing_field_name_page'));
				if(!empty($import_capability)){
					add_submenu_page('cfdb7-entries', esc_html__('Import Entries', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Import Entries', CFDB7_PRO_TEXT_DOMAIN), $import_capability, 'cfdb7-import-entries', array($this, 'cfdb7_import_entries_page'));
				}
				add_submenu_page('cfdb7-entries', esc_html__('Settings', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Settings', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-settings', array($this, 'cfdb7_settings_page'));
				add_submenu_page('cfdb7-entries', esc_html__('Tools', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Tools', CFDB7_PRO_TEXT_DOMAIN), 'manage_options', 'cfdb7-tools', array($this, 'cfdb7_tools_page'));
				
				add_submenu_page('cfdb7-entries', esc_html__('Contact Us', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Contact Us', CFDB7_PRO_TEXT_DOMAIN), 'exist', 'cfdb7-contact-us', array($this, 'cfdb7_contact_us_page'));
				add_submenu_page('cfdb7-entries', esc_html__('Documentation', CFDB7_PRO_TEXT_DOMAIN), esc_html__('Documentation', CFDB7_PRO_TEXT_DOMAIN), 'exist', 'cfdb7-documentation', array($this, 'cfdb7_documentation_page'));
				//Action for add sub menu page
				do_action( 'cfdb7_add_submenu_page', 'cfdb7-entries' );
			}
		}
	}

	/**
	 * Display the entries page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_entries_page() {
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_entries.php';
	}

	/**
	 * Display the delete and restore entries page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_delete_and_restore_page() {
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_delete_and_restore_entries.php';
	}

	/**
	 * Display the export logs page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_export_logs_page() {
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_export_logs.php';
	}

	/**
	 * Display the entry logger page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_entry_logger_page(){
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_entry_logger.php';
	}

	/**
	 * Display the indexing entries page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_entries_page() {
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_indexing_entries.php';
	}

	/**
	 * Display the indexing field name page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_field_name_page() {
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_indexing_field_names.php';
	}

	/**
	 * Display the import entries page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_import_entries_page() {
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_import_entries.php';
	}

	/**
	 * Display the plugin settings page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_settings_page() {
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_settings.php';
	}

	/**
	 * Display the plugin tools page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_tools_page(){
		$forms_list = $this->get_contact_forms_list();
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_tools.php';
	}

	/**
	 * Display the Contact Us page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_contact_us_page(){
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_contact_us.php';
	}

	/**
	 * Display the plugin documentation page in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_documentation_page(){
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_documentation.php';
	}

	/**
	 * Retrieve a list of all Contact Form 7 forms.
	 *
	 * @since    1.0.0
	 * @return   array    An array of contact forms.
	*/
	private function get_contact_forms_list(){
		$forms_list = cfdb7_get_contact_forms_list();
		return $forms_list;
	}

	/**
	 * Generate necessary database tables for storing form entries.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_generate_tables(){
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		if(!empty($nonce)){
			$result = array();
			if(wp_verify_nonce($nonce, 'generate_tables')){
				$result['status'] = "success";
				add_lead_source_column();
				cfdb7_generate_basic_tables();
        		cfdb7_generate_entries_table();
				$result['message'] = esc_html__( 'Table generated successfully.', CFDB7_PRO_TEXT_DOMAIN );
			}else{
				$result['status'] = "fail";
				$result['message'] = esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN );
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Index the field names of form entries for faster searching.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_entries_field_names(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		if(!empty($cf7_id) && !empty($nonce)){
			$result = array();
			if(wp_verify_nonce($nonce, 'indexing_field_names')){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();
				//Delete all options from db
				$obj->truncate_cfdb7_report_field_name_options($wpdb, $cf7_id);
				
				$fields_list = $obj->get_cfdb7_report_field_name_options_count($wpdb, $cf7_id);
				if(!empty($fields_list)){
					foreach($fields_list as $field_list){
						$field_name_safe = isset($field_list['field_name']) ? sanitize_text_field($field_list['field_name']) : '';
						$count_safe = isset($field_list['count']) ? intval($field_list['count']) : 0;
						$obj->save_cfdb7_report_field_name_options($wpdb, $cf7_id, $field_name_safe, $count_safe);
					}
					$result['status'] = "success";
					$result['message'] = esc_html__( 'Indexing successfully for form entries.', CFDB7_PRO_TEXT_DOMAIN );
				}else{
					$result['message'] = esc_html__( 'No Entries found for form entries.', CFDB7_PRO_TEXT_DOMAIN );
					$result['status'] = "fail";
				}
			}else{
				$result['message'] = esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN );
				$result['status'] = "fail";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Index the field names of form entries for faster searching.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_delete_entries_field_names(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		if(!empty($cf7_id) && !empty($nonce)){
			$result = array();
			if(wp_verify_nonce($nonce, 'indexing_field_names')){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();
				//Delete all options from db
				$obj->truncate_cfdb7_delete_report_field_name_options($wpdb, $cf7_id);
				
				$fields_list = $obj->get_cfdb7_delete_report_field_name_options_count($wpdb, $cf7_id);
				if(!empty($fields_list)){
					foreach($fields_list as $field_list){
						$field_name_safe = sanitize_text_field($field_list['field_name']);
						$count_safe = intval($field_list['count']);
						$obj->save_cfdb7_delete_report_field_name_options($wpdb, $cf7_id, $field_name_safe, $count_safe);
					}
					$result['status'] = "success";
					$result['message'] = esc_html__( 'Indexing successfully for delete entries.', CFDB7_PRO_TEXT_DOMAIN );
				}else{
					$result['message'] = esc_html__( 'No Entries found for delete entries.', CFDB7_PRO_TEXT_DOMAIN );
					$result['status'] = "fail";
				}
			}else{
				$result['message'] = esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN );
				$result['status'] = "fail";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Index the field names of form entries for faster searching.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_log_entries_field_names(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		if(!empty($cf7_id) && !empty($nonce)){
			$result = array();
			if(wp_verify_nonce($nonce, 'indexing_field_names')){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();
				//Delete all options from db
				$obj->truncate_cfdb7_log_report_field_name_options($wpdb, $cf7_id);
				
				$fields_list = $obj->get_cfdb7_log_report_field_name_options_count($wpdb, $cf7_id);
				if(!empty($fields_list)){
					foreach($fields_list as $field_list){
						$field_name_safe = sanitize_text_field($field_list['field_name']); 
						$count_safe = intval($field_list['count']);
						$obj->save_cfdb7_log_report_field_name_options($wpdb, $cf7_id, $field_name_safe, $count_safe);
					}
					$result['status'] = "success";
					$result['message'] = esc_html__( 'Indexing successfully for log entries.', CFDB7_PRO_TEXT_DOMAIN );
				}else{
					$result['message'] = esc_html__( 'No Entries found for log entries.', CFDB7_PRO_TEXT_DOMAIN );
					$result['status'] = "fail";
				}
			}else{
				$result['message'] = esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN );
				$result['status'] = "fail";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Callback triggered after a Contact Form 7 form is created.
	 *
	 * @since    1.0.0
	 * @param    object    $contact_form    The newly created Contact Form 7 form object.
	*/
	public function cfdb7_wpcf7_after_create($contact_form){
		$cf7_id = intval($contact_form->id);
		cfdb7_generate_entries_table($cf7_id);
	}

	/**
	 * Display indexing information for form entries.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_info(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		if(!empty($cf7_id) && !empty($nonce)){
			$result = array();
			if(wp_verify_nonce($nonce, 'indexing_entries')){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();

				$enquiry_info = $obj->get_db7_forms_entries_count($wpdb, $cf7_id);
				if(!empty($enquiry_info)){
					if($enquiry_info['count'] > 0){
						$ppp = 50;
						$ppp = apply_filters( 'cfdb7_indexing_ppp', $ppp );

						$result['status'] = "success";
						$result['count'] = $enquiry_info['count'];
						$result['max_pages'] = ceil($enquiry_info['count']/$ppp);
					}else{
						$result['message'] = esc_html__( 'No entries found for indexing.', CFDB7_PRO_TEXT_DOMAIN );
						$result['status'] = "fail";
					}
				}else{
					$result['message'] = esc_html__( 'No entries found for indexing.', CFDB7_PRO_TEXT_DOMAIN );
					$result['status'] = "fail";
				}
			}else{
				$result['message'] = esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN );
				$result['status'] = "fail";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Index cfdb-7 form entries for retrieval.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_indexing_entries(){
		$cf7_id = isset($_POST['cf7_id']) && !empty($_POST['cf7_id']) ? intval($_POST['cf7_id']) : "";
		$nonce = isset($_POST['nonce']) && !empty($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : "";
		if(!empty($cf7_id) && !empty($nonce)){
			$result = array();
			if(wp_verify_nonce($nonce, 'indexing_entries')){
				global $wpdb;
				$obj = new Cfdb7_Queries();
				$obj->init_cfdb7_tables();

				$ppp = 50;
				$ppp = intval(apply_filters( 'cfdb7_indexing_ppp', $ppp ));

				$indexing_entries = $obj->get_db7_forms_indexing_entries($wpdb, $cf7_id, $ppp);
				if(!empty($indexing_entries)){
					$result['is_next_page'] = "yes";
					
					$tags = cfdb7_get_form_tags($cf7_id);
					//Set fields list
					$cf7_tags = array();
					if(!empty($tags)){
						foreach ( $tags as $tag ){
							if(!empty($tag->name)){
								$safe_name = sanitize_text_field($tag->name);
								$safe_type = sanitize_text_field($tag->basetype);
								$cf7_tags[$safe_name] = $safe_type;
							}
						}
					}

					//$form_setting use to applied setting to form data
					$form_setting = cfdb7_get_form_setting($wpdb, $obj, $cf7_id);
					$date_time = current_time("Y-m-d H:i:s");

					$available_field_names = array();
					foreach($indexing_entries as $indexing_entry){
						$field_data = isset($indexing_entry['form_value']) && !empty($indexing_entry['form_value']) ? maybe_unserialize($indexing_entry['form_value']) : array();
						
						$db7_forms_id = isset($indexing_entry['form_id']) && !empty($indexing_entry['form_id']) ? intval($indexing_entry['form_id']) : "";

						$entry_date_time = isset($indexing_entry['form_date']) && !empty($indexing_entry['form_date']) ? sanitize_text_field($indexing_entry['form_date']) : "";

						$lead_source = isset($indexing_entry['lead_source']) && !empty($indexing_entry['lead_source']) ? sanitize_text_field($indexing_entry['lead_source']) : "cf7";

						$field_names = array_keys($field_data);
						foreach($field_names as $proceed_name){
							if(!in_array($proceed_name, $available_field_names)){
								$available_field_names[] = $proceed_name;
							}
						}

						$original_field_data = $field_data;
						//Sanitize existing field data
						$original_field_data = cfdb7_sanitize_field_data($original_field_data);
						$field_data = cfdb7_sanitize_field_data($field_data);

						if(!empty($original_field_data)){
							if(isset($original_field_data['cfdb7_status'])){
								unset($original_field_data['cfdb7_status']);
							}
						}

						//Apply field type processing
						$original_entry_fields = cfdb7_form_data_after_applied_field_type($field_data, $cf7_tags);

						$logger = array();
						$logger['date_time'] = $date_time;
						$logger['lead_source'] = $lead_source;
						$logger['form_setting'] = $form_setting;
						$logger['db7_forms_id'] = $db7_forms_id;
						$logger['original_entry'] = $field_data;
						$logger['original_entry_fields'] = $original_entry_fields;
						$logger['form_entry'] = sanitize_textarea_field($indexing_entry);
						
						//Validate entry with form settings
						$field_data = cfdb7_form_data_after_applied_settings($field_data, $form_setting, $cf7_id, $obj, $wpdb);
						$logger['proceed_entry'] = $field_data;

						$cfdb7_data = array(
							'field_data' => $field_data,
							'cf7_tags' => $cf7_tags,
							'cf7_id' => $cf7_id,
							'db7_forms_id' => $db7_forms_id,
							'form_date' => $entry_date_time,
							'lead_source' => $lead_source,
							'user_id' => "",
							'display_name' => "",
							'ip_address' => "",
							'original_field_data' => $original_field_data,
						);
						$entry_result = cfdb7_proceed_save_entry($wpdb, $obj, $cfdb7_data);

						$logger['proceed_entry_fields'] = $entry_result['proceed_entry_fields'];
						$logger['entry_id'] = $entry_result['entry_id'];
						$logger['entry_details'] = $entry_result['entry_details'];
						
						//Save logs for indexing
						$obj->save_entry_log($wpdb, $cf7_id, $logger);
					}

					//Save report field information 
					$available_fields = array_map('sanitize_text_field', $available_field_names);
					cfdb7_save_report_field_for_field_name_options($available_fields, $cf7_id, $obj, $wpdb);
				}else{
					$result['message'] = esc_html__( 'No entries found for indexing.', CFDB7_PRO_TEXT_DOMAIN );
					$result['is_next_page'] = "no";
				}
			}else{
				$result['message'] = esc_html__( 'Security check failed. Please try again.', CFDB7_PRO_TEXT_DOMAIN );
				$result['is_next_page'] = "no";
			}
			echo json_encode($result);
		}
		wp_die();
	}

	/**
	 * Retrieve information from the entry logger.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_get_entry_logger_information(){
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_entry_logger_information.php';
		wp_die();
	}

	/**
	 * Save the user display settings for the plugin.
	 *
	 * @since    1.0.0
	 * @param    array     $posted_data    The data submitted by the user.
	 * @param    object    $wpdb           The WordPress database object.
	 * @param    object    $obj            Additional object containing context or methods.
	*/
	public function cfdb7_save_display_user_setting($posted_data, $wpdb, $obj){
		$nonce = isset($_POST['cfdb7_display_setting_nonce']) && !empty($_POST['cfdb7_display_setting_nonce']) ? sanitize_text_field($_POST['cfdb7_display_setting_nonce']) : "";
		if(!empty($nonce)){
			if(wp_verify_nonce($nonce, 'cfdb7_display_setting')){
				$cf7_id = isset($posted_data['cf7-id']) && !empty($posted_data['cf7-id']) ? intval($posted_data['cf7-id']) : "";
				if(empty($cf7_id)){
					return;
				}

				// Get current user information
				$user_info = cfdb7_get_logged_in_user_info();
				$user_id = $user_info['user_id'];
				// Determine context based on current page
				$context = isset($posted_data['page']) && !empty($posted_data['page']) ? sanitize_text_field($posted_data['page']) : "";
				// Prepare display settings array
				$display_settings = array();
				// Process field rename settings
				if(isset($posted_data['rename_field']) && is_array($posted_data['rename_field'])){
					foreach($posted_data['rename_field'] as $field_name => $rename_value){
						$field_name = sanitize_text_field($field_name);
						$rename_value = sanitize_text_field(trim($rename_value));
						
						if(!empty($rename_value)){
							$display_settings['rename_field'][$field_name] = $rename_value;
						}
					}

					$field_order = array_keys($posted_data['rename_field']);
					$field_order = array_map("sanitize_text_field", $field_order);
					$display_settings['field_order'] = $field_order;
				}

				// Process field visibility settings
				if(isset($posted_data['enable_field']) && is_array($posted_data['enable_field'])){
					foreach($posted_data['enable_field'] as $field_name => $enabled){
						$field_name = sanitize_text_field($field_name);
						$display_settings['enable_field'][$field_name] = true;
					}
				}

				// Serialize settings for storage
				$settings_serialized = maybe_serialize($display_settings);

				// Check if settings already exist for this user, form, and context
				$existing_settings = $obj->get_cfdb7_form_display_settings($wpdb, $cf7_id, $user_id, $context);
				
				if(!empty($existing_settings)){
					// Update existing settings
					$obj->update_cfdb7_form_display_settings($wpdb, $cf7_id, $user_id, $context, $settings_serialized);
				} else {
					// Save new settings
					$obj->save_cfdb7_form_display_settings($wpdb, $cf7_id, $user_id, $context, $settings_serialized);
				}
				
				// Add success notice
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Display settings saved successfully.', CFDB7_PRO_TEXT_DOMAIN) . '</p></div>';
			}else{
				echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Security check failed. Please try again..', CFDB7_PRO_TEXT_DOMAIN) . '</p></div>';
			}
		}
	}

	/**
	 * Display a single form entry in the admin area.
	 *
	 * @since    1.0.0
	*/
	public function cfdb7_view_entry(){
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_entries_information.php';
		wp_die();
	}

	public function cfdb7_entries_proceed_bulk_action($post_data, $wpdb, $obj){
		$bulk_action = isset($post_data['bulk_action']) && !empty($post_data['bulk_action']) ? sanitize_text_field($post_data['bulk_action']) : "";
		$current_action = isset($post_data['action']) && !empty($post_data['action']) ? sanitize_text_field($post_data['action']) : "";
		if(!empty($bulk_action)){
			if($current_action == "delete"){
				$this->cfdb7_entries_delete_entry_ids($post_data, $wpdb, $obj);
			}else if($current_action == "export"){
				$this->cfdb7_entries_export_entry_ids($post_data, $wpdb, $obj);
			}
		}
	}

	private function cfdb7_entries_delete_entry_ids($post_data, $wpdb, $obj){
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_entries_delete_entry_ids.php';
		wp_die();
	}

	private function cfdb7_entries_export_entry_ids($post_data, $wpdb, $obj){
		include_once plugin_dir_path(__FILE__).'partials/cfdb7_entries_export_entry_ids.php';
		wp_die();
	}
}
