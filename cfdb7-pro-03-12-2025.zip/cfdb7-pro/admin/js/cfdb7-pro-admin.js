jQuery(document).ready(function(){
    if(jQuery("#save-display-settings tbody").length > 0){
        jQuery("#save-display-settings tbody").sortable({
            cursor: 'row-resize',
            placeholder: 'ui-state-highlight',
            opacity: '0.55',
            items: '.ui-sortable-handle'
        }).disableSelection();
    }
});